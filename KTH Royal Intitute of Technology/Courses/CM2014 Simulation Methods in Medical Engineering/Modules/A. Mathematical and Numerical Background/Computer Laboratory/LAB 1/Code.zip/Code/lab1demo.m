%Numerical experiments with the harmonic oscillator
%Given d2x/dt2+omega^2 x=0, x(0)=1, dx/dt(0)=0
omega=2;
h=0.1;N=100;
t=[0:h:N*h];
x=cos(omega*t);
xp=-omega*sin(omega*t);
E=omega^2*(x.*x)+xp.*xp;
X=[x' xp'];
plot(t,x,t,xp)
xlabel('t'),ylabel('x,xp')
title('Harmonic oscillator, exact trajetories')
pause
plot(x,xp)
axis('equal')
xlabel('x'),ylabel('dx/dt')
title('Harmonic oscillator, exact phase portrait')
grid
pause
plot(t,E)
xlabel('t')
ylabel('E')
title('Harmonic oscillator, exact Energi vs time')
pause
y=[1,0]';t=0;
A=[0 1;-omega^2 0];
y=[1,0]';t=0;
Y=[y'];T=[t];E=[omega^2];
for k=1:N
   y=y+h*A*y;
   Y=[Y;y'];
   t=t+h;
   T=[T;t];
   E=[E;omega^2*y(1)*y(1)+y(2)*y(2)];
end
Yexeul=Y;
plot(T,Y,'*')
xlabel('t'),ylabel('y1,y2')
title('Harmonic oscillator, Explicit Euler trajectories')
pause
plot(Y(:,1),Y(:,2),'*')
axis('equal')
xlabel('y1'),xlabel('y2')
title('Harmonic oscillator, Explicit Euler phase portrait')
pause
plot(T,E,'*')
xlabel('t'),ylabel('E')
title('Harmonic oscillator, Explicit Euler Energi vs time')
pause
y=[1,0]';t=0;
Y=[y'];T=[t];E=[omega^2];
for k=1:N
    y=(eye(2)-h*A)\y;
    Y=[Y;y'];
    t=t+h;
    T=[T;t];
    E=[E;omega^2*y(1)*y(1)+y(2)*y(2)];
end
Yimeul=Y;
plot(T,Y,'o')
xlabel('t'),ylabel('y1,y2')
title('Harmonic Oscillator, Implicit Euler trajectories')
pause
plot(Y(:,1),Y(:,2),'o')
axis('equal')
xlabel('y1'),ylabel('y2')
title('Harmonic Oscillator, Implicit Euler phase portrait')
pause
plot(T,E)
xlabel('t'),ylabel('E')
title('Harmonic Oscillator, Implicit Euler Energy vs time')