function dY=teorell_ode(t,y,params)

dY=zeros(4,1);

v=params(1);
clt=params(2);
INF=params(3);

k1=params(1);
k2=params(2);
k3=params(3);
k4=params(4);
k5=params(5);

dY(1)= - y(1)*k1; % DRUG DOSE DEPOT/SUBCUTIS ETC.
dY(2)= y(1)*k1 + y(4)*k3 - y(2)*(k2 + k4); % BLOOD CIRCULATION
dY(3)= y(2)*k4; % KIDNEY ETC. ELIMINATION
dY(4)= y(2)*k2 - y(4)*(k3 + k5); % TISSUES



