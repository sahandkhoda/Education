function dY=lotkavolterra_ode(t,y,params)

dY=zeros(2,1);

alp=params(1);
bet=params(2);
sigm=params(3);
gamm=params(4);

dY(1)= alp*y(1) - bet*y(2)*y(1); % PREY: POPULATION OVER TIME
dY(2)= sigm*y(1)*y(2) - gamm*y(2); % PREDATOR: POPULATION OVER TIME



