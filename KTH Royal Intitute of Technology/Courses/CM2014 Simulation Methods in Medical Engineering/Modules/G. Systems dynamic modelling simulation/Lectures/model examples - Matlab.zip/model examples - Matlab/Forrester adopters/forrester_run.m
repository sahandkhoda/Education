%% Simulation methods in medical engineering course
% model example: Forrester's adopter model
% Implemented from Sterman 2001

% Input parameters
ProbOfAdopt=0.5;
TotalPop=1000;
ContFreq=0.7;
OtherSources=0.1;
params=[ProbOfAdopt,TotalPop,ContFreq,OtherSources];

tspan=0:0.1:100;
yzero=[1000,0];

options=odeset();

[t, y]=ode45(@forrester_ode,tspan,yzero,options,params);

plot(t,y(:,1:2))
xlabel("Time [U]");
ylabel("Population [N]");
legend({'Potential adopters','Adopters'});

