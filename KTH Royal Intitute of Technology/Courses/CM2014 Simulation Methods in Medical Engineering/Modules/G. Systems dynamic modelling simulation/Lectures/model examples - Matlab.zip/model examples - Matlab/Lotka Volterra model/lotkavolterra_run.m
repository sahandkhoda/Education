%% Simulation methods in medical engineering course
% model example: the Lotka-Volterra model for predator-prey population
% dynamics

% Input parameters
alp=1; % ALPHA: Prey, reference growth rate [per time]
bet=1; % BETA: Prey, death rate with predator interaction [per time]
sigm=1; % SIGMA: Predator, growth rate with prey interaction [per time]
gamm=1; % GAMMA: Predator, death rate [per time]

params=[alp,bet,sigm,gamm];

tspan=0:0.1:20;
yzero=[1,0.1]; % Initial conditions: prey, predator

options=odeset();

[t, y]=ode45(@lotkavolterra_ode,tspan,yzero,options,params);

plot(t,y)
xlabel("Time [U]");
ylabel("Population [N]");
legend({'prey','predator'});

