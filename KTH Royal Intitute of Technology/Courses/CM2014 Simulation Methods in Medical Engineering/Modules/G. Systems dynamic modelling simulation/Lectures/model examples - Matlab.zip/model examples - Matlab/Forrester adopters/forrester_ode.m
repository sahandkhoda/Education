function dY=forrester_ode(t,y,params)

dY=zeros(2,1);

ProbOfAdopt=params(1);
TotalPop=params(2);
ContFreq=params(3);
OtherSources=params(4);

probOfContact = y(2)/TotalPop;
SocContacts= y(1)*ContFreq;
Contacts = SocContacts*probOfContact;
WordOfMouth = Contacts*ProbOfAdopt;
AdoptRate = WordOfMouth + OtherSources;

dY(1)= - AdoptRate; % POTENTIAL ADOPTERS
dY(2)= AdoptRate; % ADOPTER POPULATION



