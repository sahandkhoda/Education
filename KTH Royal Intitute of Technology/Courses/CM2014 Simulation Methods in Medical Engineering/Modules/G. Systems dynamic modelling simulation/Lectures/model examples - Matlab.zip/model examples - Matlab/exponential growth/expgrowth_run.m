%% Simulation methods in medical engineering course
% model example: Exponential growth model

% Input parameters
k_learn=1; % rate of learning [per time]
params=[k_learn];

tspan=0:0.1:5;
yzero=[1];

options=odeset();

[t, y]=ode45(@expgrowth_ode,tspan,yzero,options,params);

plot(t,y)
xlabel("Time [U]");
ylabel("Knowledge [K]");
legend({'Skynet'});

