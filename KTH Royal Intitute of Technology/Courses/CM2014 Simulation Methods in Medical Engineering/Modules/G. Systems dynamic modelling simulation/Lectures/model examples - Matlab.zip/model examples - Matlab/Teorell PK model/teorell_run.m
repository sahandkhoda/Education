%% Simulation methods in medical engineering course
% model example: Teorell's early work on pharmacokinetic modelling

% Input parameters
DOSE=100;   % Dose, unit: percentage
k1=1;       % rates or flows, [per time] or [volume per time]
            % subcutis-to-blood
k2=1;       % blood-to-tissues [per time]
k3=1;       % tissues-to-blood [per time]
k4=1;       % elimination rate [per time]
k5=1;       % chemical inactivation [per time]
v_tis=2;    % tissue volume [volume]

params=[k1,k2,k3,k4,k5];

tspan=0:0.1:5;
yzero=[DOSE,0,0,0]; % initial conditions

options=odeset();

[t, y]=ode45(@teorell_ode,tspan,yzero,options,params);

c_tis=y(:,4)./v_tis;
y=[y,c_tis];

plot(t,y)
xlabel("Time [U]");
ylabel("% of Dose");
legend({'depot','blood','elimination','tissue amt.','tissue conc.'});

