function dY=bertalanffy_ode(t,y,params)

dY=zeros(1,1);

p=params(1);
a=params(2);
q=params(3);

dY(1)= p*y(1)^a - q*y(1); % ONTOGENIC GROWTH, LENGTH OVER TIME



