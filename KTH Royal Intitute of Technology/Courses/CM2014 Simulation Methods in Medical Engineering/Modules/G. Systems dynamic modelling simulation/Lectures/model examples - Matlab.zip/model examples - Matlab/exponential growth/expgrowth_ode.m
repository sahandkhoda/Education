function dY=expgrowth_ode(t,y,params)

dY=zeros(1,1);

k_learn=params(1);

dY(1)= k_learn*y(1); % Knowledge, Skynet


