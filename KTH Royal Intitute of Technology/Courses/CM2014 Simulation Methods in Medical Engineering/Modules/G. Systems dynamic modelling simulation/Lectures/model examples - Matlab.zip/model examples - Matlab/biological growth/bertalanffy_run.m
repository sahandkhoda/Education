%% Simulation methods in medical engineering course
% model example: von Bertalanffy's early model on biological growth

% Input parameters
p=1; % growth rate [per time]
a=2/3; % growth exponent 
q=1; % counter acting rate [per time]

params=[p,a,q];

tspan=0:0.1:20;
yzero=[0.01];

options=odeset();

[t, y]=ode45(@bertalanffy_ode,tspan,yzero,options,params);

plot(t,y)
xlabel("Time [U]");
ylabel("Length [L]");

