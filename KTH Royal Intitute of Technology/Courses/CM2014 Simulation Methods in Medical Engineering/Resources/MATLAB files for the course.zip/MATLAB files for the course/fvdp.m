function f=fvdp(t,u);
global epsilon
f=[u(2);
  -epsilon*(u(1)^2-1)*u(2)-u(1)];
