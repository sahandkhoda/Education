%Numerical solution of the model problem with trapezoidal method
%du/dt=lambda*u, u(0)=1, 0<=t<=tN
lambda=-1;
h=0.1;N=10;
t=0;u=1;
tout=[t];uout=[u];
for k=1:N
    u=u*(1+h*lambda/2)/(1-h*lambda/2);
    t=t+h;
    uout=[uout,u];
    tout=[tout,t];
end
result=[tout',uout',exp(-tout')]
plot(tout,uout,tout,exp(-tout))
title('Implicit Euler method to solve MP1, blue=numerical, red=exact')
xlabel('t')
ylabel('u(t) and numerical solution')

    