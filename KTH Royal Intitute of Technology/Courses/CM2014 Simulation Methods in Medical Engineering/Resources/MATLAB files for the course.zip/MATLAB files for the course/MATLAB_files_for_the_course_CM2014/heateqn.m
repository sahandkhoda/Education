%This program solves the PDE called the heat equation presented in Lecture 3.
global A
alfa=0;beta=0;
N=39;hx=1/(N+1);
x=[hx:hx:1-hx]';
A=zeros(N,N);
for k=2:N
    A(k,k)=-2/hx^2;
    A(k,k-1)=1/hx^2;
    A(k-1,k)=1/hx^2;
end
A(1,1)=-2/hx^2;
lambda=eig(A);
lambdamax=max(lambda),lambdamin=min(lambda)
t0=0;T=1;
u0=sin(pi*x);
rubrik=['Solution with stiff solver ode23s']
[touts,uouts]=ode23s('fheateqn',[t0,T],u0);
number_of_steps=size(touts)
plot(touts,uouts)
title('Solution of the heat eqn')
xlabel('time t')
ylabel('temperature u(x,t)')
rubrik=['Solution with non-stiff solver ode23']
[tout,uout]=ode23('fheateqn',[t0,T],u0);
number_of_steps=size(tout)
pause
mesh(x,touts,uouts)
title('3D-plot of heat eqn solution')
xlabel('space x')
ylabel('time t')
zlabel('temperature u(x,t)')



