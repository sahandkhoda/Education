function f=fshoot(x,u);
global a
f=[0 1;0 a]*u-[0 1]';
