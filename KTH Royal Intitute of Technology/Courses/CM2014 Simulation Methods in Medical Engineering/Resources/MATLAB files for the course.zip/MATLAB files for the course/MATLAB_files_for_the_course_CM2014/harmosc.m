%Solution of the harmonic oscillator with ode45
global omega
omega=2;
t0=0;T=100;
u0=[1 0]';
[tout,uout]=ode45('fharmosc',[t0,T],u0);
plot(tout,uout(:,1))
grid
pause
plot(uout(:,1),uout(:,2))
axis('equal')
grid
pause
E=uout(:,2).*uout(:,2)+omega^2*uout(:,1).*uout(:,1);
plot(tout,E)
grid


