dir%Solve the BVP MP3) by guessing different values of k.
%We then solve the IVP -d^2u/dx^2+a*du/dx = 1, u(0)=1, du/dx(0)=k
%We try to find k so that u(1)=0. We call this a shooting method
global a
a=10;
k=1;
u0=[1 k]';
x0=0;
xend=1;
[xout,uout]=ode45('fshoot',[x0,xend],u0);
plot(xout,uout(:,1))
grid
