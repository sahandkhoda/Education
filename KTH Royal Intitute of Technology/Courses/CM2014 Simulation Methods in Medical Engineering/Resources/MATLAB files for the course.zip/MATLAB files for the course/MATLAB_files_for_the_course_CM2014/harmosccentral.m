%Solution of the harmonic oscillator with the central difference
omega=2;
h=0.1;N=20;
x0=1;x1=1-h^2*omega^2/2;
t0=0;t1=h;
tout=[t0;t1];
xout=[x0;x1];
for k=1:N-1
    x2=(2-h^2*omega^2)*x1-x0;
    t2=t1+h;
    xout=[xout;x2];
    tout=[tout;t2];
    x0=x1;
    x1=x2;
    t0=t1;
    t1=t2;
end
plot(tout,xout)
grid
