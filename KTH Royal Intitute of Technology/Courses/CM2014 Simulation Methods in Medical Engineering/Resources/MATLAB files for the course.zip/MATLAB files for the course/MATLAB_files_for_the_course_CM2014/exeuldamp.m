%Explicit Euler method to solve the vibration eqn
%With the stepsize chosen the numerical solution is unstable
m=1;c=0.4;k=4.5;%mechanical parameters
A=[0 1;-k/m -c/m];
y0=1;%initial position
h=0.01;N=1000;
u=[y0 0]';
t=0;
uout=[u'];tout=[t];
for k=1:N
    u=u+h*A*u;
    t=t+h;
    uout=[uout;u'];
    tout=[tout;t];
end
plot(tout,uout(:,1))
grid
title('Vibration equation with Explicit Euler')
xlabel('time t')
ylabel('position y')


