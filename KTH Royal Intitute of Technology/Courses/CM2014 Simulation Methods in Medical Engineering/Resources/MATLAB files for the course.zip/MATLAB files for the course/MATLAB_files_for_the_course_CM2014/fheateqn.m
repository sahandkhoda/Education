function f=fheateqn(t,u);
global A
f=A*u;
