%This program simulates the concentration of a drug in a simple
%compartment model of the human body
%See Example 2.8 in the book
global k1 k2 ke kb q
k1=1; k2=0.2; ke=2; kb=3;%rate constants
q=1;%inflow rate
u0=[0;0];%initial conditions
T=10;%final time
tspan=[0,T];
[tout,cout]=ode45('fdrug',tspan,u0);
plot(tout,cout)
title('Simulation of drug concentration in blood (blue) and organ (red)')
xlabel('time t')
ylabel('conc c(1) (blue), c(2) (red)')

