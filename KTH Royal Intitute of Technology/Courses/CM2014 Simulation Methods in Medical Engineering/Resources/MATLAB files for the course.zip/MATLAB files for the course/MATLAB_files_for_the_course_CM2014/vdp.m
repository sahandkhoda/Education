%Solution of Van der Pol's equation, see Example 3.3 in the book
%The parameter epsilon >= 0 can be changed
global epsilon
epsilon=1;
u0=[1;0];
T=10;
tspan=[0,T];
[tout,uout]=ode45('fvdp',tspan,u0);
plot(tout,uout)
title('Van der Pols equation')
xlabel('time t')
ylabel('u1 and u2')