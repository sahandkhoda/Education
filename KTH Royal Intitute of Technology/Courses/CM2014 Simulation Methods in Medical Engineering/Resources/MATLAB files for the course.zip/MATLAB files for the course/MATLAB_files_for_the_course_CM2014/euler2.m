%% 
%The accuracy of the Euler method illustrated on the Model problem
%du/dt=lambda*u, u(0)=1, exact solution u(t)=exp(lambda*t), 0<=t<=tN
lambda=-1;tN=1;
uexakt=exp(lambda*tN);
resultat=[];
for N=[10,20,40,80,160]
    h=tN/N;
    t=0;u=1;
    for k=1:N
        u=u+h*lambda*u;
        t=t+h;
    end
    resultat=[resultat;N,h,u,uexakt-u];
end
    plot(resultat(:,2),resultat(:,4))
    title('Error at t=1 for Explicit Euler as function of h for MP1')
    xlabel('h stepsize')
    ylabel('error=u(t_N)-u_N')
    grid
    format compact
    rubrik=[' N', '          h', '       u_N', '       error']
    resultat 
    
    
    
    
