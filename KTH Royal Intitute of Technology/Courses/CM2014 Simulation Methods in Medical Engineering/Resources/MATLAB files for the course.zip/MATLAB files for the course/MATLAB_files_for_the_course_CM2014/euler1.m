%Eulers method applied to du/dt=lambda*u, u(0)=1
%t_k=k*h,u_k=u_k-1+h*lambda*u_k-1, u_0=1, k=1,2,...,N
lambda=-1;
h=1;N=10;
t=0;u=1;%initial value
tout=[t];uout=[u];%numerical solution stored in tout,uout
for k=1:N
    %% 
    %% 
    u=u+h*lambda*u;
    t=t+h;
    uout=[uout;u];
    tout=[tout;t];
end
plot(tout,uout,tout,exp(-tout))
title('Explicit Euler method solving MP1, blue=numerical, red=exact')
xlabel('t')
ylabel('u(t) and numerical solution')
grid

%% 
