%This program solves the BVP MP3, presented in Lecture 3.
a=10;
alfa=1;beta=0;
N=99;h=1/(N+1);
x=[h:h:1-h]';
A=zeros(N,N);
b=zeros(N,1);
for k=2:N
    A(k,k)=2;
    A(k,k-1)=-1-a*h/2;
    A(k-1,k)=-1+a*h/2;
end
A(1,1)=2;
b=h^2*sin(pi*x);
b(1)=b(1)+alfa+h*a*alfa/2;
b(N)=b(N)+beta-h*a*beta/2;
u=A\b;
uplot=[alfa;u;beta];
xplot=[0:h:1]';
plot(xplot,uplot)

