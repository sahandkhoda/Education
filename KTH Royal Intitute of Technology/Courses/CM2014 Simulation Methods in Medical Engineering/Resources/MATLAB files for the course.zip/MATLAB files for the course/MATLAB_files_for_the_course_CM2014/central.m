%Explicit midpoint method to solve the Model problem
%du/dt=lambda*u, u(0)=1, 0<=t<=tN
lambda=-1;
h=0.2;N=10;
t0=0;u0=1;
tout=[t0];uout=[u0];
u1=u0+h*lambda*u0;t1=t0+h;
tout=[tout,t1];uout=[uout,u1];
for k=2:N
    u2=u0+2*h*lambda*u1;
    t2=t1+h;
    uout=[uout,u2];
    tout=[tout,t2];
    u0=u1;u1=u2;
    t1=t2;
end
plot(tout,uout,tout,exp(lambda*tout))
title('Numerical solution of MP1 with central difference approximation')
xlabel('t')
ylabel('Numerical solution')

