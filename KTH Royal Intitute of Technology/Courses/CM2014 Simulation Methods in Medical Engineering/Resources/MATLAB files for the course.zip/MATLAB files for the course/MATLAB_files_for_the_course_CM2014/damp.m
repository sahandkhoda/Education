%Solution of the vibration equation with ode45
global m c k
m=1;c=0.4;k=4.5;
u0=[1 0]';
T=10;
[tout,uout]=ode45('fdamp',[0 T],u0);
plot(tout,uout(:,1))
grid
title('Vibration eqn with ode45')
xlabel('time t')
ylabel('position y')