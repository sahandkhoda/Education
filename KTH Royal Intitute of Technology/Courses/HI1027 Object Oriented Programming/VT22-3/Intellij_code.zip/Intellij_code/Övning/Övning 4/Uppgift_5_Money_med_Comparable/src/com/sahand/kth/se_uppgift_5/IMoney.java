package com.sahand.kth.se_uppgift_5;

/**
 * Represents an amount of money in a specific currency.
 * Instances of this class are </em>immutable</em>.
 * </p>
 * The implementing class must have three constructors, each with two arguments:
 *  1. (throws IllegalArgumentException if amount < 0) one argument (amount 0)
 *  2. (throws IllegalArgumentException if amount < 0) no argument (amount 0, currency EUR)
 */

public interface IMoney extends Comparable<Money>
{
    /** @return amount for this Money */
    double getAmount();

    /** @return currency for this Money */
    Currency getCurrency();

    /** @return copy of this instance */
    Money copy();

    /**
     * Create a new Money instance, with the indicated currency.
     * @param newCurrency the new currency
     * @return new Money instance
     */
    Money toCurrency(Currency newCurrency);

    /**
     * Create a new Money instance with the sum, in the same currency as this.
     * @param moneyToAdd the money to add to this money
     * @return new Money instance, in the same currency as this
     * @throws IllegalArgumentException if the amount is less than zero
     */
    Money add(Money moneyToAdd);

    /**
     * Create a new Money instance with the difference, in the same currency as this.
     * @param moneyToSubtract the money to subtract from this money
     * @return new Money instance, in the same currency as this
     * @throws IllegalArgumentException if the sum is less than zero
     */
    Money subtract(Money moneyToSubtract) throws IllegalArgumentException;

    /** @return string with the amount, rounded to two decimals, and the currency */
    @Override
    String toString();

    /**
     * Compare amounts, internally converted to EUR.
     * Two instances are considered equal if the amounts differ less than 1E-3.
     * Also, see documentation for interface java.lang.Comparable.
     * @param other other Money instance to compare to
     * @return integer (less, equal, or greater than)
     */
    @Override
    int compareTo(Money other);

    /**
     * Compare amounts, internally converted to EUR.
     * Two instances are considered equal if the amounts differ less than 1E-3.
     * Also, see documentation for interface java.lang.Object.
     * @param other other Money instance to compare to
     * @return boolean (true or false)
     */
    @Override
    boolean equals(Object other);
}