package com.sahand.kth.se_uppgift_5;

public class Money implements IMoney
{
    public Money(double amount, Currency currency) throws IllegalArgumentException {
        this.amount   = amount;
        this.currency = currency;
    }
    public Money(Currency currency) {
        this(0.0, currency);
    }
    public Money() {
        this(Currency.EUR);
    }

    @Override
    public Money toCurrency(Currency newCurrency) {
        return new Money(calculateAmountIn(newCurrency), newCurrency);
    }

    @Override
    public Money add(Money moneyToAdd) {
        if (moneyToAdd.getAmount() < 0) {
            double absAmount = Math.abs(moneyToAdd.getAmount());
            subtract(new Money(absAmount, moneyToAdd.getCurrency()));
            return null;
        }
        double sum = getAmount() + moneyToAdd.getAmount();
        return new Money(sum, getCurrency());
    }

    @Override
    public Money subtract(Money moneyToSubtract) throws IllegalArgumentException {
        double difference = getAmount()-moneyToSubtract.calculateAmountIn(getCurrency());
        if (difference < 0) throw new IllegalArgumentException("DIFFERENCE IS LESS THAN ZERO");
        return new Money(difference, getCurrency());
    }

    @Override
    public int compareTo(Money other) {
        double thisEUR  = this.calculateAmountIn(Currency.EUR);
        double otherEUR = other.calculateAmountIn(Currency.EUR);
        return Double.compare(thisEUR, otherEUR);
        /*
        if (thisEUR < otherEUR)
            return -1;
        else if (thisEUR > otherEUR)
            return 1;
        else
            return 0;
        */
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof Money) {
            return this.compareTo((Money) other) == 0;
        }
        return false;
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final double amount;
    private final Currency currency;

    private double calculateAmountIn(Currency newCurrency) {
        return getAmount() * getCurrency().getRate() / newCurrency.getRate();
    }

    @Override
    public double   getAmount()   { return amount; }
    @Override
    public Currency getCurrency() { return currency; }
    @Override
    public Money    copy()        { return new Money(getAmount(), getCurrency()); }

    @Override
    public String toString() {
        return String.format("\n" + "Amount : %.2f [%s]", getAmount(), getCurrency().toString());
    }
}