package com.sahand.kth.se_uppgift_5;

public enum Currency
{
    EUR("euro",   1.00),
    SEK("kronor", 0.095),
    USD("dollar", 0.91),
    NOK("kronor", 0.092);

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final String name;
    private final double rate;        // Rate with regard to EUR

    private Currency(String name, double rate) {
        this.name = name;
        this.rate = rate;
    }

    public String getName() { return name; }
    public double getRate() { return rate; }
}
