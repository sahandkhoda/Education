package com.sahand.kth.se_uppgift_5;

public class Main {

    public static void main(String[] args)
    {
        Money eur1 = new Money(50, Currency.EUR);
        System.out.println(eur1.toString());

        Money eur2 = eur1.subtract(new Money(20, Currency.NOK));
        System.out.println(eur2.toString());

        Money sek1 = eur1.toCurrency(Currency.SEK);
        System.out.println(sek1.toString());

        Money sek2 = eur2.toCurrency(Currency.SEK);
        System.out.println(sek2.toString());
    }
}
