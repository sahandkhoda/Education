package com.sahand.kth.se;

import java.util.Random;

/**
 * The random class generates a number between (inclusive) 0 and 5 (exclusive).
 * Therefore, one is added. Alternatively, use value = (int) (Math.random()*SIDES + 1)
 */

public class Dice
{
    /** DATA FIELDS */
    private int value;
    private final int[] frequency;
    private final int SIDES;
    private final Random random;

    public Dice() { this(6); }
    public Dice(int sides) {
        random = new Random();
        SIDES = sides;
        value = 1;
        frequency = new int[SIDES];
    }

    public void throwDice() {
        value = random.nextInt(SIDES) + 1;
        frequency[value-1] += 1;
    }

    /** ACCESS METHODS */
    public int    getValue()     { return value;           }
    public int[]  getFrequency() { return frequency;       }
    public String toString()     { return String.valueOf(getValue()); }

    //public int getFrequency(int index) { return frequency[index]; }
}
