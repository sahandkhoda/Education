package com.company;

public enum Rank {
    ACE     (1),
    TWO     (2),
    THREE   (3),
    FOUR    (4),
    FIVE    (5),
    SIX     (6),
    SEVEN   (7),
    EIGHT   (8),
    NINE    (9),
    TEN     (10),
    KNIGHT  (11),
    QUEEN   (12),
    KING    (13);

    private final int valueRANK;
    Rank(int valueRANK) { this.valueRANK = valueRANK; }
    public int getValueRANK()   { return valueRANK; }
}
