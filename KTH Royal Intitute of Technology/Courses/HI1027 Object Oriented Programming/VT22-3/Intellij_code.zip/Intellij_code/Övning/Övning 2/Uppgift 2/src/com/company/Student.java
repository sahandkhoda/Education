package com.company;

public class Student
{
    private final String fullName;
    private String program;
    private double credits;

    public Student(String fullName, String program) {
        this.fullName = fullName;
        this.program = program;
    }

    public void addCredit(double credits) {
        if (credits<0) throw new IllegalArgumentException("INVALID CREDIT");
        this.credits += credits;
    }

    public void setProgram(String newProgram) { program = newProgram; }

    public String toString() {
        return "Full name : " + this.fullName + "\n"
             + "Program   : " + this.program  + "\n"
             + "Credit    : " + this.credits  + "\n";
    }
}
