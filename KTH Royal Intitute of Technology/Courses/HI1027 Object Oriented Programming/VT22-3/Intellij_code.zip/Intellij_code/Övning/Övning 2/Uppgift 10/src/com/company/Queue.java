package com.company;

public class Queue
{
    /** DATA FIELDS */
    private String[] theQueue;
    private int nrOfElements;

    /** CONSTRUCTOR */
    public Queue() {
        this(10);
    }
    public Queue(int CAPACITY) {
        theQueue = new String[CAPACITY];
        nrOfElements = 0;
    }

    public void enqueue(String newElement) {
        if (nrOfElements == theQueue.length) resize();
        theQueue[nrOfElements++] = newElement;
    }

    private void resize() {
        String[] temp = new String[theQueue.length * 2];
        System.arraycopy(theQueue, 0, temp, 0, theQueue.length);
        theQueue = temp;
    }

    public String dequeue() {
        String element = theQueue[0];
        System.arraycopy(theQueue, 1, theQueue, 0, theQueue.length - 1);
        nrOfElements--;
        return element;
    }

    /** ACCESS METHODS */
    public int size()        { return nrOfElements;      }
    public String peek()     { return theQueue[0];       }
    public boolean isEmpty() { return nrOfElements == 0; }

    public String[] getAll() {
        String[] temp = new String[nrOfElements];
        System.arraycopy(theQueue, 0, temp, 0, nrOfElements);
        return temp;
    }

    @Override
    public String toString()
    {
        StringBuilder info = new StringBuilder("[ ");
        for (int i=0; i<nrOfElements; i++) {
            info.append(theQueue[i]).append(" ");
            if (i+1 != nrOfElements) info.append(", ");

        }
        info.append("]");
        return info.toString();
    }
}
