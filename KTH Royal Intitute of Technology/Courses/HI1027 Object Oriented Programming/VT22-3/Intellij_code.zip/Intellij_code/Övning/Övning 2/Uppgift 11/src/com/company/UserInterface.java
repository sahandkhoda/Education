package com.company;

import java.util.Scanner;

public class UserInterface
{
    public void runProgram()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.println("WELCOME");
        System.out.print("Enter limit : ");
        int limit = scanner.nextInt();
        GuessMyNumberModel play = new GuessMyNumberModel(limit);
        System.out.println("Initializing game... DONE\n");

        do {
            System.out.print("Enter guess [1..." + play.getMAX() + "] : ");
            int guess = scanner.nextInt();
            play.setGuess(guess);
            System.out.println(play.compareGuessToString());

        } while (play.compareGuess()!=0);

        System.out.println(play.toString());
    }
}
