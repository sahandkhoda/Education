package com.company;

import java.time.LocalDate;

public class PostIt
{
    /** DATA FIELDS */
    private String note;
    private LocalDate localDate;
    private final  int number;
    private static int nrOfPostIts = 0;

    /** CONSTRUCTOR */
    public PostIt(String note) {
        this.note = note;
        localDate = LocalDate.now();
        nrOfPostIts++;
        number = nrOfPostIts;
    }

    /** ADD NEW INFO */
    public void append(String newInfo) {
        this.note += "\n" + newInfo;
        localDate = LocalDate.now();
    }

    /** ACCESS METHODS */
    public    String getNote()      { return note; }
    public LocalDate getLocalDate() { return localDate; }
    public       int getNumber()    { return number; }

    @Override
    public String toString() {
        return "\n" + "--------------"
             + "\n" + "POST IT #" + getNumber()
             + "\n" + getNote()
             + "\n" + "Last updated : (" + getLocalDate() + ")";

    }


}
