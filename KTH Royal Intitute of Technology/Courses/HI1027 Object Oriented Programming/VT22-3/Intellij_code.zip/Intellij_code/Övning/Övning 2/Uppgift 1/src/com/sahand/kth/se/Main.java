package com.sahand.kth.se;

import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        System.out.println();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Sides of dice : ");
        int SIDES  = scanner.nextInt();
        System.out.print("Total throws  : ");
        int THROWS = scanner.nextInt();

        Dice d1 = new Dice(SIDES);
        Dice d2 = new Dice();

        System.out.println();
        System.out.println("DICE 1 | DICE 2");
        for (int i=0; i<THROWS; i++) {
            d1.throwDice();
            d2.throwDice();
            System.out.println("   " + d1.toString() + "   |   " + d2.toString());
        }

        final int MAX_THROWS = 1000;
        int[] freq1 = d1.getFrequency();
        int[] freq2 = d2.getFrequency();
        System.out.println();
        System.out.println("FREQUENCY");
        for (int i=THROWS; i<MAX_THROWS; i++) {
            d1.throwDice();
            d2.throwDice();
        }
        for (int i=0; i<SIDES; i++) {
            System.out.printf("#%d : %d | %d\n", (i+1), freq1[i], freq2[i]);
        }

        /*
        for (int index=0; index<SIDES; index++) {
            System.out.println((index+1) + " : " + d.getFrequency(index));
        }
        */
    }
}