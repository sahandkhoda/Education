package com.company;

public class Main {

    public static void main(String[] args)
    {
        // STUDENT INFO START
        Student a = new Student("Adam Sandler", "GROWN");
        Student c = new Student("Chris Rock"  , "UPS");

        System.out.println();
        System.out.println("=== STUDENT INFO ===\n");
        System.out.println(a);
        System.out.println(c);

        // SET PROGRAM
        a.setProgram("GOLF");
        c.setProgram("COMEDY");

        // ADD CREDIT
        a.addCredit(8.0);
        c.addCredit(15.3);

        // STUDENT INFO END
        System.out.println("=== STUDENT INFO ===\n");
        System.out.println(a);
        System.out.println(c);

    }
}
