package com.company;

import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        System.out.println();
        System.out.print("NEW POST IT : ");
        PostIt p1 = new PostIt(scanner.nextLine());
        System.out.print("ADD NOTE : ");
        p1.append(scanner.nextLine());
        
        System.out.println();
        System.out.print("NEW POST IT : ");
        PostIt p2 = new PostIt(scanner.nextLine());
        System.out.print("ADD NOTE : ");
        p2.append(scanner.nextLine());

        System.out.println(p1);
        System.out.println(p2);
    }
}
