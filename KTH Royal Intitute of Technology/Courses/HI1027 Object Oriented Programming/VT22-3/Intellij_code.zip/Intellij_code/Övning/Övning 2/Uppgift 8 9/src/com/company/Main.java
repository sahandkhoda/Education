package com.company;

public class Main {

    public static void main(String[] args)
    {
        Rational r0 = new Rational();
        Rational r1 = new Rational(3,2);
        Rational r2 = new Rational(6,3);
        Rational r3 = new Rational(-6,4);
        Rational r4 = r1.add(r2);
        System.out.println();
        System.out.println(r0.toString());
        System.out.println(r1.toString());
        System.out.println(r2.toString());
        System.out.println(r3.toString());
        System.out.println(r4.toString());
    }
}
