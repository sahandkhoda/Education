package com.company;

public class Main {

    public static void main(String[] args)
    {
        Queue q = new Queue(4);
        q.enqueue("Hi");
        q.enqueue("There");
        q.enqueue("U");
        q.enqueue("Good");
        q.enqueue("Mate?");

        System.out.println(q.toString());
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        System.out.println(q.toString());
    }
}
