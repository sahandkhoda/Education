package com.company;

public class Rational
{
    /** DATA FIELDS */
    private int num, den;

    /** CONSTRUCTOR */
    Rational() {
        this(0, 1);
    }

    Rational(int numerator) {
        this(numerator, 1);
    }

    Rational(int numerator, int denominator) {
        num = numerator;
        den = denominator;
        if (den==0) {
            throw new IllegalArgumentException(
                    """
                    
                    
                    --- ERROR ---
                    DENOMINATOR can't be ZERO (0)!
                    Exiting program...
                    """);
        }
        simplify();
    }

    /** Common factor in both numerator and denominator */
    private void simplify() {
        for(int i = Math.abs(num); i>0; i--) {
            if (num % i == 0 && den % i == 0) {
                num /= i;
                den /= i;
                break;
            }
        }
    }

    /** The sum of two fractions can be calculated by the following formula:
     * ( (N1*D2) + (N2*D1) ) / (D1*D2)
     */
    public Rational add(Rational other) {
        return new Rational
                (
                ((this.num * other.den) + (other.num * this.den))
                ,
                (this.den * other.den)
                );
    }

    /** ACCESS METHODS */
    @Override
    public String toString() {
        return
        "RATIO : " + getNum() + "/" + getDen() + " = " + getRatio();
    }

    public int getNum() { return num; }
    public int getDen() { return den; }
    public double getRatio() { return (double) num / den; }
}
