package com.company;

public class Main {

    public static void main(String[] args)
    {
        ECARD card1 = new ECARD(Rank.KING, Suit.CLUBS);
        ECARD card2 = new ECARD(1, 3);
        System.out.println();
        System.out.println("CARD 1 : " + card1);
        System.out.println("CARD 2 : " + card2);
        System.out.println("-------------------------");

        if (card1.compareRANK(card2) < 0) {
            System.out.println(card1 + " has lower rank than " + card2);
        } else if (card1.compareRANK(card2) > 0) {
            System.out.println(card1 + " has higher rank than " + card2);
        } else if (card1.equals(card2)) {
            System.out.println("The cards are the same!");
        } else
            System.out.println(card1 + " has the same rank as " + card2);
    }
}
