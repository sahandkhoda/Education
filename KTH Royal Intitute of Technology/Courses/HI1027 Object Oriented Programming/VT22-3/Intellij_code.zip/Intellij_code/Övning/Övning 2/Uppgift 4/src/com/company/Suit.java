package com.company;

public enum Suit {
    DIAMONDS    (1),
    CLUBS       (2),
    HEARTS      (3),
    SPADES      (4);

    private final int valueSUIT;
    Suit(int valueSUIT) { this.valueSUIT = valueSUIT; }
    public int getValueSUIT()   { return valueSUIT; }
}
