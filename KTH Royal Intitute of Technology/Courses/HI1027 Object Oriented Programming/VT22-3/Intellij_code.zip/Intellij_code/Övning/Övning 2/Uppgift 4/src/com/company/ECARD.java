package com.company;

public class ECARD
{
    /** DATA FIELDS */
    private final Rank RANK;
    private final Suit SUIT;

    /** CONSTRUCTOR (rank, suit) */
    public ECARD(Rank rank, Suit suit) {
        this.RANK = rank;
        this.SUIT = suit;
    }

    /** CONSTRUCTOR (int) */
    public ECARD(int rank, int suit) {

        RANK = Rank.values()[rank-1];
        SUIT = Suit.values()[suit-1];

        /*
        switch (rank) {
            case 1  -> this.rank = Rank.ACE;
            case 2  -> this.rank = Rank.TWO;
            case 3  -> this.rank = Rank.THREE;
            case 4  -> this.rank = Rank.FOUR;
            case 5  -> this.rank = Rank.FIVE;
            case 6  -> this.rank = Rank.SIX;
            case 7  -> this.rank = Rank.SEVEN;
            case 8  -> this.rank = Rank.EIGHT;
            case 9  -> this.rank = Rank.NINE;
            case 10 -> this.rank = Rank.TEN;
            case 11 -> this.rank = Rank.KNIGHT;
            case 12 -> this.rank = Rank.QUEEN;
            default -> this.rank = Rank.KING;
        }

        switch (suit) {
            case 1  -> this.suit = Suit.DIAMONDS;
            case 2  -> this.suit = Suit.CLUBS;
            case 3  -> this.suit = Suit.HEARTS;
            default -> this.suit = Suit.SPADES;
        } */
    }

    /** COMPARE */
    public int compareRANK(ECARD other) {
        return this.RANK.getValueRANK() - other.RANK.getValueRANK();
    }

    /** EQUALS */
    public boolean equals(ECARD other) {
        return this.RANK == other.RANK && this.SUIT == other.SUIT;
    }

    /** ACCESS METHODS */
    public Rank getRANK() { return RANK; }
    public Suit getSUIT() { return SUIT; }
    public int  getRankValue() { return RANK.getValueRANK(); }
    public int  getSuitValue() { return SUIT.getValueSUIT();  }

    @Override
    public String toString() { return getRANK() + " of " + getSUIT(); }
}
