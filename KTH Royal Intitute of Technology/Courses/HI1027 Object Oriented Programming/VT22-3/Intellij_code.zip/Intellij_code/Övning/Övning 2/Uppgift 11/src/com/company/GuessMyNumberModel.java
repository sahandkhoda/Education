package com.company;

import java.util.Random;

public class GuessMyNumberModel
{
    /** DATA FIELDS */
    private final int MAX;
    private int secret, guess, nrOfGuesses;

    /** CONSTRUCTOR */
    public GuessMyNumberModel(int limit) {
        MAX = limit;
        initGame();
    }


    public void initGame() {
        Random random = new Random();
        secret = random.nextInt(MAX)+1;
        nrOfGuesses = 0;
    }

    public void setGuess(int guess) {
        this.guess = guess;
        nrOfGuesses++;
    }

    public int compareGuess() {
        return Integer.compare(guess, secret);
    }

    public String compareGuessToString() {
        return switch (compareGuess())
                {
                    case -1 -> "too low...";
                    case 1  -> "too high...";
                    default -> "CORRECT";
                };
    }


    /** ACCESS METHODS */
    public int getMAX()         { return MAX; }
    public int getGuess()       { return guess; }
    public int getSecret()      { return secret; }
    public int getNrOfGuesses() { return nrOfGuesses; }

    @Override
    public String toString()
    {
        return "\n" + "Secret : " + getSecret()
             + "\n" + "Number of guesses : " + getNrOfGuesses()
             + "\n" + "BYE BYE";
    }
}
