package com.company.carpark;

public class Car
{
    /** CONSTRUCTOR */
    public Car(String reg, String manufacturer) {
        this.reg = reg;
        this.manufacturer = manufacturer;
        theOwner = null;
    }

    /** PACKAGE PRIVATE METHODS */
    void setTheOwner(Owner theOwner) {
        this.theOwner = theOwner;
    }
    void removeOwner() {
        theOwner = null;
    }

    /** DATA FIELDS */
    private final String reg;
    private final String manufacturer;
    private Owner theOwner;

    /** ACCESS METHODS */
    public String getReg()          { return reg; }
    public String getManufacturer() { return manufacturer; }
    public Owner  getTheOwner()     { return theOwner; }

    @Override
    public String toString() {
        return getReg() + " [" + getManufacturer() + "]";
    }
}
