package com.company;

public class ActorRole
{
    /** PRIVATE FIELDS */
    private final Movie  film;
    private final String character;
    private final Person actor;

    /** CONSTRUCTOR */
    public ActorRole(Movie film, String character, Person actor) {
        this.film      = film;
        this.character = character;
        this.actor     = actor;
    }

    /** ACCESS METHODS */
    public Movie  getFilm()      { return film;      }
    public String getCharacter() { return character; }
    public Person getActor()     { return actor;     }

    @Override
    public String toString() {
        return "* " + getActor().getName()  + " [" + getActor().getDateOfBirth() + "]" + " as " + getCharacter();
    }
}
