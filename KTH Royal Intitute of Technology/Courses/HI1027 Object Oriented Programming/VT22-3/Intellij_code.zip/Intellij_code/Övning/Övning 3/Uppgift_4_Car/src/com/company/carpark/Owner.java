package com.company.carpark;

public class Owner
{
    /** CONSTRUCTOR */
    public Owner(String name, String address) {
        this.name = name;
        this.address = address;
        theCar = null;
    }

    /** OTHER METHODS */
    public void setCar(Car theCar) {
        if (theCar.getTheOwner() == null) {
            this.theCar = theCar;
            theCar.setTheOwner(this);       // Double directed association!
        }
    }

    public void removeCar() {
        if (theCar != null) {
            theCar.removeOwner();           // Remove both associations!
            theCar = null;
        }
    }

    /** DATA FIELDS */
    private final String name;
    private final String address;
    private Car theCar;

    /** ACCESS METHODS */
    public String getName()    { return name; }
    public String getAddress() { return address; }
    public Car    getCar()     { return theCar; }

    @Override
    public String toString() {
        String info = "\n" + getName() + " (" + getAddress() + ")" + "\n";
        info += (theCar != null) ? ("CAR : " + theCar.toString()) : ("NO CAR");
        return info;
    }
}
