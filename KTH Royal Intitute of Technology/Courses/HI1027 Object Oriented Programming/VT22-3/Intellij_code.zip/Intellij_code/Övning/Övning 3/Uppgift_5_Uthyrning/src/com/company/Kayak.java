package com.company;

import java.util.Locale;

public class Kayak
{
    /** CONSTRUCTOR */
    public Kayak(String model, KLevel level, long number, Member caretaker) {
        this.model     = model.toUpperCase(Locale.ROOT);
        this.level     = level;
        this.number    = number;
        this.caretaker = caretaker;
    }

    /** SET METHOD */
    public void setCaretaker(Member newCaretaker) {
        caretaker = newCaretaker;
    }

    /** DATA FIELDS */
    private final String model;
    private final KLevel level;
    private final long number;
    private Member caretaker;

    /** ACCESS METHODS */
    public String getModel()     { return model;     }
    public KLevel getLevel()     { return level;     }
    public long   getNumber()    { return number;    }
    public Member getCaretaker() { return caretaker; }

    @Override
    public String toString() {
        return "\n"
             + "KAYAK [" + getNumber() + "]" + "\n"
             + "* Model : " + getModel() + "\n"
             + "* Level : " + getLevel() + "\n"
             + "Caretaker : " + getCaretaker();
    }
}
