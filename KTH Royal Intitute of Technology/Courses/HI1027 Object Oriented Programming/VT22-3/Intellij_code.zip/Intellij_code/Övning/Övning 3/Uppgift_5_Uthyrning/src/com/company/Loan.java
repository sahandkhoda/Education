package com.company;

import java.time.LocalDate;

public class Loan
{
    /** CONSTRUCTOR */
    public Loan(Kayak kayak, Member borrower, LocalDate loanDate) {
        this.kayak     = kayak;
        this.borrower  = borrower;
        this.loanDate = loanDate;
    }

    /** DATA FIELDS */
    private final Kayak kayak;
    private final Member borrower;
    private final LocalDate loanDate;

    /** ACCESS METHODS */
    public Kayak     getKayak()    { return kayak;     }
    public Member    getBorrower() { return borrower;    }
    public LocalDate getLoanDate() { return loanDate; }

    @Override
    public String toString() {
        return "LOAN" + "\n"
             + "* Kayak     : " + getKayak()
             + "* Borrower  : " + getBorrower()
             + "* Loan date : " + getLoanDate();
    }
}
