package com.company;

public enum KLevel
{
    BEGINNER (1),
    EASY     (2),
    SKILLED  (3),
    ADVANCED (4);

    private final int level;
    private KLevel(int level) { this.level = level; }
    public int getLevel() { return level; }
}
