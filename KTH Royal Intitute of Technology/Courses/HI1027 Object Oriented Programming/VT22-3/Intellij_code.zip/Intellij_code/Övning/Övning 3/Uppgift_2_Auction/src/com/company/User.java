package com.company;

public class User
{
    /** PRIVATE FIELDS */
    private final String username, email;
    private String password;

    /** CONSTRUCTOR */
    public User(String username, String email, String password) {
        this.username = username;
        this.email    = email;
        this.password = password;
    }

    /** SET METHOD */
    public void setPassword(String newPassword) {
        password = newPassword;
    }

    /** ACCESS METHODS */
    public String getUsername() { return username; }
    public String getEmail()    { return email;    }
    public String getPassword() { return password; }

    @Override
    public String toString() {
        return "Username : " + getUsername() + "\n" +
               "Email    : " + getEmail() + "\n" +
               "Password : " + getPassword();
    }
}
