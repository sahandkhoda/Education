package com.company;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Movie
{
    /** PRIVATE FIELDS */
    private final String title;
    private final Genre genre;
    private final Person director;
    private final LocalDate releaseDate;
    private final ArrayList<ActorRole> actorRoles;

    /** CONSTRUCTOR */
    public Movie(String title, Genre genre, Person director, LocalDate releaseDate) {
        this.title       = title;
        this.genre       = genre;
        this.director    = director;
        this.releaseDate = releaseDate;
        actorRoles = new ArrayList<>();
    }

    /** ADD ACTOR ROLE */
    public void addActorRole(String character, Person actor) {
        actorRoles.add(new ActorRole(this, character, actor));
    }

    /** ACCESS METHODS */
    public String    getTitle()       { return title;       }
    public Genre     getGenre()       { return genre;       }
    public Person    getDirector()    { return director;    }
    public LocalDate getReleaseDate() { return releaseDate; }
    public List<ActorRole> getActorRoles() { return new ArrayList<>(actorRoles); }

    @Override
    public String toString() {
        return getTitle() + " (" + getGenre() + ")"
             + " [" + getReleaseDate() + "]" + "\n"
             + "DIRECTOR : " + getDirector().getName() + "\n"
             + "STARRING :";
    }
}
