package com.company;

import java.time.LocalDate;
import java.util.List;

public interface ILoanManager
{
    public abstract List<Kayak> getKayaks();
    public abstract List<Loan>  getLoans();

    public abstract void addKayak(Kayak newKayak);
    public abstract void addLoan(Kayak kayak, Member borrower, LocalDate loanDate)
            throws IllegalStateException;

    public abstract List<Loan>  getLoansFor(Kayak kayak);
    public abstract List<Kayak> getAvailableKayaks(LocalDate targetDate);
}
