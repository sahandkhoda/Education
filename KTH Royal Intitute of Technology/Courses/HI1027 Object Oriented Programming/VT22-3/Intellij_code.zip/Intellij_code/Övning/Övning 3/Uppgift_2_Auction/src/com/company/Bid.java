package com.company;

public class Bid
{
    /** PRIVATE FIELDS */
    private final User bidder;
    private final int bid;

    /** CONSTRUCTOR */
    public Bid(User bidder, int bid) {
        this.bidder = bidder;
        this.bid    = bid;
    }

    /** ACCESS METHODS */
    public User getBidder() { return bidder; }
    public int  getBid()    { return bid;    }

    @Override
    public String toString() {
        return getBidder().getUsername() + "[" + getBid() + "]";
    }
}
