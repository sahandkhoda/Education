package com.company;

import java.util.ArrayList;
import java.util.List;

public class Auction
{
    /** PRIVATE FIELDS */
    private final User owner;
    private final String item;
    private final ArrayList<Bid> bids;

    /** CONSTRUCTOR */
    public Auction(User owner, String item) {
        this.owner = owner;
        this.item  = item;
        bids  = new ArrayList<>();
    }

    /** ADD BID METHOD */
    public void addBid(Bid bid) {
        bids.add(bid);
    }

    /** ACCESS METHODS */
    public User      getOwner() { return owner; }
    public String    getItem()  { return item;  }
    public List<Bid> getBids()  { return new ArrayList<>(bids); }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("\n");
        builder.append(owner.getUsername()).append(" | Item : ").append(item).append("\n").append("Bids :\n");
        for (Bid b : bids) {
            builder.append(b.getBidder().getUsername())
                   .append(" [").append(b.getBid()).append("]\n");
        }
        return builder.toString();
    }
}
