package com.company;

import java.time.LocalDate;
import java.util.List;

public class Main {

    public static void main(String[] args)
    {
        Person peter = new Person
                ("Peter Jackson",
                 "Oscar-winning director",
                 LocalDate.of(1968, 5, 21));

        Person elijah = new Person
                ("Elijah Wood",
                 "Talented actor",
                 LocalDate.of(1988, 3, 1));

        Person sean = new Person
                ("Sean Austin",
                 "Best-friend",
                 LocalDate.of(1982, 9, 30));

        Movie TLOTR = new Movie
                ("The Lord of the Rings",
                 Genre.ADVENTURE,
                 peter,
                 LocalDate.of(2001,9,21));

        TLOTR.addActorRole("Frodo Baggins", elijah);
        TLOTR.addActorRole("Samwise Gamgee", sean);

        System.out.println();
        System.out.println(TLOTR.toString());
        List<ActorRole> roles = TLOTR.getActorRoles();
        for (ActorRole role : roles) {
            System.out.println(role.toString());
        }

    }
}
