package com.company;

import java.util.Locale;

public class Member
{
    public Member(String fullName, Pnr pnr) {
        this.fullName = fullName.toUpperCase(Locale.ROOT);
        this.pnr = pnr;
    }

    /** DATA FIELDS */
    private final String fullName;
    private final Pnr pnr;

    /** ACCESS METHODS */
    public String getFullName() { return fullName; }
    public Pnr    getPnr()      { return pnr; }

    @Override
    public String toString() {
        return getFullName() + " [" + getPnr().toString() + "]" + "\n";
    }
}
