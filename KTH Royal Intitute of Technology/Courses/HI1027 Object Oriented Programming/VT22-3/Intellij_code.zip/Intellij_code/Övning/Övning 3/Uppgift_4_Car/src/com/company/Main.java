package com.company;

import com.company.carpark.Car;
import com.company.carpark.Owner;

public class Main {

    public static void main(String[] args)
    {
        Owner adam = new Owner("Adam Sandler","Gilmore LA 101");
        Car car = new Car("ABC123", "VOLVO");
        adam.setCar(car);
        System.out.println(adam.toString());
        adam.removeCar();
        System.out.println(adam.toString());
    }
}
