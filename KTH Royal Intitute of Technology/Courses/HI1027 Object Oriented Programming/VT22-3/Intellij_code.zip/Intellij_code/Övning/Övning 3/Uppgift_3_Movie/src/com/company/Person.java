package com.company;

import java.time.LocalDate;

public class Person {

    /** PRIVATE FIELDS */
    private final String name;
    private String biography;
    private final LocalDate dateOfBirth;

    /** CONSTRUCTOR */
    public Person(String name, String biography, LocalDate dateOfBirth) {
        this.name = name;
        this.biography = biography;
        this.dateOfBirth = dateOfBirth;
    }

    /** ADD TO BIOGRAPHY */
    public void addBiography(String newInfo) {
        biography += "\n" + newInfo;
    }

    /** ACCESS METHODS */
    public String    getName()        { return name;        }
    public String    getBiography()   { return biography;   }
    public LocalDate getDateOfBirth() { return dateOfBirth; }

    @Override
    public String toString() {
        return getName() + " [" + getDateOfBirth() + "]"
             + "\n" + getBiography();
    }
}
