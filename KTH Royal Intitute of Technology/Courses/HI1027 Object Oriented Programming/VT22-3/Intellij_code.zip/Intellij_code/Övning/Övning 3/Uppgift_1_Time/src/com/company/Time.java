package com.company;

public class Time
{
    /** PRIVATE FIELDS */
    private int hour, min, sec;

    /** CONSTRUCTORS */
    public Time(int hour, int min, int sec) {

        if (hour<0 || min<0 || sec<0) {
            throw new IllegalArgumentException("INVALID TIME");
        }

        this.hour = hour;
        this.min  = min;
        this.sec  = sec;
        adjust();
    }

    public Time(int hour, int min) {
        this(hour, min, 0);
    }

    /** METHODS */
    public void setTime(int h, int m, int s) {
        hour = h;
        min  = m;
        sec  = s;
        adjust();
    }

    private void adjust() {

        // Add up minutes and hours
        min  += (sec/60);
        hour += (min/60);

        // The remainder
        sec  %= 60;
        min  %= 60;
        hour %= 24;
    }

    public void tic(int ticSec) {
        sec += ticSec;
    }
    public void tic() {
        tic(1);
    }

    /** ACCESS METHODS */
    public int getHour() { return hour; }
    public int getMin()  { return min;  }
    public int getSec()  { return sec;  }

    @Override
    public String toString()
    {
        return String.format("%02d", getHour()) + ":" +
               String.format("%02d", getMin())  + ":" +
               String.format("%02d", getSec());
    }
}
