package com.company;

public class Main {

    public static void main(String[] args)
    {
        System.out.println();
        User adam  = new User("Adam Sandler", "adamsandler@golf.ball", "HappyGilmore");
        User kevin = new User("Kevin James",  "paulblart@cop.mall",    "MallCop");
        User chris = new User("Chris Rock",   "rock@chris.me",         "Comedian");

        Auction auction = new Auction(adam, "Golf stuff");
        auction.addBid(new Bid(kevin, 100));
        auction.addBid(new Bid(chris, 140));
        auction.addBid(new Bid(kevin, 200));

        System.out.println(auction.toString());
    }
}
