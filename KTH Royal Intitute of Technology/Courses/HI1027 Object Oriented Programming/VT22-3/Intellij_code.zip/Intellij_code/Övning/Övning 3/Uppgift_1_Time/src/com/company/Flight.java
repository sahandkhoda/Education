package com.company;

import java.util.Locale;

public class Flight
{
    /** PRIVATE FIELDS */
    private final String destination, flightNr;
    private final Time departureTime;

    /** CONSTRUCTORS */
    public Flight(String destination, String flightNr, int h, int m, int s) {
        this.destination   = destination.toUpperCase(Locale.ROOT);
        this.flightNr      = flightNr.toUpperCase(Locale.ROOT);
        this.departureTime = new Time(h, m, s);
    }

    public Flight(String destination, String flightNr, Time departureTime) {
        this.destination   = destination.toUpperCase(Locale.ROOT);
        this.flightNr      = flightNr.toUpperCase(Locale.ROOT);
        this.departureTime = departureTime;
    }

    /** ACCESS METHODS */
    public String getDestination() { return destination; }
    public String getFlightNr()    { return flightNr; }
    public Time   getDeparture()   { return new Time(departureTime.getHour(),
                                                     departureTime.getMin(),
                                                     departureTime.getSec());
    }

    @Override
    public String toString()
    {
        return "Flight " + getFlightNr() +
               " headed for " + getDestination()
             + " departures at [" + getDeparture().toString() + "]";
    }
}
