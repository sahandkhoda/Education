package com.company;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LoanManager implements ILoanManager
{
    /** CONSTRUCTOR */
    public LoanManager() {
        kayaks = new ArrayList<>();
        loans = new ArrayList<>();
    }

    /** PUBLIC METHODS */
    public void addKayak(Kayak newKayak) {
        if (!kayaks.contains(newKayak))
            kayaks.add(newKayak);
    }

    public void addLoan(Kayak kayak, Member borrower, LocalDate loanDate) {
        for (Loan loan : loans) {
            if (loan.getKayak().equals(kayak) && loan.getLoanDate().equals(loanDate)) {
                throw new IllegalLoanException
                        (kayak.getModel() + " unavailable [" + loanDate + "]");
            }
        }
        loans.add(new Loan(kayak, borrower, loanDate));
    }

    /** DATA FIELDS */
    private final List<Kayak> kayaks;
    private final List<Loan> loans;

    /** ACCESS METHODS */
    public List<Kayak> getKayaks() { return new ArrayList<>(kayaks); }
    public List<Loan>  getLoans()  { return new ArrayList<>(loans);  }

    public List<Loan>  getLoansFor(Kayak kayak) {
        List<Loan> loansForKayak = new ArrayList<>();
        for (Loan loan : loans) {
            if (loan.getKayak().equals(kayak)) {
                loansForKayak.add(loan);
            }
        }
        return loansForKayak;
    }

    public List<Kayak> getAvailableKayaks(LocalDate targetDate) {
        List<Kayak> availableKayaks = new ArrayList<>();
        for (Kayak kayak : kayaks) {
            boolean taken = false;
            for (Loan loan : loans) {
                if (loan.getKayak().equals(kayak) && loan.getLoanDate().isEqual(targetDate)) {
                    taken = true;
                    break;
                }
            }
            if (!taken) availableKayaks.add(kayak);
        }
        return availableKayaks;
    }

    @Override
    public String toString() {
        return "Total loans for" + "\n"
             + " * KAYAKS : " + kayaks.size() + "\n"
             + " * LOANS  : " + loans.size()  + "\n";
    }
}
