package com.company;

public enum Genre
{
    HORROR,
    ADVENTURE,
    ACTION,
    ROMANTIC,
    THRILLER,
    DRAMA,
    COMEDY
}
