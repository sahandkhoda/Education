package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println();

        // Destination
        System.out.print("Destination : ");
        String destination = scanner.nextLine();

        // Flight number
        System.out.print("Flight number : ");
        String flightNr = scanner.nextLine();

        // Departure time
        System.out.println("Departure time");
        System.out.print(" Hour : ");
        int hour = Integer.parseInt(scanner.nextLine());
        System.out.print(" Min  : ");
        int min  = Integer.parseInt(scanner.nextLine());
        System.out.print(" Sec  : ");
        int sec  = Integer.parseInt(scanner.nextLine());

        // Flight
        Flight f1 = new Flight(destination, flightNr, hour, min, sec);
        Flight f2 = new Flight(destination, flightNr, new Time(hour, min));

        System.out.println(f1.toString());
        System.out.println(f2.toString());
    }
}
