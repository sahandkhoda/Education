package com.company;

public class Pnr
{
    /** PRIVATE CONSTRUCTOR */
    private Pnr(String pnrStr) throws IllegalArgumentException {
        if (!pnrStr.matches(pnrPattern))
            throw new IllegalArgumentException("INVALID PNR");
        this.pnrStr = pnrStr;
    }

    /** STATIC CLASS METHOD */
    public static Pnr createPnr(String pnrStr) throws IllegalArgumentException {
        return new Pnr(pnrStr);
    }

    /** EQUALS METHOD */
    @Override
    public boolean equals(Object other) {
        if (other instanceof Pnr otherPnr) {
            return this.pnrStr.equals(otherPnr.pnrStr);
        }
        return false;
    }

    /** DATA FIELDS */
    private final String pnrStr;
    private static final String pnrPattern = "^(19|20)?[0-9]{6}[- ]?[0-9]{4}$";

    /** ACCESS METHODS */
    public String getPnr() { return pnrStr;}

    @Override
    public String toString() {
        return "SSN : " + getPnr();
    }
}
