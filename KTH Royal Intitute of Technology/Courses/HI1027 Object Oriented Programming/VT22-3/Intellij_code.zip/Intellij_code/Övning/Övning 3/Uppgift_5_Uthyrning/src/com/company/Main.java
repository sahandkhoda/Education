package com.company;

import java.time.LocalDate;
import java.util.List;

public class Main {

    public static void main(String[] args)
    {
        System.out.println();
        Member adam = new Member("Adam Sandler", Pnr.createPnr("19901201-1234"));
        System.out.println(adam.toString());

        Kayak k1 = new Kayak("K1", KLevel.BEGINNER, 1234, adam);
        Kayak k2 = new Kayak("K2", KLevel.ADVANCED, 5678, adam);

        LoanManager manager = new LoanManager();
        manager.addKayak(k1);
        manager.addKayak(k1);
        manager.addKayak(k2);
        System.out.println(manager.toString());

        List<Kayak> available = manager.getAvailableKayaks(LocalDate.now());
        System.out.println("=== Available today ===" + "\n" + available.toString());

        manager.addLoan(k1, adam, LocalDate.now());
    }
}
