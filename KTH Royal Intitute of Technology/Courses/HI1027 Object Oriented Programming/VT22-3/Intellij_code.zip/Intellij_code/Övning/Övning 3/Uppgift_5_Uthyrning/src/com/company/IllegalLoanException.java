package com.company;

public class IllegalLoanException extends RuntimeException
{
    public IllegalLoanException(String message)
    {
        super(message);
    }

    public IllegalLoanException() {}

}
