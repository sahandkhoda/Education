package com.sahand.kth.se_uppgift_5;

import java.util.Arrays;

public class GenericList<T>
{
    public GenericList(int capacity) {
        if (capacity<0) capacity = 10;
        arr = (T[]) new Object[capacity];
        nrOfStrings = 0;
    }
    public GenericList() { this(10); }

    public void add(T theObject) {
        if (nrOfStrings >= arr.length) resize();
        arr[nrOfStrings++] = theObject;
    }

    public void resize() {
        T[] temp = (T[]) new Object[arr.length*2];
        System.arraycopy(arr, 0, temp, 0, arr.length);
        arr = temp;
    }

    public void remove(int index) {
        for (int i = index; i<arr.length-1; i++) {
            arr[i] = arr[i+1];
        }
        nrOfStrings--;
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private T[] arr;
    private int nrOfStrings;

    public int size() { return arr.length; }
    public T get(int index) {
        if (index < 0 || index >= nrOfStrings) {
            throw new IndexOutOfBoundsException("Index : " + index);
        }
        return arr[index];
    }

    public String[] getArr() {
        String[] copy = new String[nrOfStrings+1];
        System.arraycopy(arr, 0, copy,0, arr.length);
        return copy;
    }

    @Override
    public String toString() {
        return "The String array is " + Arrays.toString(arr);
    }
}