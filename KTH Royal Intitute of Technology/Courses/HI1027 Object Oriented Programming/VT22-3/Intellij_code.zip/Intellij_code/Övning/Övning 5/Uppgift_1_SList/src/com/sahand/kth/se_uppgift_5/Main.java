package com.sahand.kth.se_uppgift_5;

public class Main {

    public static void main(String[] args)
    {
        GenericList g = new GenericList();
        g.add("Hej");
        g.add("Hur");
        g.add("Mår");
        g.add("Ni");
        g.add("Två?");
        g.remove(4);
        System.out.println(g.toString());
    }
}
