package com.sahand.kth.se.launch;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LaunchTest extends Application
{
    @Override
    public void start(Stage stage) throws Exception
    {
        Pane pane = new Pane();
        Scene scene = new Scene(pane, 350, 300);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("A L E R T");
        alert.setHeaderText("THIS IS THE MESSAGE");
        alert.setContentText("Specific information...");
        alert.show();

        stage.setTitle("L A U N C H E R");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) { launch(); }
}
