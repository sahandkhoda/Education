module com.sahand.kth.se.launch {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.sahand.kth.se.launch to javafx.fxml;
    exports com.sahand.kth.se.launch;
}