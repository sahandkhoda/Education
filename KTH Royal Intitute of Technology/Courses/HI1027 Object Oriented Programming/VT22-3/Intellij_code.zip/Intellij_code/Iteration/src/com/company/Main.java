package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        int[] aArray = new int[5];
        Scanner number = new Scanner(System.in);

        System.out.print("\n");
        for (int counter=0 ; counter < aArray.length ; counter++)
        {
            System.out.print(" #" + (counter+1) + " Enter number : ");
            int value = number.nextInt();
            aArray[counter] = value;
        }

        int sum = 0;
        for (int counter : aArray)
            sum += counter;
        System.out.println("__________");
        System.out.println("Total : " + sum + "");
    }
}
