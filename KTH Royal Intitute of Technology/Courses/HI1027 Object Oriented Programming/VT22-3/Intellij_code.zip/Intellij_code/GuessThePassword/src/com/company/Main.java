package com.company;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        // Läs in lösenord
        System.out.print("\n");
        System.out.print("Enter password   : ");
        Scanner scanPassword = new Scanner(System.in);
        String myPassword1 = scanPassword.nextLine();
        String myPassword2;

        // Kontrollera lösenord
        Boolean check;
        do
        {
            // Läs in lösenord igen
            System.out.print("Confirm password : ");
            Scanner confirmPassword = new Scanner(System.in);
            myPassword2 = confirmPassword.nextLine();

            check = myPassword1.equals(myPassword2);
            if (check == true) System.out.println("CORRECT");
            else System.out.println("ERROR");

        } while (check == false);

        // Om rätt lösenord, spara.
        String savePassword = myPassword2.toUpperCase(Locale.ROOT);
        System.out.println("Saved password : " + savePassword);
    }
}
