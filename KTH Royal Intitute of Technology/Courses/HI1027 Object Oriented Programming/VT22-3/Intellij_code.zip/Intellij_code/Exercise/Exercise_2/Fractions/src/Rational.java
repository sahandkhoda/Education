public class Rational {

    /** PRIVATE DATA FIELDS */

    private final int NUM, DEN;                         // Original
    private int numerator, denominator;                 // Modifiable
    private int factor;                                 // Common factor


    /** CONSTRUCTORS */

    public Rational(int numerator, int denominator) {

        if (denominator == 0)
            throw new IllegalArgumentException("ERROR: Denominator ZERO is undefined!");

        this.NUM = numerator;
        this.DEN = denominator;
        this.numerator = numerator;
        this.denominator = denominator;
        this.factor = 1;
        modify();
    }

    public Rational(int numerator) {
        this(numerator, 1);
    }

    public Rational() {
        this(0, 1);
    }


    /** PUBLIC OPERATION */

    public Rational add(Rational other) {
        int num = this.getNUM() * other.getDEN() + this.getDEN() * other.getNUM();
        int den = this.getDEN() * other.getDEN();
        return new Rational(num, den);
    }


    /** PRIVATE HELP METHODS */

    private double getFraction(Rational rational) {
        return (double) rational.getNumerator() / rational.getDenominator();
    }

    private void modify() {
        int j = Math.min(numerator, denominator);               // Highest possible common factor

        for (int i = 1; i <= j; i++) {
            if (numerator % i == 0 && denominator % i == 0) {
                factor = i;
            }
        }

        numerator   /= factor;
        denominator /= factor;
    }

    private String fractionFormat() {
        return String.format("%.2f", getFraction(this));
    }


    /** ACCESS METHODS */

    public int getNUM() {
        return NUM;
    }

    public int getDEN() {
        return DEN;
    }

    public int getNumerator() {
        return numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    public int getFactor() {
        return factor;
    }

    @Override
    public String toString() {
        return  "Fraction : "  + getNUM() + "/" + getDEN() + " = " + numerator + "/" + denominator + " = " + fractionFormat()
                + "\n"
                + "Least common factor : " + getFactor();
    }
}
