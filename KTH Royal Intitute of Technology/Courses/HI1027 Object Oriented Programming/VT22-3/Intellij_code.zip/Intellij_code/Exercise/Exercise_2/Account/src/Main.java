import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanS = new Scanner(System.in);
        Scanner scanD = new Scanner(System.in);
        ListOfAccounts list = new ListOfAccounts();

        String choice;
        do {
            System.out.print("Enter full name : ");
            String name = scanS.nextLine();
            System.out.print("Enter balance   : ");
            double balance = scanD.nextDouble();
            list.addAccount(new Account(name, balance));

            System.out.print("Do you want to add another account? (y/n) : ");
            choice = scanS.nextLine();
        } while (choice.equals("y"));

        list.addAccount(new Account("Adam Sandler", 1000));
        list.addAccount(new Account("Kevin James",  40));
        list.addAccount(new Account("Chris Rock",   500));

        System.out.println();
        System.out.print("Search name : ");
        ArrayList<Account> foundList = list.findAccount(scanS.nextLine());
        for (Account account : foundList) {
            System.out.println(account.getFullName());
        }


    }
}