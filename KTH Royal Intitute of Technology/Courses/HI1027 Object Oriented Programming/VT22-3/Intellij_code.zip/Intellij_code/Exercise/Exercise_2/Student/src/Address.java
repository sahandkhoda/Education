public class Address {

    /** PRIVATE FIELDS */

    private String street, city;


    /** CONSTRUCTOR */

    public Address(String street, String city) {
        this.street = street.toUpperCase();
        this.city = city.toUpperCase();
    }


    /** SET METHODS */

    public void setStreet(String newStreet) {
        street = newStreet.toUpperCase();
    }

    public void setCity(String newCity) {
        city = newCity.toUpperCase();
    }


    /** GET METHODS */

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }


    /** ACCESS METHOD */

    @Override
    public String toString() {
        return "Address : " + getStreet() + ", " + getCity() + "\n";
    }
}