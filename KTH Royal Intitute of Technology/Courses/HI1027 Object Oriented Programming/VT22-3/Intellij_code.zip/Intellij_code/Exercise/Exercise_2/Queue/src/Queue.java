import java.util.Arrays;

public class Queue {

    /** PRIVATE DATA FIELDS */

    private int SIZE, ELEMENTS;
    private String[] queue;


    /** CONSTRUCTOR */

    public Queue(int SIZE) {
        this.SIZE = SIZE;
        this.ELEMENTS = 0;
        this.queue = new String[SIZE];
    }

    public Queue() {
        this(10);
    }


    /** PUBLIC OPERATIONS */

    public void enqueue(String s) {
        if (ELEMENTS >= SIZE)
            resize();

        queue[ELEMENTS++] = s;
    }

    public String dequeue() {
        String dequeued = queue[0];
        if (!isEmpty()){
            --ELEMENTS;
            queue[0] = null;
            resize();
        }
        return dequeued;
    }

    public void clear() {
        int j=SIZE;
        for (int i=0; i<j; i++) {
            dequeue();
        }
    }

    public boolean isEmpty() {
        for (String s : queue) {
            if (s != null) {
                return false;
            }
        }
        return true;
    }

    public String peek() {
        return queue[0];
    }


    /** PRIVATE HELP METHOD */

    private void resize() {

        String[] temp;

        if (ELEMENTS >= SIZE) {
            temp = new String[++SIZE];
            System.arraycopy(queue, 0, temp, 0, queue.length);
        }

        else {
            temp = new String[--SIZE];
            System.arraycopy(queue, 1, temp, 0, temp.length);
        }

        queue = new String[temp.length];
        System.arraycopy(temp, 0, queue, 0, temp.length);
    }


    /** ACCESS METHODS */

    public int getSIZE() {
        return SIZE;
    }

    public int getELEMENTS() {
        return ELEMENTS;
    }

    public String[] getQueue() {
        return Arrays.copyOf(queue, queue.length);
    }

    @Override
    public String toString() {
        return  "\n" +
                "QUEUE : " + Arrays.toString(queue) + "\n" +
                "Empty : " + isEmpty();
    }
}
