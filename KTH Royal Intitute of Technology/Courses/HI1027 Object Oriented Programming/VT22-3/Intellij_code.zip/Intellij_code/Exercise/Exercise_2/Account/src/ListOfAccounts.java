import java.util.ArrayList;

public class ListOfAccounts {

    /** PRIVATE DATA FIELD */

    private final ArrayList<Account> list;


    /** CONSTRUCTOR */

    public ListOfAccounts() {
        this.list = new ArrayList<>();
    }

    public void addAccount(Account newAccount) {
        list.add(newAccount);
    }


    /** OPERATIONS */

    public void removeAccount(int index) {
        list.remove(index);
    }

    public ArrayList<Account> findAccount(String name) {
        ArrayList<Account> foundAccounts = new ArrayList<>();
        System.out.println("Found accounts :");
        for (Account account : list) {
            if (account.getFullName().contains(name.toUpperCase())) {
                foundAccounts.add(account);
            }
        }
        return foundAccounts;
    }

    /** GET METHODS */

    public ArrayList<Account> getList() {
        return new ArrayList<Account>(list);
    }

    public int getListSize() {
        return list.size();
    }
}
