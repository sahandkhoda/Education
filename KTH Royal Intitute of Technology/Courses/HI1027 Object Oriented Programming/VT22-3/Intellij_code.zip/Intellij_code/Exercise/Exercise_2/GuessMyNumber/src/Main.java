import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanI = new Scanner(System.in);
        Scanner scanS = new Scanner(System.in);

        System.out.print("Enter MAX : ");
        GuessMyNumberModel model = new GuessMyNumberModel(scanI.nextInt());

        String again;
        do {
            // Initialize new game (same MAX)
            model.initGame();

            // Guess until correct
            int guess;
            do {
                System.out.print("\n" + "Make a guess [1..." + model.getMAX() + "] : ");
                guess = scanI.nextInt();
                model.setGuess(guess);
                System.out.println("Your guess is " + model.compareGuessToString());
            } while (guess != model.getSecret());

            // Play again?
            System.out.print("\n" +"Play again? (y/n) : ");
            again = scanS.nextLine();

        } while (!again.equals("n"));



    }
}