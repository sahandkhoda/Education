import java.util.Scanner;

public class UserInterface {

    /** Scanner for INT and STRING */

    Scanner scanI = new Scanner(System.in);
    Scanner scanS = new Scanner(System.in);


    /** PRIVATE FIELDS */

    private final ListOfPersons list;
    private String name;
    private int    age;
    private String street;
    private String city;


    /** CONSTRUCTOR */

    public UserInterface() {
        this.list = new ListOfPersons();

        do {
            menu();
            enterRole();
        } while (addMore().equals("y"));

        list.printList();
    }


    /** OPERATIONS */

    private void menu() {
        System.out.println(
                """
                        
                        ------ MENU ------
                        Select one of the following roles [1-3] :
                         (1) Principal
                         (2) Teacher
                         (3) Student
                        ------------------"""
        );
    }

    private void enterRole() {
        int i;
        do {
            System.out.print("Enter role : ");
            i = scanI.nextInt();
            switch (i) {
                case 1 -> addPrincipal();
                case 2 -> addTeacher();
                case 3 -> addStudent();
                default -> {
                    System.out.println("Please enter valid role [1-3]!\n");
                    i = 0;
                }
            }
        } while (i == 0);
    }

    private String addMore() {
        System.out.print("Add more? (y/n) : ");
        return scanS.nextLine();
    }


    private void enterInfo() {
        System.out.print("Name       : "); name   = scanS.nextLine();
        System.out.print("Age        : "); age    = scanI.nextInt();
        System.out.print("Street     : "); street = scanS.nextLine();
        System.out.print("City       : "); city   = scanS.nextLine();
    }

    private void addPrincipal() {
        enterInfo();
        System.out.print("Salary [$] : ");
        int salary = scanI.nextInt();
        System.out.print("Section    : ");
        String section = scanS.nextLine();
        list.addPrincipal(new Principal(name, age, street, city,
                salary, section));
    }

    private void addTeacher() {
        enterInfo();
        System.out.print("Salary [$] : ");
        int salary = scanI.nextInt();
        System.out.print("Subject    : ");
        String subject = scanS.nextLine();
        list.addTeacher(new Teacher(name, age, street, city,
                salary, subject));
    }

    private void addStudent() {
        enterInfo();
        System.out.print("Program    : ");
        String program = scanS.nextLine();
        System.out.print("Credit     : ");
        int credit = scanI.nextInt();
        list.addStudent(new Student(name, age, street, city,
                program, credit));
    }
}
