import java.util.Random;

public class Account {

    /** PRIVATE DATA FIELDS */
    private final long accountNumber;
    private final String fullName;
    private double balance;


    /** CONSTRUCTOR */

    public Account(String fullName, double balance) {

        if (fullName.length() == 0)
            throw new IllegalArgumentException("Enter a valid name.");
        if (balance < 0)
            throw new IllegalArgumentException("Enter a valid balance [$].");

        this.fullName = fullName.toUpperCase();
        this.balance = balance;

        accountNumber = generateAccNr();
    }

    /** OPERATIONS */

    private long generateAccNr() {
        Random random = new Random();
        return random.nextInt(100000, 999999);
    }

    public void deposit(int amount) {
        if (amount<0)
            throw new IllegalArgumentException("ERROR: Negative amount!\n");
        this.balance += amount;
    }

    public void withdraw(int amount) {
        if (amount<0 || amount>balance)
            throw new IllegalArgumentException("ERROR: Invalid amount!\n");
        balance -= amount;
    }

    /** GET METHODS */

    public String getFullName() {
        return fullName;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }


    /** ACCESS METHODS */

    @Override
    public String toString() {
        return  "ACCOUNT NUMBER (" + getAccountNumber() + ")\n" +
                "NAME : " + getFullName() + "\n" +
                "BALANCE : " + getBalance();
    }
}
