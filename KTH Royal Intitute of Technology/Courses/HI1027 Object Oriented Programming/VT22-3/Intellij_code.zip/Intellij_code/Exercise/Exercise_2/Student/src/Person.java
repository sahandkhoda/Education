abstract public class Person {

    /** PRIVATE FIELDS */

    private final Address address;

    private final String name;
    private final int age;


    /** CONSTRUCTOR */

    public Person(String name, int age, String street, String city) {
        this.name = name.toUpperCase();
        this.age  = age;
        address = new Address(street, city);
    }

    /** GET METHODS */

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public Address getAddress() {
        return new Address(address.getStreet(), address.getCity());
    }

    /** ACCESS METHOD */

    @Override
    public String toString() {
        return  "\n" +
                "Name    : " + getName() + "\n" +
                "Age     : " + getAge()  + "\n" +
                getAddress().toString();
    }



}
