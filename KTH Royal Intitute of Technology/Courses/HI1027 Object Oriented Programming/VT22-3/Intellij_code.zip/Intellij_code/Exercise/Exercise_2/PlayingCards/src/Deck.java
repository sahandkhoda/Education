import java.util.ArrayList;

public class Deck {

    private final ArrayList<ICard> deck;                 // (Shared) Aggregation

    public Deck() {
        deck = new ArrayList<>();
        fill();
        shuffle();
    }

    /** METHODS */
    public void fill() {
        for (Rank rank : Rank.values()) {
            for (Suit suit : Suit.values()) {
                deck.add(new ICard(rank, suit));
            }
        }
    }

    public void shuffle() {

    }

    public ICard dealCard() {
        return null;
    }

    /** ACCESS METHODS */
    public ArrayList<ICard> getDeck() {
        return new ArrayList<ICard>(deck);
    }

    public int getDeckSize() {
        return deck.size();
    }

    @Override
    public String toString() {
        return "Number of cards in deck : " + getDeckSize() + "\n";
    }
}
