public class Main {
    public static void main(String[] args) {

        Rational r1 = new Rational(10,12);
        Rational r2 = new Rational(5,6);
        Rational r4 = r1.add(r2);
        System.out.println(r4.toString());


    }
}