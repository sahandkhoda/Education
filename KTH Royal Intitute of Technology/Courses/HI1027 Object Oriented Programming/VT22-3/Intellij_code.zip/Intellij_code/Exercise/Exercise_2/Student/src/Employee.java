abstract public class Employee extends Person {

    /** PRIVATE FIELDS */

    private final int salary;


    /** CONSTRUCTOR */

    public Employee(String name, int age, String street, String city,
                    int salary) {
        super(name, age, street, city);
        this.salary = salary;
    }


    /** GET METHODS */

    public int getSalary() {
        return salary;
    }


    /** ACCESS METHOD */

    @Override
    public String toString() {
        return super.toString();
    }

}
