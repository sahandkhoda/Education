import java.util.ArrayList;

public class ListOfPersons {

    /** DATA FIELDS */

    public ArrayList<Person> listP, listT, listS;


    /** CONSTRUCTOR */

    public ListOfPersons() {
        listP = new ArrayList<>();
        listT = new ArrayList<>();
        listS = new ArrayList<>();
    }


    /** OPERATIONS */

    public void addPrincipal(Person principal) {
        listP.add(principal);
    }

    public void addTeacher(Person teacher) {
        listT.add(teacher);
    }

    public void addStudent(Person student) {
        listS.add(student);
    }



    /** GET METHODS */

    public ArrayList<Person> getListP() {
        return new ArrayList<>(listP);
    }

    public ArrayList<Person> getListT() {
        return new ArrayList<>(listT);
    }

    public ArrayList<Person> getListS() {
        return new ArrayList<>(listS);
    }

    public int getSizeP() {
        return listP.size();
    }

    public int getSizeT() {
        return listT.size();
    }

    public int getSizeS() {
        return listS.size();
    }


    /** ACCESS METHODS */

    public void printList() {
        System.out.println("\n");
        System.out.println("----------------------\n");
        int i=1;
        for (Person person : listP) {
            System.out.println(
                    "--- (Principal " + i++ + " of " + getSizeP() + ") ---" +
                            person.toString());
        }

        int j=1;
        for (Person person : listT) {
            System.out.println(
                    "--- (Teacher " + j++ + " of " + getSizeT() + ") ---" +
                            person.toString());
        }

        int k=1;
        for (Person person : listS) {
            System.out.println(
                    "--- (Student " + k++ + " of " + getSizeS() + ") ---" +
                            person.toString());
        }
    }

    @Override
    public String toString() {
        return   "THE LIST"  + "\n"
                + getListP() + "\n"
                + getListT() + "\n"
                + getListS() + "\n";
    }
}
