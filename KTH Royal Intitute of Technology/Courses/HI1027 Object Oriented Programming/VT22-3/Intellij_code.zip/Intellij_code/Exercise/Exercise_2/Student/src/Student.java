public class Student extends Person {

    /** PRIVATE FIELDS */

    protected String program;
    protected double credit;


    /** CONSTRUCTOR */

    public Student(String name, int age, String street, String city,
                   String program, double credit) {
        super(name, age, street, city);
        this.program = program.toUpperCase();
        this.credit = credit;
    }


    /** OPERATIONS */

    public void addCredit(int amount) {
        if (amount<=0)
            throw new IllegalArgumentException("Credit is not valid!");

        credit += amount;
    }

    public void setProgram(String newProgram) {
        program = newProgram;
    }


    /** GET METHODS */

    public Role getRole() {
        return Role.Student;
    }

    public String getProgram() {
        return program;
    }

    public double getCredit() {
        return credit;
    }


    /** ACCESS METHOD */

    @Override
    public String toString() {
        return  super.toString() +
                "Role    : " + getRole()    + "\n" +
                "Program : " + getProgram() + "\n" +
                "Credit  : " + getCredit()  + "\n";
    }

}
