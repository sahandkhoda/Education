public class PlayICards {

    public PlayICards() {

        ICard c1 = new ICard(Rank.ACE, Suit.HEARTS);
        ICard c2 = new ICard(Rank.ACE, Suit.CLUBS);
        System.out.println(c1.toString());
        System.out.println(c2.toString());
        System.out.println(c1.equals(c2));



    }
}
