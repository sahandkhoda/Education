import java.util.Random;

public class GuessMyNumberModel {

    /** PRIVATE DATA FIELDS */

    private final int MAX;
    private final Random random;
    private int secret, guess, nrOfGuesses;

    /** CONSTRUCTORS */

    public GuessMyNumberModel(int MAX) {
        if (MAX<2) MAX = 10;
        this.MAX = MAX;
        random = new Random();
    }

    public GuessMyNumberModel() {
        this(10);
    }

    /** PRIVATE HELP METHODS */

   private int compareGuess() {
        return Integer.compare(guess, secret);
    }

    public String compareGuessToString() {
        if (compareGuess() < 0) {
            return "too low ...";
        }

        else if (compareGuess() > 0) {
            return "too high ...";
        }

        else {
            return "CORRECT";
        }
    }


    /** PUBLIC OPERATION */

    public void initGame() {
        secret = random.nextInt(1,MAX);
        nrOfGuesses = 0;
    }

    public void setGuess(int guess) {
        this.guess = guess;
        nrOfGuesses++;
    }


    /** ACCESS METHODS */

    public int getMAX() {
        return MAX;
    }

    public int getSecret() {
        return secret;
    }

    public int getGuess() {
        return guess;
    }

    public int getNrOfGuesses() {
        return nrOfGuesses;
    }

    @Override
    public String toString() {
        return  "Guess is " + compareGuessToString();
    }
}
