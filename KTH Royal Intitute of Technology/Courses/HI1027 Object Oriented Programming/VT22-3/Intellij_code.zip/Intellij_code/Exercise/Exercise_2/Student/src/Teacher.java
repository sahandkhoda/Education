public class Teacher extends Employee {

    /** PRIVATE FIELDS */

    private final String subject;


    /** CONSTRUCTOR */

    public Teacher(String name, int age, String street, String city,
                   int salary, String subject) {
        super(name, age, street, city, salary);this.subject = subject;
    }


    /** GET METHODS */

    public Role getRole() {
        return Role.Teacher;
    }

    public String getSubject() {
        return subject;
    }


    /** ACCESS METHOD */

    @Override
    public String toString() {
        return  super.toString() +
                "Role    : " + getRole()         + "\n" +
                "Salary  : " + super.getSalary() + "\n" +
                "Subject : " + getSubject()      + "\n";
    }

}