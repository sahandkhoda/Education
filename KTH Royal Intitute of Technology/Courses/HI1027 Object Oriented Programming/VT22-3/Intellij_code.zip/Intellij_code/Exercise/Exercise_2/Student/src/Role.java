public enum Role {

    Principal (1),
    Teacher   (2),
    Student   (3);

    private final int value;

    Role(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
