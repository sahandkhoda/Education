public class Main {
    public static void main(String[] args) {

        Queue queue = new Queue(1);
        queue.enqueue("Hello");
        queue.enqueue("my");
        queue.enqueue("name");
        queue.enqueue("is");
        queue.enqueue("Sahand");

        //queue.clear();

        System.out.println(queue.toString());

        String s = queue.dequeue();
        System.out.println("Dequeued : " + s);
    }
}