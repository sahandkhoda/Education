public enum Suit {

    HEARTS   ('H'),
    DIAMONDS ('D'),
    CLUBS    ('C'),
    SPADES   ('S');

    private final char suit;

    private Suit(char suit) {
        this.suit = suit;
    }

    public char getSuit() {
        return this.suit;
    }
}
