import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ArrayList<PostIt> list = new ArrayList<>();

        // Scanner for STRING
        Scanner scanS = new Scanner(System.in);

        // PostIt object
        PostIt postIt;

        // New PostIt choice
        String choiceP;
        System.out.print("New Post It? (y/n) : ");
        choiceP = scanS.nextLine();

        while (choiceP.equals("y")) {

            // First note
            postIt = new PostIt();
            System.out.print("New note : ");
            postIt.append(scanS.nextLine());

            // Additional notes
            String choiceN;
            System.out.print("Add note? (y/n) : ");
            choiceN = scanS.nextLine();
            while (choiceN.equals("y")) {
                System.out.print("Note : ");
                postIt.append(scanS.nextLine());
                System.out.print("Add another note? (y/n) : ");
                choiceN = scanS.nextLine();
            }

            // Adds the PostIt object to the LIST
            list.add(postIt);
            System.out.print("New Post It? (y/n) : ");
            choiceP = scanS.nextLine();
        }

        System.out.println();
        for (PostIt p : list) {
            System.out.println(p.toString());
        }
    }
}