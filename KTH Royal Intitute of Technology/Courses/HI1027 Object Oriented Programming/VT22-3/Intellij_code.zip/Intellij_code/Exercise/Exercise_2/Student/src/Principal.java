public class Principal extends Employee {

    /** PRIVATE FIELDS */

    private final String section;


    /** CONSTRUCTOR */

    public Principal(String name, int age, String street, String city,
                     int salary,
                     String section) {
        super(name, age, street, city, salary);
        this.section = section;
    }


    /** GET METHODS */

    public Role getRole() {
        return Role.Principal;
    }

    public String getSection() {
        return section;
    }


    /** ACCESS METHOD */

    @Override
    public String toString() {
        return  super.toString() +
                "Role    : " + getRole()         + "\n" +
                "Salary  : " + super.getSalary() + "\n" +
                "Section : " + getSection()      + "\n";
    }
}
