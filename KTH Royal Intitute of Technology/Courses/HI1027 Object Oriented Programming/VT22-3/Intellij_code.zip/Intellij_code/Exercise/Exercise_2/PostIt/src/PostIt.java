import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PostIt {

    /** PRIVATE DATA FIELDS */
    private static int totalNumbers = 1;
    private LocalDateTime originalDateTime;
    private String note;
    private final int y, m, d, number;


    /** CONSTRUCTOR */
    public PostIt(String note, LocalDateTime originalDateTime) {

        this.number = totalNumbers++;

        this.originalDateTime = originalDateTime;
        this.y = originalDateTime.getYear();
        this.m = originalDateTime.getMonthValue();
        this.d = originalDateTime.getDayOfMonth();
        this.note = note + "\n";
    }

    public PostIt(String note) {
        this(note, LocalDateTime.now());
    }

    public PostIt() {
        this("", LocalDateTime.now());
    }

    /** OPERATION */

    public void append(String newNote) {
        note += "\n" + newNote;
    }


    /** GET METHOD */

    public static int getTotalNumbers() {
        return totalNumbers;
    }

    public int getNumber() {
        return number;
    }

    public String getNote() {
        return note;
    }

    public String generateDateTime(LocalDateTime date) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("E, MMM dd yyyy (HH:mm:ss)");
        return date.format(dateFormatter);
    }

    private LocalDateTime getOriginalDateTime() {
        return originalDateTime;
    }

    private LocalDateTime getUpdatedDateTime() {
        return LocalDateTime.now();
    }

    public int getY() {
        return y;
    }

    public int getM() {
        return m;
    }

    public int getD() {
        return d;
    }

    /** ACCESS METHOD */

    @Override
    public String toString() {
        return  "----- POST-IT " + getNumber() + " -----\n" +
                generateDateTime(getOriginalDateTime()) +
                getNote() + "\n\n" +
                "Last updated : " + generateDateTime(getUpdatedDateTime()) + "\n";
    }
}
