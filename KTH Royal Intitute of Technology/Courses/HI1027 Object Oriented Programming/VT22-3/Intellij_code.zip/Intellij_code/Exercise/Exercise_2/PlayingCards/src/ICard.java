public class ICard {

    /** PRIVATE DATA FIELDS */

    private final Rank rank;
    private final Suit suit;


    /** CONSTRUCTOR */

    public ICard(Rank rank, Suit suit) {
        this.rank = rank;
        this.suit = suit;
    }


    /** OPERATIONS */

    public boolean equals(ICard other) {
        return (this.getRank() == other.rank && this.getSuit() == other.suit);
    }

    public int compareRank(ICard other) {
        return this.getRankValue() - other.getRankValue();
    }

    /** GET METHODS */
    public Rank getRank() {
        return rank;
    }

    public int getRankValue() {
        return rank.ordinal();
    }

    public Suit getSuit() {
        return suit;
    }

    public int getSuitValue() {
        return suit.ordinal();
    }

    /** ACCESS METHOD */

    @Override
    public String toString() {
        return  getRank().toString() + " of " + getSuit().toString();
    }
}
