public class Main {
    public static void main(String[] args) {

        PlayICards pCard = new PlayICards();

    }
}