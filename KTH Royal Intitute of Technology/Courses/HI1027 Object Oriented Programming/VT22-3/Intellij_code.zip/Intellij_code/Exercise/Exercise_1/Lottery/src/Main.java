import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        final int SELECTED = 7, MAX = 35;
        final int[] row = new int[SELECTED];
        final boolean[] unique = new boolean[MAX];

        for (int i=0; i<row.length; i++) {
            int number;
            do {
                number = (int) (Math.random() * MAX + 1);   // Generate random number...
            } while (unique[number-1]);                     // ... must be a unique number

            unique[number-1] = true;                        // Update condition
            row[i] = number;                                // Assign lottery number
        }

        System.out.println(Arrays.toString(row));
    }
}