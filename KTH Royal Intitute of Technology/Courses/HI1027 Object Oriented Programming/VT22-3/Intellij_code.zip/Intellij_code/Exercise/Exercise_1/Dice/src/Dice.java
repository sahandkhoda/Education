public class Dice {

    /** PRIVATE DATA FIELDS */

    private static int number = 1;

    private int value;
    private final int THROWS, diceNumber;
    private final int[] freq;


    /** CONSTRUCTOR */

    public Dice(int THROWS) {
        this.value = 1;
        this.THROWS = THROWS;
        this.diceNumber = number++;
        this.freq = new int[6];
    }


    /** PUBLIC OPERATION */

    public void throwDice() {
        for(int i=0; i<THROWS; i++) {
            value = (int) ( Math.random() * 6 + 1);
            freq[value-1]++;
        }
    }


    /** ACCESS METHODS */

    // Value of specific throw
    public int getValue(int dice) {
        return freq[dice-1];
    }

    // Value of latest throw
    public int getValue() {
        return value;
    }

    public int getDiceNumber() {
        return diceNumber;
    }

    public int[] getFreq() {
        int[] copy = new int[THROWS];
        System.arraycopy(freq, 0, copy, 0, freq.length);
        return copy;
    }

    @Override
    public String toString() {
        return "DICE " + getDiceNumber() + " FREQUENCIES\n" +
                " ONE   : " + freq[0] + "\n" +
                " TWO   : " + freq[1] + "\n" +
                " THREE : " + freq[2] + "\n" +
                " FOUR  : " + freq[3] + "\n" +
                " FIVE  : " + freq[4] + "\n" +
                " SIX   : " + freq[5] + "\n";
    }
}
