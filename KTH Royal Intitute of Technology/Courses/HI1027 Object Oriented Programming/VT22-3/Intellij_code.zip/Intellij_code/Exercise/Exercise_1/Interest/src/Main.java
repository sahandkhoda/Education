import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanD = new Scanner(System.in);

        final double RATE1 = 0.5 / 100;
        final double RATE2 = 2.5 / 100;
        final double THRESHOLD = 100_000.0;
        double interest;

        System.out.print("Enter balance : ");
        double balance = scanD.nextDouble();

        if (balance <= 0) {
            interest = 0.0;
        } else if (balance > 0 && balance < THRESHOLD) {
            interest = RATE1;
        } else {
            interest = RATE2;
        }

        System.out.println("BALANCE  : " + balance + "$");
        System.out.println("INTEREST : " + interest*100 + "%");
    }
}