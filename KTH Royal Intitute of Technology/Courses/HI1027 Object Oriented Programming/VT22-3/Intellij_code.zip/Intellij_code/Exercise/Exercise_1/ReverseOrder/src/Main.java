import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanI = new Scanner(System.in);

        System.out.println();
        System.out.print("How many numbers? : ");
        int[] numbers = new int[scanI.nextInt()];

        System.out.println();
        System.out.println("ENTER NUMBER");
        for (int i=0; i<numbers.length; i++) {
            System.out.print("#" + (i+1) + " : ");
            numbers[i] = scanI.nextInt();
        }

        System.out.println();
        System.out.println("REVERSED ORDER");
        for (int i=numbers.length-1; i>=0; i--) {
            System.out.print("#" + (i+1) + " : ");
            System.out.println(numbers[i]);
        }
    }
}