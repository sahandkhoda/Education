import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanI = new Scanner(System.in);

        System.out.println("How many times do you wish to throw each dice? [1-1000]");
        System.out.print("Dice 1 : "); int THROWS1 = scanI.nextInt();
        System.out.print("Dice 2 : "); int THROWS2 = scanI.nextInt();
        System.out.println();

        Dice d1 = new Dice(THROWS1);    d1.throwDice();
        Dice d2 = new Dice(THROWS2);    d2.throwDice();

        System.out.println(d1.toString());
        System.out.println(d2.toString());

    }
}