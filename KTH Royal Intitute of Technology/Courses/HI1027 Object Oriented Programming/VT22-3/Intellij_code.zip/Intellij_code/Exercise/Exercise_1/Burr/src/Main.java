import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanI = new Scanner(System.in);

        int burr;
        do {
            System.out.print("Enter BURR-number [2-9] : ");
            burr = scanI.nextInt();
        } while (burr < 2 || burr > 9);

        for (int i = 1; i < 100; i++) {

            // Evenly dividable with the BURR-number
            if (i % burr == 0) {
                System.out.print("XX  ");
            }

            // Starts with the BURR-number
            else if (i / 10 == burr) {
                System.out.print("XX  ");
            }

            // Ends with the BURR-number
            else if (i % 10 == burr) {
                System.out.print("XX  ");
            }

            // Else ...
            else {
                System.out.printf("%02d  ", i);
            }

            // For every 9th number, print a new line.
            if (i % 9 == 0) {
                System.out.print("\n");
            }
        }

    }
}