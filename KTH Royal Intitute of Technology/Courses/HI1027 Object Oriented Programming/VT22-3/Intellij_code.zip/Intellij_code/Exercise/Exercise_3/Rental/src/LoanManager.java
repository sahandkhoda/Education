import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LoanManager implements ILoanManager {

    private final ArrayList<Kayak> kayaks;
    private final ArrayList<Loan> loans;

    public LoanManager() {
        kayaks = new ArrayList<Kayak>();
        loans = new ArrayList<Loan>();
    }

    @Override
    public List<Kayak> getKayaks() {
        return new ArrayList<>(kayaks);
    }

    @Override
    public List<Loan> getLoans() {
        return new ArrayList<>(loans);
    }

    @Override
    public void addKayak(Kayak kayak) {

        // Use method "if(!kayaks.contains(kayak))" ...

        for (Kayak k : kayaks) {

            if (k.getModel().equals(kayak.getModel())) {

                if (k.getLevel().getLevelStr().equals(kayak.getLevel().getLevelStr())) {

                    if (k.getNumber() == kayak.getNumber()) {

                        if (k.getCaretaker().getPnr().getPnrStr().equals(kayak.getCaretaker().getPnr().getPnrStr())) {

                            return;

                        }
                    }
                }
            }
        }

        kayaks.add(kayak);

    }

    @Override
    public void addLoan(Member borrower, Kayak kayak, LocalDate loanDate) throws IllegalStateException {

        if (!kayaks.contains(kayak)) {
            throw new IllegalStateException( "The kayak is not found on the list.");
        }

        for (Loan loan : loans) {
            if (loan.getKayak().equals(kayak) && loan.getLoanDate().equals(loanDate)) {
                throw new IllegalStateException("Kayak #" + kayak.getNumber() + " is not available for booking on " + loanDate + ".");
            }
        }

        loans.add(new Loan(borrower, kayak, loanDate));
    }

    @Override
    public List<Loan> getLoansFor(Kayak kayak) {

        if (!kayaks.contains(kayak)) {
            throw new IllegalStateException("The kayak is not found on the list.");
        }

        List<Loan> loansForKayak = new ArrayList<>();

        for (Loan loan : loans) {

            if (loan.getKayak().equals(kayak)) {

                loansForKayak.add(loan);

            }
        }

        return loansForKayak;
    }

    @Override
    public List<Kayak> getAvailableKayaks(LocalDate targetDate) {

        List<Kayak> available = new ArrayList<>();

        for (Kayak kayak : kayaks) {

            boolean taken = false;
            for (Loan loan : loans) {
                if (kayak.equals(loan.getKayak()) && loan.getLoanDate().equals(targetDate)) {
                    taken = true;
                    break;
                }
            }

            if (!taken) {
                available.add(kayak);
            }
        }

        return available;
    }

    @Override
    public String toString() {
        return  "=== LOAN MANAGER ===" + "\n" +
                "Number of kayaks : " + getKayaks().size() + "\n" +
                "Number of loans  : " + getLoans().size();
    }
}
