public class Pnr {

    /** PRIVATE DATA FIELDS */

    private final String pnrStr;
    private static final String pnrPattern = "^(19|20)?[0-9]{6}[- ]?[0-9]{4}$";


    /** PRIVATE CONSTRUCTOR */

    private Pnr(String pnrStr) {
        this.pnrStr = pnrStr;
    }


    /** PUBLIC STATIC METHOD
     * <p>
     * Use this method to create a new instance.
     * (There are no public constructors, because constructors throwing exceptions should be avoided.)
     * @param pnrStr a string representing a social security number (SSN)
     * @return a new Pnr object
     * @throws IllegalArgumentException if the param does not represent a correct SSN
     */

    public static Pnr createPnr(String pnrStr) throws IllegalArgumentException {
        if (!pnrStr.matches(pnrPattern)) {
            throw new IllegalArgumentException("INVALID PNR!\n");
        }
        return new Pnr(pnrStr);
    }


    /** PUBLIC OPERATION */

    @Override
    public boolean equals(Object other) {

        if (other instanceof Pnr otherPnr) {
            return this.pnrStr.equals(otherPnr.getPnrStr());
        }
        return false;
    }


    /** ACCESS METHODS */

    public String getPnrStr() {
        return pnrStr;
    }

    @Override
    public String toString() {
        return "PNR : " + getPnrStr();
    }
}
