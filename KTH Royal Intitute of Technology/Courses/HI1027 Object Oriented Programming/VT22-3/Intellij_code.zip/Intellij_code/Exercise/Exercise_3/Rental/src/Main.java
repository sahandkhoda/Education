import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        System.out.println();
        LoanManager loanManager = new LoanManager();

        Member adam = new Member(
                "Adam Sandler",
                "19840921-1234");

        Member kevin = new Member(
                "Kevin James",
                "19220921-1234");

        Member chris = new Member(
                "Chris Rock",
                "19540921-1234");

        Kayak k1 = new Kayak(
                "GILMORE",
                "ADVANCED",
                1,
                adam);

        Kayak k4 = new Kayak(
                "GILMORE",
                "ADVANCED",
                1,
                adam);

        Kayak k2 = new Kayak(
                "MALL COP",
                "BEGINNER",
                2,
                kevin);

        Kayak k3 = new Kayak(
                "SMACK",
                "EASY",
                3,
                chris);

        loanManager.addKayak(k1);
        loanManager.addKayak(k2);
        loanManager.addKayak(k3);

        loanManager.addLoan(adam, k1, LocalDate.now());
        loanManager.addLoan(adam, k2, LocalDate.now());
        loanManager.addLoan(adam, k2, LocalDate.of(2023, 9, 5));
        loanManager.addLoan(adam, k3, LocalDate.now());

        for (Loan loan : loanManager.getLoans()) {
            System.out.println(loan.toString());
        }

    }
}