import CarPark.Car;
import CarPark.Owner;

public class Main {
    public static void main(String[] args) {

        System.out.println();
        Car car = new Car("123abc ", "Volvo");
        Owner adam = new Owner("Adam Sandler", "California    ");
        Owner kevin = new Owner("Kevin James", "California");

        kevin.setCar(car);

        System.out.println(adam.toString());
        System.out.println(kevin.toString());
    }
}