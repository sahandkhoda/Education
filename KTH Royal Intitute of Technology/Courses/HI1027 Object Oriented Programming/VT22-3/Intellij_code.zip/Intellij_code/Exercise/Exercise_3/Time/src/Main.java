import FlightTime.Flight;

public class Main {
    public static void main(String[] args) {

        Flight flight = new Flight
                ("Barcelona, Spain", "123ABC", 17871,30,0);

        System.out.println();
        System.out.println(flight.toString());

    }
}