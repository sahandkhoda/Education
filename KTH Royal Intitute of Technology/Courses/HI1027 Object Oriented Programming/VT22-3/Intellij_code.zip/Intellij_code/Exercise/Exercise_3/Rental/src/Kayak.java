public class Kayak {

    /** PRIVATE DATA FIELDS */

    private final String model;
    private final KLevel level;
    private final long number;
    private Member caretaker;


    /** CONSTRUCTORS */

    public Kayak(String model, KLevel level, long number, Member caretaker) {
        this.model = model.strip();
        this.level = level;
        this.number = number;
        this.caretaker = caretaker;
    }

    public Kayak(String model, String level, long number, Member caretaker) {
        this(model, KLevel.valueOf(level), number, caretaker);
    }


    /** PUBLIC OPERATION */

    public void setCaretaker(Member newCaretaker) {
        this.caretaker = newCaretaker;
    }


    /** ACCESS METHODS */

    public String getModel() {
        return model;
    }

    public KLevel getLevel() {
        return level;
    }

    public long getNumber() {
        return number;
    }

    public Member getCaretaker() {
        return caretaker;
    }

    public String kayakInfo() {
        return  "Caretaker : " + getCaretaker().memberInfo() + "\n" +
                "Model     : " + getModel()                  + "\n" +
                "KLevel    : " + getLevel()                  + "\n" +
                "Number    : " + getNumber();
    }

    @Override
    public String toString() {
        return  "=== KAYAK ===" + "\n" +
                kayakInfo()     + "\n";
    }
}
