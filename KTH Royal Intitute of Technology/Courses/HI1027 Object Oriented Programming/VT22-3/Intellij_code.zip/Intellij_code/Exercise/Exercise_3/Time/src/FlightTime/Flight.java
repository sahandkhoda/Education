package FlightTime;

public class Flight {

    /** PRIVATE DATA FIELDS */

    private Time departureTime;
    private final String destination, flightNr;


    /** CONSTRUCTORS */

    public Flight(String destination, String flightNr, Time departureTime) {
        this(destination, flightNr);
        this.departureTime = departureTime.getTimeCopy();
    }

    public Flight(String destination, String flightNr, int h, int m, int s) {
        this(destination, flightNr);
        this.departureTime = new Time(h, m, s);
    }

    public Flight(String destination, String flightNr) {
        this.destination = destination.strip().toUpperCase();
        this.flightNr = flightNr.strip().toUpperCase();
    }


    /** ACCESS METHODS */

    public Time getDepartureTime() {
        return departureTime.getTimeCopy();
    }

    public String getDestination() {
        return destination;
    }

    public String getFlightNr() {
        return flightNr;
    }

    @Override
    public String toString() {
        return  "Flight " + getFlightNr() + " headed to " + getDestination() +
                " will departure at [" + getDepartureTime().toString() + "] " +
                "on " + String.format("%02d/%02d-%02d.", Time.DAY, Time.MONTH, Time.YEAR);
    }
}
