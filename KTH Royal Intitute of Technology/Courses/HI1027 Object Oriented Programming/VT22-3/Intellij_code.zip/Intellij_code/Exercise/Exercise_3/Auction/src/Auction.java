import java.util.Arrays;

public class Auction {

    /** PRIVATE DATA FIELDS */

    private final User owner;
    private final String item;
    private Bid[] bids;
    private int nrOfBids;

    /** CONSTRUCTOR */

    public Auction(User owner, String item) {
        this.owner = owner;
        this.item = item;
        bids = new Bid[1];
        nrOfBids = 0;
    }

    /** PUBLIC OPERATION */

    public void addBid(Bid bid) {
        bids[nrOfBids++] = bid;
        resize();
    }


    /** PRIVATE HELP METHOD */

    private void resize() {
        Bid[] temp = new Bid[nrOfBids+1];
        System.arraycopy(bids, 0, temp, 0, bids.length);
        bids = new Bid[temp.length];
        System.arraycopy(temp, 0, bids, 0, bids.length);
    }

    private String printBids() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < nrOfBids; i++) {
            builder.append(bids[i].toString()).append("\n");
        }
        return builder.toString();
    }

    /** ACCESS METHODS */

    public User getOwner() {
        return new User(owner.getUsername(), owner.getEmail(), owner.getPassword());
    }

    public Bid[] getBids() {
        return bids.clone();
    }

    public String getItem() {
        return item;
    }

    @Override
    public String toString() {
        return  "--- OWNER ---"      + "\n" +
                getOwner().toString()     +
                "Item     : " + getItem() + "\n" +
                printBids();
    }
}
