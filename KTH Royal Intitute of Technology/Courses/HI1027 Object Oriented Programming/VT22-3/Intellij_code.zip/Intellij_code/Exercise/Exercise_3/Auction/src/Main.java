public class Main {
    public static void main(String[] args) {

        User a = new User("a", "a", "a");
        User b = new User("b", "b", "b");
        User c = new User("c", "c", "c");

        Auction auction = new Auction(a, "Golf Clubs");
        auction.addBid(new Bid(b, 100));
        auction.addBid(new Bid(c, 200));
        auction.addBid(new Bid(b, 350));

        System.out.println(auction.toString());
    }
}