public enum Genre {

    ACTION    ("ACTION"),
    ADVENTURE ("ADVENTURE"),
    DRAMA     ("DRAMA"),
    HORROR    ("HORROR"),
    ROMANCE   ("ROMANCE");


    private final String genre;

    private Genre(String genre) {
        this.genre = genre;
    }

    public String getGenre() {
        return genre;
    }
}
