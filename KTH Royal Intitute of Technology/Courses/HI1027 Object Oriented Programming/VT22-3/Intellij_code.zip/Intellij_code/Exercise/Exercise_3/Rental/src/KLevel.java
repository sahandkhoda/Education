public enum KLevel {

    BEGINNER ("BEGINNER"),
    EASY     ("EASY"),
    SKILLED  ("SKILLED"),
    ADVANCED ("ADVANCED");

    private final String level;

    private KLevel(String level) {
        this.level = level;
    }

    public String getLevelStr() {
        return level;
    }
}
