public class User {

    /** PRIVATE DATA FIELDS */

    private final String username, email;
    private String password;


    /** CONSTRUCTOR */

    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }


    /** PUBLIC OPERATION */

    public void setPassword(String newPassword) {
        password = newPassword;
    }


    /** ACCESS METHODS */

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return  "Name     : " + username + "\n" +
                "Email    : " + email    + "\n" +
                "Password : " + password + "\n";
    }
}
