import java.util.ArrayList;

public class Movie {

    /** PRIVATE DATA FIELDS */

    private final String title;
    private final Genre genre;
    private final Person director;
    private final ArrayList<ActorRole> roles;


    /** CONSTRUCTOR */

    public Movie(String title, Person director, Genre genre) {
        this.title = title.strip();
        this.director = director;
        this.genre = genre;
        roles = new ArrayList<>();
    }

    public Movie(String title, Person director, String genre) {
        this(title, director, Genre.valueOf(genre.strip().toUpperCase()));
    }


    /** PUBLIC OPERATION */

    public void addRole(ActorRole newRole) {
        roles.add(newRole);
    }


    /** ACCESS METHODS */

    public Movie getMovie() {
        return new Movie(getTitle(), getDirector(), getGenre());
    }

    public String getTitle() {
        return title;
    }

    public Person getDirector() {
        return director.getPerson();
    }

    public Genre getGenre() {
        return genre;
    }

    public String getGenreString() {
        switch (Genre.valueOf(getGenre().toString())) {
            case ACTION    -> { return "POW POW BOOM BOOM";     }
            case ADVENTURE -> { return "WOW, SO AWESOME!";     }
            case DRAMA     -> { return "WTF IS GOING ON?!";     }
            case HORROR    -> { return "Adrenaline rush!";      }
            case ROMANCE   -> { return "For the love birds <3"; }
            default        -> { return "No genre...";           }
        }
    }

    public ArrayList<ActorRole> getRoles() {
        return new ArrayList<ActorRole>(roles);
    }

    @Override
    public String toString() {
        return  getTitle() + " [" + getGenre() + "] directed by " +
                getDirector().getFullName() + " (" + getDirector().getBirthday() + ").";
    }
}
