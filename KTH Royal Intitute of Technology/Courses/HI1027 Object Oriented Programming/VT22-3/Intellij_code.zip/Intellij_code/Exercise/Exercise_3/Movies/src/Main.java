import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        Person peter = new Person(
                "Peter Jackson",
                1986, 4, 23,
                "Little Hobbit");

        Person elijah = new Person("Elijah Wood",
                1999, 5, 2,
                "Master Hobbit");

        Person sean = new Person("Sean Austin",
                1991, 7, 30,
                "Part-time Gardener. Full-time Hero of the Story.");

        Movie lotr = new Movie(
                "The Lord of the Rings", peter, "Adventure");

        ActorRole frodo = new ActorRole(lotr, elijah, "Frodo Baggins");
        ActorRole sam = new ActorRole(lotr, sean, "Samwise Gamgee");
        lotr.addRole(frodo);
        lotr.addRole(sam);

        for (ActorRole role : lotr.getRoles()) {
            System.out.println(role.toString());
        }

    }
}