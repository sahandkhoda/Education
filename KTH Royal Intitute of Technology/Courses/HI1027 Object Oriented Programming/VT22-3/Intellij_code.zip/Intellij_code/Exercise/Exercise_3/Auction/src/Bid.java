public class Bid {

    /** PRIVATE DATA FIELDS */

    private final User bidder;
    private final double bid;
    private static int bidNumber = 0;


    /** CONSTRUCTOR */

    public Bid(User bidder, double bid) {
        this.bidder = bidder;
        this.bid = bid;
    }

    /** ACCESS METHODS */

    public User getBidder() {
        return new User(bidder.getUsername(), bidder.getEmail(), bidder.getPassword());
    }

    public double getBid() {
        return bid;
    }

    public int getBidNumber() {
        return ++bidNumber;
    }

    @Override
    public String toString() {
        return  "\n--- BID " + getBidNumber() + " ---" + "\n" +
                getBidder().toString()  +
                "Bid [$]  : " + getBid();
    }
}
