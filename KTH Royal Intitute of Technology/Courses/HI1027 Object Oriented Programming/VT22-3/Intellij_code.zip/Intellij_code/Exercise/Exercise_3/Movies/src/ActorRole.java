public class ActorRole {

    private final Movie movie;
    private final Person actor;
    private final String role;

    public ActorRole(Movie movie, Person actor, String role) {
        this.movie = movie;
        this.actor = actor;
        this.role = role;
    }

    public Movie getMovie() {
        return movie.getMovie();
    }

    public Person getActor() {
        return actor.getPerson();
    }

    public String getRole() {
        return role;
    }

    @Override
    public String toString() {
        return getRole() + " in " + getMovie().getTitle() +
                " played by " + getActor().getFullName() + " (" + getActor().getBirthday() + ").";
    }

}
