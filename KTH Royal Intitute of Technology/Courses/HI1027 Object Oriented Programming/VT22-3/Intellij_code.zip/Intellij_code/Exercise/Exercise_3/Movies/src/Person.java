import java.time.LocalDate;

public class Person {

    /** PRIVATE DATA FIELDS */

    private String fullName, firstname, lastname;
    private final LocalDate birthday;
    private final String biography;


    /** CONSTRUCTOR */

   public Person(String fullName, LocalDate birthday, String biography) {
        setNames(fullName.strip());
        this.birthday = birthday;
        this.biography = biography;
    }

    public Person(String fullName, int year, int month, int day, String biography) {
        this(fullName, LocalDate.of(year, month, day), biography);
    }


    /** PRIVATE HELP METHOD */

    private void setNames(String fullName) {
        this.fullName = fullName;
        String[] names = fullName.split(" ");
        this.firstname = names[0];
        this.lastname  = names[names.length-1];
    }


    /** ACCESS METHODS */

    public Person getPerson() {
        return new Person(getFullName(), getBirthday(), getBiography());
    }

    public String getFullName() {
        return fullName;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public String getBiography() {
        return biography;
    }

    @Override
    public String toString() {
        return  "=== BIOGRAPHY ===" + "\n" +
                getFullName() + " (" + getBirthday().toString() + ")\n" +
                "'" + getBiography() + "'" + "\n";
    }
}
