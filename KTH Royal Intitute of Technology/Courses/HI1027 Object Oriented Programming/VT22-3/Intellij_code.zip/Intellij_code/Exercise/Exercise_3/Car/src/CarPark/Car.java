package CarPark;

public class Car {

    /** PACKAGE PRIVATE DATA FIELDS */

    Owner owner;
    final String reg, manufacturer;


    /** CONSTRUCTOR */

    public Car(String reg, String manufacturer) {
        this.reg = reg.strip().toUpperCase();
        this.manufacturer = manufacturer.strip().toUpperCase();
        this.owner = null;
    }


    /** PACKAGE PRIVATE OPERATIONS */

    void setOwner(Owner owner) {
        this.owner = owner;
    }

    void removeOwner() {
        this.owner = null;
    }


    /** ACCESS METHODS */

    String getReg() {
        return reg;
    }

    String getManufacturer() {
        return manufacturer;
    }

    Owner getOwnerCopy() {
        return owner;
    }

    @Override
    public String toString() {
        return "=== " + getReg() + " [" + getManufacturer() + "] ===\n";
    }
}
