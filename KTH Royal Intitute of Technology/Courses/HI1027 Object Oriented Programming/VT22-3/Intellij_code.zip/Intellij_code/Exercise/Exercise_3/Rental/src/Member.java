public class Member {

    /** PRIVATE DATA FIELDS */

    private final String name;
    private final Pnr pnr;


    /** CONSTRUCTORS */

    public Member(String name, Pnr pnr) {
        this.name = name.strip();
        this.pnr = pnr;
    }

    public Member(String name, String pnrStr) {
        this(name, Pnr.createPnr(pnrStr));
    }


    /** ACCESS METHODS */

    public String getName() {
        return name;
    }

    public Pnr getPnr() {
        return pnr;
    }

    public String memberInfo() {
        return getName() + " (" + getPnr().getPnrStr() + ")";
    }

    @Override
    public String toString() {
        return  "=== MEMBER ===" + "\n" +
                memberInfo()     + "\n";
    }
}
