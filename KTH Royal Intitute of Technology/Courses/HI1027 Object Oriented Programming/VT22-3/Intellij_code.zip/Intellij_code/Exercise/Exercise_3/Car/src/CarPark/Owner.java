package CarPark;

public class Owner {

    /** PRIVATE DATA FIELDS */

    private Car car;
    private final String name, address;


    /** CONSTRUCTOR */

    public Owner(String name, String address) {
        this.name = name.strip();
        this.address = address.strip();
        this.car = null;
    }


    /** PUBLIC OPERATIONS */

    public void setCar(Car car) {
        this.car = new Car(car.getReg(), car.getManufacturer());
        this.car.setOwner(this);
    }

    public void removeCar() {
        this.car.removeOwner();
        this.car = null;
    }


    /** PRIVATE HELP METHOD */

    private String printOwner() {
        return getName() + " (" + getAddress() + ")\n";
    }

    private String printCar() {
        if (car == null) {
            return "=== NO REGISTERED CAR ===\n";
        } else {
            return getCarCopy().toString();
        }
    }


    /** ACCESS METHODS */

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public Car getCarCopy() {
        return car;
    }

    @Override
    public String toString() {
        return  printOwner() + printCar();
    }
}
