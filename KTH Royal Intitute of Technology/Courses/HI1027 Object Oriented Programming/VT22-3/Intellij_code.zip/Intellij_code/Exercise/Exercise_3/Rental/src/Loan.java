import java.time.LocalDate;

public class Loan {

    /** PRIVATE DATA FIELDS */

    private final Member borrower;
    private final Kayak kayak;
    private final LocalDate loanDate;


    /** CONSTRUCTOR */

    public Loan(Member borrower, Kayak kayak, LocalDate loanDate) {
        this.borrower = borrower;
        this.kayak = kayak;
        this.loanDate = loanDate;
    }


    /** ACCESS METHODS */

    public Kayak getKayak() {
        return kayak;
    }

    public Member getBorrower() {
        return borrower;
    }

    public LocalDate getLoanDate() {
        return loanDate;
    }

    public String loanInfo() {
        return  getKayak().kayakInfo()                      + "\n" +
                "Borrower  : " + getBorrower().memberInfo() + "\n" +
                "Loan date : " + getLoanDate().toString();
    }

    @Override
    public String toString() {
        return  "=== LOAN ===" + "\n" +
                loanInfo()     + "\n";

    }
}
