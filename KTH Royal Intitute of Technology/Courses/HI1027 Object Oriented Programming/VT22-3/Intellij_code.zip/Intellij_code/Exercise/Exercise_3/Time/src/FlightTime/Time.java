package FlightTime;

import java.time.LocalDateTime;

public class Time {

    /** PRIVATE DATA FIELDS */

    private static final LocalDateTime localDateTime = LocalDateTime.now();
    private int h, m, s;


    /** PUBLIC STATIC DATA FIELDS */

    public static int DAY   = localDateTime.getDayOfMonth();
    public static int MONTH = localDateTime.getMonthValue();
    public static int YEAR  = localDateTime.getYear();


    /** CONSTRUCTORS (OVERLOADED) */

    public Time(int h, int m, int s) {
        contract(h, m, s);
        this.h = h;
        this.m = m;
        this.s = s;
        adjust();
    }

    public Time(int h, int m) {
        this(h,m,0);
    }

    public Time(int h) {
        this(h,0,0);
    }

    public Time() {
        this(10,10,10);
    }


    /** PUBLIC OPERATIONS */

    public void setTime(int h, int m, int s) {
        contract(h, m, s);
        this.h = h;
        this.m = m;
        this.s = s;
        adjust();
    }

    public void setH(int h) {
        contract(h, 0, 0);
        this.h = h;
        adjust();
    }

    public void setM(int m) {
        contract(0, m, 0);
        this.m = m;
        adjust();
    }

    public void setS(int s) {
        contract(0, 0, s);
        this.s = s;
        adjust();
    }

    public void tic(int h, int m, int s) {
        contract(h, m, s);
        this.h += h;
        this.m += m;
        this.s += s;
        adjust();
    }

    public void tic(int m, int s) {
        tic(0, m, s);
    }

    public void tic(int s) {
        tic(0, 0, s);
    }

    public void tic() {
        tic(10, 10, 10);
    }

    /** PRIVATE HELP METHODS */

    private void contract(int h, int m, int s) throws IllegalArgumentException {
        if (h<0 || m<0 || s<0)
            throw new IllegalArgumentException("INVALID TIME ARGUMENT!\n");
    }

    private void adjust() {
        m += s / 60;
        h += m / 60;

        if (h > 23) {
            DAY += h/24;
        }

        if (DAY > 31) {
            MONTH += DAY / 31;
            DAY %= 31;
        }

        if (MONTH > 12) {
            YEAR += MONTH / 12;
            MONTH %= 12;
        }

        s %= 60;
        m %= 60;
        h %= 24;
    }


    /** ACCESS METHODS */

    public Time getTimeCopy() {
        return new Time(getH(), getM(), getS());
    }

    public int getH() {
        return h;
    }

    public int getM() {
        return m;
    }

    public int getS() {
        return s;
    }

    @Override
    public String toString() {
        return String.format("%02d:%02d:%02d", getH(), getM(), getS());
    }
}
