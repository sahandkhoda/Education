package model;

import java.util.Random;

public class SlidingPuzzle {

    // Public field
    public enum Dimension { THREE, EIGHT, FIFTEEN }

    // Private fields
    private int noOfMoves;
    private final int rows, cols;
    private int[] values;

    public SlidingPuzzle(Dimension dimension) {
        switch (dimension)
        {
            case THREE      : this.rows = 2; this.cols = 2; break;
            case EIGHT      : this.rows = 3; this.cols = 3; break;
            case FIFTEEN    : this.rows = 4; this.cols = 4; break;
            default         : this.rows = 5; this.cols = 5; break;
        }
        this.values = new int[rows*cols];
        this.reset();
    }

    public SlidingPuzzle() {
        this(Dimension.FIFTEEN);
    }


    /** Resets the numbers in ascending order, with the empty position last. */
    public final void reset() {
        this.noOfMoves = 0;
        values[values.length-1] = 0;
        for (int i=0; i<values.length-1; i++) { values[i] = i+1; }
        shuffle();
    }

    public void shuffle()
    {
        /**
         * Shuffles the numbers until solvable with "randomize()".
         * The new state is guaranteed to be solvable with "isSolvable()".
         */

        do {
            randomize();
            isSolvable();
        } while (!isSolvable());
    }

    public int getPos(int number)
    {
        int index = 0;
        for (int i=0; i<values.length; i++) {
            if(number==values[i]) {
                index = i;
            }
        }
        return index;
    }

    public int getNoOfMoves()
    {
        /**
         * Returns the number of moves since the last reset or shuffle.
         * @return number of moves
         */
        return noOfMoves;
    }

    public boolean makeMove(int number)
    {
        /**
         * Swaps the positions of number and empty position.
         * In case the move is illegal, the state is unchanged.
         * @parameter number the number to move
         * @return true if the number was moved
         */

        if (isLegalMove(number))
        {
            // Creating a (temporary) copy of "values[]"
            int[] tempArr = new int[values.length];
            for (int i=0; i<tempArr.length; i++) {
                tempArr[i] = values[i];
            }

            // Assigning new values to "values[]"
            tempArr[getPos(0)] = number;
            tempArr[getPos(number)] = 0;
            values = tempArr;
            noOfMoves++;

            return true;
        }
        // Side note : change boolean to void?
        return false;
    }

    public boolean isLegalMove(int number)
    {
        /**
         * Returns whether the number ("int number") can be moved or not,
         * i.e. if the number is adjacent to the empty position.
         * @parameter number the number to move
         * @return true if the number can be moved
         */

        // Finding row and column for both "0" and "number"
        int r0 = getPos(0) / rows;
        int c0 = getPos(0) % cols;
        int r = getPos(number) / rows;
        int c = getPos(number) % cols;

        // Same row
        if (r0 == r) {
            if (c0-c == 1 || c0-c == -1) {
                return true;
            }
        }

        // Same column
        if (c0 == c) {
            if (getPos(0)-getPos(number) == rows || getPos(0)-getPos(number) == -rows) {
                return true;
            }
        }

        return false;
    }

    public boolean isSolved()
    {
        /**
         * Returns whether the puzzle is solved, i.e. all numbers in
         * ascending order, with the empty position last, or not.
         * @return true if the puzzle is solved
         */

        // Last element has to be zero
        if (values[values.length-1]==0)
        {
            // Iterate from the first element to the element before the last (0).
            for (int i=0; i<values.length-2; i++) {
                // Is it ascending order?
                if (values[i] > values[i+1]) {
                    return false;
                }
            }

            // Loop didn't return "false".
            // Thus, all numbers are in ascending order.
            return true;

        }

        return false;
    }

    public int[][] copyOfBoard()
    {
        int[][] boardCopy = new int[rows][cols];
        for (int r=0; r<rows; r++)
        {
            for (int c=0; c<cols; c++)
            {
                boardCopy[r][c] = values[(cols*r)+c];
            }
        }

        return boardCopy;
    }

    @Override
    public String toString()
    {
        System.out.println("");
        String info = "\t=== BOARD === \n";

        for (int r=0; r<rows; r++) {
            for (int c=0; c<cols; c++) {
                info += "\t" + values[r*cols + c];
            }
            info += "\n";
        }
        info += "\n" + "Number of moves : " + getNoOfMoves();
        return info;
    }

    // Private methods
    private void randomize()
    {
        /**
         * Applying Fisher-Yates shuffling
         */

        int x = values.length;
        Random random = new Random();
        for (int i=0; i<values.length; i++)
        {
            int randomValue = i + random.nextInt(x-i);
            int temp = values[randomValue];
            values[randomValue] = values[i];
            values[i] = temp;
        }
    }

    private boolean isSolvable()
    {
        int n = noOfInversions();
        if (cols % 2 == 0)                // width even
        {
            int ePos = getPos(0);
            int eRow = ePos / cols;
            // empty position on even row, counting from bottom?
            if ( (rows-eRow) % 2 == 0) { return n % 2 != 0; }
            else { return n % 2 == 0; }

        } else { return n % 2 == 0; }     // width odd
    }

    private int noOfInversions()
    {
        // count number of inversions (n)
        int n = 0;
        for (int i=0; i<values.length; i++) {
            if (values[i] != 0) {
                int val = values[i];
                for (int j = i+1; j<values.length; j++) {
                    if (values[j] != 0 && values[j]<val) {
                        n++;
                    }
                }
            }
        }
        return n;
    }
}
