import Model.SlidingPuzzle;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanS = new Scanner(System.in);
        String choice;
        do {
            SlidingPuzzle puzzle;
            System.out.println();
            System.out.println("INITIALIZING GAME...");
            System.out.print("Enter dimension [4, 9, 16, 25] : ");

            int dimI = Integer.parseInt(scanS.nextLine());
            switch (dimI) {
                case 4  -> puzzle = new SlidingPuzzle("three");
                case 9  -> puzzle = new SlidingPuzzle("eight");
                case 25 -> puzzle = new SlidingPuzzle("twenty_four");
                default -> puzzle = new SlidingPuzzle("fifteen");
            }
            System.out.println();
            System.out.println(puzzle.toString());

            // Scan INTEGER
            Scanner scanI = new Scanner(System.in);
            do {
                System.out.print("Enter move : ");
                puzzle.makeMove(scanI.nextInt());
                System.out.println(puzzle.toString());
            } while (!puzzle.isSolved());

            System.out.println("SOLVED! Number of moves : " + puzzle.getNrOfMoves() + "\n");
            System.out.print("Play again (y/n) : ");
            choice = scanS.nextLine().toLowerCase();
        } while (choice.equals("y"));

        System.out.println("EXITING GAME...");
        System.out.println("DONE!");

    }
}