package Model;

public enum Dimension {

    THREE       ("THREE"),
    EIGHT       ("EIGHT"),
    FIFTEEN     ("FIFTEEN"),
    TWENTY_FOUR ("TWENTY_FOUR");

    private final String dimension;

    Dimension(String dimension) {
        this.dimension = dimension;
    }

    public String getDimension() {
        return dimension;
    }
}
