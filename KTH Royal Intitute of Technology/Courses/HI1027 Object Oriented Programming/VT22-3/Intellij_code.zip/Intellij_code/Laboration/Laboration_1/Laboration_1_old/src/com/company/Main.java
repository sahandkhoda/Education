package com.company;

import model.SlidingPuzzle;

import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        SlidingPuzzle puzzle = new SlidingPuzzle(SlidingPuzzle.Dimension.THREE);
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println(puzzle.toString());
            System.out.print("ENTER MOVE : ");
            int move = scanner.nextInt();
            puzzle.makeMove(move);
        } while (!puzzle.isSolved());

        System.out.println();
        System.out.println("Congrats!" + "\n" + "GAME WON");

        /**
         * TEST CODES TO CHECK AND CONTROL IF EVERYTHING WORKS
         *
         * // LEGAL MOVE? SOLVED BOARD? POSITION?
         * System.out.println("Legal  : " + puzzle.isLegalMove(move));
         * System.out.println("Solved : " + puzzle.isSolved());
         * System.out.println("Zero : " + puzzle.getPos(0));
         * System.out.println("Numb : " + puzzle.getPos(move));
         *
         * // COPY OF BOARD
         * System.out.println("COPY OF BOARD");
         * System.out.println(Arrays.deepToString(puzzle.copyOfBoard()).replace("], ", "]\n").replace("[[", "[").replace("]]", "]"));
         */

    }
}
