package model;

import java.util.Random;

/**
 * This class represents logic and data for a sliding puzzle, a n-by-n matrix of
 * numbers, [1 .. (n*n - 1)] and one empty position.
 * <p>
 * Only positions adjacent to the empty positions can be moved. The goal is to
 * arrange the numbers in ascending order, with the empty position last.
 *
 * @author Anders Lindström, anderslm@kth.se
 */
public class SlidingPuzzle {

    /**
     * Represents valid puzzle dimensions. E.g. FIFTEEN represents a 4-by-4
     * puzzle (with one empty position).
     */
    public enum Dimension {
        THREE, EIGHT, FIFTEEN
    }

    private int noOfMoves;
    private int rows, cols;
    // NB! Internal representation as a one dimensional array makes it easier to
    // randomize a solvable starting position.
    private int[] values;

    /**
     * Constructs a new SlidingPuzzle with the specified dimension.
     *
     * @param dimension The dimensions of the board.
     */
    public SlidingPuzzle(Dimension dimension) {
        // ...
    }

    /**
     * Constructs a new SlidingPuzzle with dimension FIFTEEN.
     */
    public SlidingPuzzle() {
        // ...
    }

    /**
     * Resets the numbers in ascending order, with the empty position last.
     */
    public final void reset() {
        // ...
    }

    /**
     * Shuffles the numbers. The new state is guaranteed to be solvable.
     */
    public void shuffle() {
        // shuffle until solvable
        // ...
    }

    /**
     * Returns the number of moves since the last reset or shuffle.
     *
     * @return number of moves
     */
    public int getNoOfMoves() {
        // ...
        return 0;
    }

    /**
     * Returns whether the number can be moved or not, i.e. if the number is
     * adjacent to the empty position.
     *
     * @param number the number to move
     * @return true if the number can be moved
     */
    public boolean isLegalMove(int number) {
        // ...
        return false;
    }

    /**
     * Swaps the positions of number and empty position. In case the move is
     * illegal the state is unchanged.
     *
     * @param number the number to move
     * @return true if the number was moved
     */
    public boolean makeMove(int number) {
        // ...
        return false;
    }

    /**
     * Returns whether the puzzle is solved, i.e. all numbers in ascending order
     * with the empty position last, or not.
     *
     * @return true if the puzzle is solved
     */
    public boolean isSolved() {
        // ...
        return false;
    }

    /**
     * Returns a copy of the board, in the form of a 2-dim int matrix,
     * dimensions rows*columns. The empty position is represented with 0 (zero).
     *
     * @return an int[rows][columns] representation of the board.
     */
    public int[][] copyOfBoard() {
        // ...
        return null;
    }

    /**
     * Returns a String-representation of this SlidingPuzzle.
     */
    @Override
    public String toString() {
        // ...
        // StringBuffer recommended
        return "";
    }

    // the position (index) of the number in the internal 1-dimensional array
    private int getPos(int number) {
        // ...
        return 0;
    }

    // randomize the numbers
    // NB! Not guaranteed to generate a solvable state
    private void randomize() {
        // Fisher-Yates shuffling recommended
        // ...
    }

    // Check if this set of values do represent a solvable puzzle
    // Theory:
    // https://www.geeksforgeeks.org/check-instance-8-puzzle-solvable/
    private boolean isSolvable() {
        int n = noOfInversions();
        if (cols % 2 == 0) { // width even
            int ePos = getPos(0);
            int eRow = ePos / cols;
            // empty position on even row, counting from bottom?
            if ((rows - eRow) % 2 == 0) {
                return n % 2 != 0;
            } else {
                return n % 2 == 0;
            }
        } else { // width odd
            return n % 2 == 0;
        }
    }

    // https://www.geeksforgeeks.org/check-instance-8-puzzle-solvable/
    private int noOfInversions() {
        // count number of inversions, n
        int n = 0;
        for (int k = 0; k < values.length; k++) {
            if (values[k] != 0) {
                int val = values[k];
                for (int l = k + 1; l < values.length; l++) {
                    if (values[l] != 0 && val > values[l]) {
                        n++;
                    }
                }
            }
        }
        return n;
    }
}
