package Model;

import java.util.Random;

/**
 * This class represents logic and data for a sliding puzzle,
 * an n-by-n matrix of numbers, [1 ... (n*n - 1)] and one empty position.
 * <p>
 * Only positions adjacent to the empty positions can be moved. The goal is to
 * arrange the numbers in ascending order, with the empty position last.
 *
 * @author Sahand Khodabandehloo, sahandkh@kth.se
 */

public class SlidingPuzzle {

    /** PRIVATE DATA FIELDS */

    private int rows, cols, nrOfMoves;
    private final int[] values;

    /** CONSTRUCTORS (OVERLOADED) */

    public SlidingPuzzle(Dimension dimension) {
        switch (dimension) {
            case THREE       -> { rows = 2; cols = 2; }
            case EIGHT       -> { rows = 3; cols = 3; }
            case FIFTEEN     -> { rows = 4; cols = 4; }
            case TWENTY_FOUR -> { rows = 5; cols = 5; }
        }
        values = new int[rows * cols];
        reset();
        shuffle();
    }

    public SlidingPuzzle(String dimension) {
        this(Dimension.valueOf(dimension.toUpperCase()));
    }

    public SlidingPuzzle() {
        this(Dimension.FIFTEEN);
    }


    /** PUBLIC METHODS */

    // Returns a copy of the 1D integer array.
    public int[] getValues() {
        return values.clone();
    }

    // Converts the 1D integer array to a 2D integer array and returns it.
    public int[][] getCopyOfBoard() {
        int[][] boardCopy = new int[getRows()][getCols()];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                boardCopy[r][c] = values[r * cols + c];
            }
        }
        return boardCopy;

    }

    // Returns the position of the "number"-parameter.
    private int getPos(int number) {
        for (int i=0; i<values.length; i++) {
            if (values[i] == number) {
                return i;
            }
        }
        throw new IllegalArgumentException("Enter valid number.\n");
    }

    // Updates the board by swapping position of the specific move and the empty position.
    // In case the move is illegal, the state is unchanged.
    public void makeMove(int move) {
        if (isLegalMove(move)) {
            int temp = getPos(move);
            values[getPos(0)] = move;
            values[temp] = 0;
            nrOfMoves++;
        }
    }


    /** ACCESS METHODS */

    // Returns the total number of moves.
    public int getNrOfMoves() {
        return nrOfMoves;
    }

    // Returns whether the board is solved, in ascending order, and the empty position last.
    public boolean isSolved() {
        for (int i = 0; i < values.length-1; i++) {
            if (values[i] != i+1) {
                return false;
            }
        }
        return values[values.length - 1] == 0;
    }

    // Returns a String-representation of the current board.
    @Override
    public String toString() {
        StringBuilder info = new StringBuilder("\n");
        info.append("====== ").append(getRows()).append(" x ").append(getCols()).append(" ======\n");
        info.append("Number of moves : ").append(getNrOfMoves()).append("\n");
        info.append("===================\n");
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                info.append("\t").append(values[r * cols + c]);
            }
            info.append("\n");
        }
        return info.toString();
    }


    /** PRIVATE METHODS */

    // Returns the number of rows of the board.
    private int getRows() {
        return rows;
    }

    // Returns the number of columns of the board.
    private int getCols() {
        return cols;
    }

    // Resets the numbers in ascending order, with the empty position last.
    private void reset() {
        nrOfMoves = 0;
        values[values.length-1] = 0;
        for (int i = 0; i < values.length - 1; i++) {
            values[i] = i+1;
        }
    }

    // Shuffles the board with the randomize()-method.
    // The new state is guaranteed to be solvable with the isSolvable()-method.
    private void shuffle() {
        do {
            randomize();
        } while (!isSolvable());
    }

    // Randomly shuffles the board by applying Fisher-Yates shuffling.
    private void randomize() {
        Random random = new Random();
        for (int i = 0; i < values.length; i++) {
            int randomValue = i + random.nextInt(values.length - i);
            int temp = values[randomValue];
            values[randomValue] = values[i];
            values[i] = temp;
        }
    }

    // Returns whether the entered move is legal.
    // The move (number) has to be adjacent to the empty position.
    public boolean isLegalMove(int move) {

        // Correct range of numbers
        if (move < 1 || move > values.length-1) return false;

        // Get row
        int r1 = getPos(move) / getRows();
        int r0 = getPos(0) / getRows();

        // Get column
        int c1 = getPos(move) % getCols();
        int c0 = getPos(0) % getCols();

        // Same row
        if (r1 == r0) {
            return (c1 - c0 == 1 || c1 - c0 == -1);         // Difference of 1 or -1
        }

        // Same column
        if (c1 == c0) {
            return (r1 - r0 == 1 || r1 - r0 == -1);         // Difference of 1 or -1
        }

        // Else...
        return false;
    }

    // Help methods
    private boolean isSolvable() {

        int n = nrOfInversions();
        if (cols % 2 == 0) {                        // Width even
            int ePos = getPos(0);
            int eRow = ePos / cols;

            // Empty position on even row, counting from bottom?
            if ((rows - eRow) % 2 == 0) {
                return n % 2 != 0;
            } else {
                return n % 2 == 0;
            }
        } else {                                    // Width odd
            return n % 2 == 0;
        }
    }

    private int nrOfInversions() {

        // Count number of inversions (n)
        int n = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i] != 0) {
                int val = values[i];
                for (int j = i + 1; j < values.length; j++) {
                    if (values[j] != 0 && val > values[j]) {
                        n++;
                    }
                }
            }
        }
        return n;
    }

}
