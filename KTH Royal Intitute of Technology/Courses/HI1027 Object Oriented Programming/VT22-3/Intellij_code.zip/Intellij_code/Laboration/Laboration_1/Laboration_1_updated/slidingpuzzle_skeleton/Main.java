import model.SlidingPuzzle;
import static model.SlidingPuzzle.Dimension;

public class Main {

	public static void main(String[] args) {
			
		SlidingPuzzle puzzle = new SlidingPuzzle(Dimension.EIGHT); // also try other dimensions
		System.out.println(puzzle.toString());
		
		for(int val = 0; val < 16; val++) {
			System.out.println("" + val + " is legal: " + puzzle.isLegalMove(val));
		}
		
		int[] moves = new int[]{ 8, 5, 4, 1, 2 }; // a list of moves
		for(int i = 0; i < moves.length; i++) {
			System.out.println("try move " + moves[i]);
			puzzle.makeMove(moves[i]);
			System.out.println(puzzle.toString());
		}
		
		System.out.println("Number of moves: " + puzzle.getNoOfMoves());
		
		System.out.println("reset puzzle");
		puzzle.reset();
		System.out.println(puzzle.toString());
	}
}
