package com.company.cardutils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Pile
{
    public Pile()
    {
        pile = new ArrayList<>();
        clearPile();
    }

    public void clearPile()           { pile.clear();   }
    public void add(Card card)        { pile.add(card); }
    public void add(List<Card> cards) { pile.addAll(cards); }

    public Card remove(int index)
    {
        Card removedCard = getCard(index);
        pile.remove(index);
        return removedCard;
    }

    public boolean remove(Card theCard)
    {
        if (contains(theCard))
        {
            pile.remove(theCard);
            return true;
        }
        return false;
    }

    public boolean remove(List<Card> cards)
    {
        if (pile.equals(cards))
        {
            pile.clear();
            return true;
        }
        return false;
    }

    public boolean contains(Card otherCard)
    {
        for (Card thisCard : pile) {
            if (thisCard == otherCard) {
                return true;
            }
        }
        return false;
    }

    public int nrOfRank(Rank theRank)
    {
        int counter = 0;
        for(Card card : pile) {
            if (card.getRank() == theRank) {
                counter++;
            }
        }
        return counter;
    }

    public int nrOfSuit(Suit theSuit)
    {
        int counter = 0;
        for(Card card : pile) {
            if (card.getSuit() == theSuit) {
                counter++;
            }
        }
        return counter;
    }

    private String[] toShortPile()
    {
        String[] shortPile = new String[getSize()];
        for (int i=0; i<getSize(); i++)
        {
            shortPile[i] = getCard(i).toShortString();
        }
        return shortPile;
    }

    /**
     * PRIVATE FIELDS & ACCESS METHODS
     */

    private final ArrayList<Card> pile;

    @Override
    public String toString() { return Arrays.toString(toShortPile()); }

    public int getSize()              { return pile.size(); }
    public Card getCard(int index)    { return pile.get(index); }
    public ArrayList<Card> getCards() { return new ArrayList<>(pile); }

}
