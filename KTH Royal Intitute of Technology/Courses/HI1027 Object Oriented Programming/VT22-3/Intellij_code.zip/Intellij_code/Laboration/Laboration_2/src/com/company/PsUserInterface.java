package com.company;

import com.company.cardutils.Card;
import com.company.ps.PsLogic;

import java.util.Locale;
import java.util.Scanner;

public class PsUserInterface
{
    private final PsLogic psLogic;
    private final Scanner scan;

    public PsUserInterface()
    {
        this.psLogic = new PsLogic();
        this.scan = new Scanner(System.in);
    }

    public void runProgram()
    {
        char choice;
        String answer;
        do
        {
            menu();
            System.out.print("Enter choice : ");
            answer = scan.nextLine().toUpperCase(Locale.ROOT);
            choice = answer.charAt(0);
            switch (choice)
            {
                case 'N' -> newGame();
                case 'X' -> System.out.println("Exiting program... DONE");
                default  -> System.out.println("ERROR! Unknown command");
            }
        } while (choice != 'X');
    }

    public void menu()
    {
        System.out.print(
           """
              
              ===== MENU =====
              N Start New Game
              X Exit
              ================
              """);
    }

    public void newGame()
    {
        System.out.println("Initializing a new game ...");
        System.out.println("READY\n");

        while (!psLogic.isGameOver()) { pickACard(); }

        System.out.println("GAME OVER");
        System.out.println("You got " + psLogic.getPoints() + " points!");
        System.out.println("===== YOUR PILES =====");
        System.out.println(psLogic.toString());
    }

    public void pickACard()
    {
        Card nextCard = psLogic.pickNextCard();
        System.out.println(psLogic.toString());
        System.out.println("Next card : " + nextCard.toShortString());

        boolean condition = false;
        int index;

        /*
        do {

            System.out.print("Select a pile [1-5] : ");
            String ans = scan.nextLine();
            System.out.println();
            index = Integer.parseInt(ans.trim());

        } while (index < 1 || index > 5);
        */

        do {

            do {

                System.out.print("Select a pile [1-5] : ");
                String ans = scan.nextLine();
                System.out.println();
                index = Integer.parseInt(ans.trim());

            } while (index < 1 || index > 5);

            if (0 <= psLogic.getPiles().get(index-1).getSize() || psLogic.getPiles().get(index-1).getSize() < 5) {
                condition = true;

                System.out.println("Index : " + index);
                System.out.println("Size  : " + psLogic.getPiles().get(index-1).getSize());
                System.out.println("Piles : " + psLogic.getPiles().toString());
            }

        } while(!condition);



        psLogic.addCardToPile(index);
    }
}
