package com.company.ps;

import com.company.cardutils.Pile;
import com.company.cardutils.Rank;
import com.company.cardutils.Suit;

public class PokerHands
{
    private PokerHands()
    {

    }

    public static PokerCombo getPokerCombos(Pile hand)
    {
        if      (isFOURofAKind(hand))  return PokerCombo.FOURofAKind;
        else if (isTHREEofAKind(hand)) return PokerCombo.THREEofAKind;
        else if (isFLUSH(hand))        return PokerCombo.FLUSH;
        else if (isTwoPairs(hand))     return PokerCombo.TWO_PAIRS;
        else if (isPair(hand))         return PokerCombo.PAIR;
        else                           return PokerCombo.NONE;
    }

    private static boolean isFOURofAKind(Pile hand)
    {
        for (Rank rank : Rank.values()) {
            if (hand.nrOfRank(rank) == 4)
                return true;
        }
        return false;
    }

    private static boolean isTHREEofAKind(Pile hand)
    {
        for (Rank rank : Rank.values()) {
            if (hand.nrOfRank(rank) == 3)
                return true;
        }
        return false;
    }

    private static boolean isFLUSH(Pile hand)
    {
        for (Suit suit : Suit.values()) {
            if (hand.nrOfSuit(suit) == 5)
                return true;
        }
        return false;
    }

    private static boolean isTwoPairs(Pile hand)
    {
        int counter = 0;
        for (Rank rank : Rank.values()) {
            if (hand.nrOfRank(rank) == 2)
                counter++;
        }
        return counter == 2;
    }

    private static boolean isPair(Pile hand)
    {
        int counter = 0;
        for (Rank rank : Rank.values()) {
            if (hand.nrOfRank(rank) == 2)
                counter++;
        }
        return counter == 1;
    }
}
