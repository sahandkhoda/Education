package com.company.cardutils;

/**
 * Represents an immutable playing card, with rank and suit.
 */
public class Card {

	private final Rank rank;
	private final Suit suit;

	public Card(Rank rank, Suit suit) {
		this.rank = rank;
		this.suit = suit;
	}

	public Rank getRank() {
		return rank;
	}
	public Suit getSuit() {
		return suit;
	}
	public int getRankValue() {
		return rank.getValue();
	}
	public int getSuitValue() {
		return suit.ordinal(); // default values, 0, 1, 2, 3
	}

	@Override
	public boolean equals(Object other)
	{
		if(other instanceof Card) {
			Card otherCard = (Card) other; // downcast reference type to Card
			return this.rank == otherCard.rank && this.suit == otherCard.suit;
		}
		return false;
	}

	@Override
	public String toString()
	{
		return rank + " of " + suit;
	}
	public String toShortString()
	{
		String info = "";
		switch (rank)
		{
			case ACE   -> info += 'A';
			case KING  -> info += 'K';
			case QUEEN -> info += 'Q';
			case JACK  -> info += 'J';
			default -> info += getRankValue();
		}
		switch (suit) {
			case SPADES   -> info += '\u2660';
			case HEARTS   -> info += '\u2764';
			case CLUBS    -> info += '\u2663';
			case DIAMONDS -> info += '\u2666';
		}
		return info;
	}
}
