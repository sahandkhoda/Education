package com.company.cardutils;

import java.util.ArrayList;
import java.util.Collections;

public class Deck
{
    public Deck()
    {
        deck = new ArrayList<>();
        fill();
    }

    public void fill()
    {
        clearDeck();
        for (Rank rank : Rank.values()) {
            for (Suit suit : Suit.values()) {
                deck.add(new Card(rank, suit));
            }
        }
        shuffleCards();
    }

    public void clearDeck() { deck.clear(); }
    public void shuffleCards() { Collections.shuffle(deck); }

    public Card dealCard()
    {
        Card cardToDeal = deck.get(getSize()-1);
        deck.remove(deck.size()-1);
        return cardToDeal;
    }

    /**
     * PRIVATE FIELDS & ACCESS METHODS
     */

    private final ArrayList<Card> deck;

    @Override
    public String toString()
    {
        return "The top card : " + deck.get(getSize()-1).toShortString() + "\n"
             + "Total cards (left) : " + getSize();
    }

    public int getSize() { return deck.size(); }

}
