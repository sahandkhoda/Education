package com.company.ps;

import com.company.cardutils.*;

import java.util.ArrayList;
import java.util.Arrays;

public class PsLogic implements IPsLogic
{
    private int cardCount;
    private Deck deck;
    private Card nextCard;
    private Pile[] arrPiles;

    public PsLogic()
    {
        initNewGame();
    }

    public void initNewGame()
    {
        deck = new Deck();

        int nrOfPiles = 5;
        arrPiles = new Pile[nrOfPiles];
        for (int i = 0; i< nrOfPiles; i++) {
            arrPiles[i] = new Pile();
        }
        cardCount = 0;
    }

    public Card pickNextCard()
    {
        nextCard = deck.dealCard();
        if (nextCard == null) throw new IllegalStateException();
        return nextCard;
    }

    public void addCardToPile(int pile)
    {
        if (nextCard == null) throw new IllegalStateException();

        // OBS! The user enters 1-5, but array index is 0-4.
        arrPiles[pile-1].add(nextCard);
        cardCount++;
    }

    public boolean isGameOver() { return getCardCount() == 25; }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        for (Pile pile : arrPiles) {
            builder.append(pile.toString()).append("\n");
        }
        return builder.toString();
    }

    public ArrayList<Pile> getPiles()
    {
        return new ArrayList<>(Arrays.asList(arrPiles));
    }

    public int getCardCount() { return cardCount; }

    public int getPoints()
    {
        int sum = 0;
        for (Pile pile : arrPiles) {
            sum += getPilePoints(pile);
        }
        return sum;
    }

    private int getPilePoints(Pile aPile)
    {
        int points = 0;
        switch (PokerHands.getPokerCombos(aPile))
        {
            case PAIR         -> points = 1;
            case TWO_PAIRS    -> points = 3;
            case FLUSH        -> points = 5;
            case THREEofAKind -> points = 6;
            case FOURofAKind  -> points = 16;
        }
        return points;
    }

}

