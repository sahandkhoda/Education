package com.company.ps;

public enum PokerCombo
{
    NONE,
    PAIR,
    TWO_PAIRS,
    FLUSH,
    THREEofAKind,
    FOURofAKind
}
