package com.kth.se.laboration_5_ny.controller;

import com.kth.se.laboration_5_ny.model.ImagePixelMatrixConverter;
import com.kth.se.laboration_5_ny.model.Rotate;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class handleRotate implements EventHandler<ActionEvent>
{
    /** Rotates the image */
    @Override
    public void handle(ActionEvent actionEvent) {
        Rotate rotate = new Rotate();
        FileIO.image = ImagePixelMatrixConverter.getImage(rotate.getTheMatrix());
        FileIO.imageView.setImage(FileIO.image);
    }
}
