package com.kth.se.laboration_5_ny.view;

import com.kth.se.laboration_5_ny.controller.FileIO;
import com.kth.se.laboration_5_ny.model.Contrast;
import com.kth.se.laboration_5_ny.model.ImagePixelMatrixConverter;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Optional;

public class ContrastView
{
    /** PRIVATE DATA FIELDS */
    private final ImageView view1, view2;
    private final Slider    slider;
    private final Stage     newStage;

    /** ACCESS METHODS */
    public Stage getNewStage() { return newStage; }

    /** CONSTRUCTOR */
    public ContrastView(ImageView theView, Slider slider) {

        // ORIGINAL IMAGE
        this.view1 = new ImageView();
        setView(view1);

        // MODIFIED IMAGE
        this.view2 = theView;
        setView(view2);

        // SLIDER
        this.slider = slider;

        // NEW STAGE
        newStage = new Stage();
        setNewStage();
    }

    /** PRIVATE METHODS */
    private void setView(ImageView theView) {
        theView.setImage(FileIO.image);
        theView.setFitHeight(500);
        theView.setFitWidth (500);
        theView.setPreserveRatio(true);
    }

    private void setNewStage()
    {
        Contrast contrast = new Contrast(slider);

        Button sliderButton = new Button("Save Value");
        GridPane gridPane = new GridPane();
        gridPane.add(new Label("ORIGINAL IMAGE"),0,0);
        gridPane.add(new Label("MODIFIED IMAGE"),1,0);
        gridPane.add(view1,0,1);
        gridPane.add(view2,1,1);
        gridPane.add(slider,1,2);
        gridPane.add(sliderButton,1,3);
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        gridPane.setPadding(new Insets(20));

        Dialog<String> dialog = new Dialog<String>();
        dialog.setTitle("CONTRAST GENERATOR");
        dialog.setResizable(true);
        dialog.getDialogPane().setContent(gridPane);

        sliderButton.setOnAction(event -> {
            FileIO.image = ImagePixelMatrixConverter.getImage(contrast.processImage(ImagePixelMatrixConverter.getPixelMatrix(FileIO.image)));
            FileIO.imageView.setImage(FileIO.image);
        });

        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CLOSE);
        dialog.show();
    }
}
