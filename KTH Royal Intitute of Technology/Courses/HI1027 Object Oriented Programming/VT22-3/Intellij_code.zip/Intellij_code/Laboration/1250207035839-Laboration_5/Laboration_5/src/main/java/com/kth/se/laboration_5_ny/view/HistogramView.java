package com.kth.se.laboration_5_ny.view;

import com.kth.se.laboration_5_ny.controller.FileIO;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class HistogramView
{
    /** DATA FIELD */
    private final Stage newStage;

    /** ACCESS METHOD */
    public Stage getNewStage() { return newStage; }

    /** CONSTRUCTOR */
    public HistogramView(LineChart<String, Number> chartHistogram) {
        HBox hBox = new HBox(FileIO.imageView, chartHistogram);
        hBox.setPadding(new Insets(20));
        newStage = new Stage();
        newStage.setTitle("HISTOGRAM GENERATOR");
        newStage.setScene(new Scene(hBox, 1000, 400));
    }
}
