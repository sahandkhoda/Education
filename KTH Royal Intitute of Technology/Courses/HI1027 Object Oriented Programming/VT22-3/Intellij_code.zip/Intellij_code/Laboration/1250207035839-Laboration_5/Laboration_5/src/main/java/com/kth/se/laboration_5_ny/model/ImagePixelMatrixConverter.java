package com.kth.se.laboration_5_ny.model;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class ImagePixelMatrixConverter {

    public static int[][] getPixelMatrix(Image image) {
        int width  = (int) image.getWidth();
        int height = (int) image.getHeight();

        int[][] pixelMatrix = new int[width][height];
        PixelReader reader = image.getPixelReader();
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixelMatrix[x][y] = reader.getArgb(x, y);
            }
        }
        return pixelMatrix;
    }

    public static Image getImage(int[][] pixelMatrix) {
        int width  = pixelMatrix.length;
        int height = pixelMatrix[0].length;

        WritableImage outImg = new WritableImage(width, height);
        PixelWriter outPixels = outImg.getPixelWriter();
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                outPixels.setArgb(x, y, pixelMatrix[x][y]);
            }
        }
        return outImg;
    }
}