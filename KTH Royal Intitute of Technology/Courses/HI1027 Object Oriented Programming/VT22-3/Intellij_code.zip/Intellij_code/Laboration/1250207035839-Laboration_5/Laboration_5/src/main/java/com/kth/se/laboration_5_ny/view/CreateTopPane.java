package com.kth.se.laboration_5_ny.view;

import com.kth.se.laboration_5_ny.Main;
import com.kth.se.laboration_5_ny.controller.*;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.VBox;

public class CreateTopPane
{
    /** PRIVATE DATA FIELDS */
    private final VBox topPane;


    /** CONSTRUCTOR */
    public CreateTopPane() {
        this.topPane = new VBox();
        setTopPane();
    }

    /** PRIVATE METHODS */
    private void setTopPane() {

        // MENU BAR
        MenuBar menuBar = new MenuBar();
        javafx.scene.control.Menu menuFile     = new javafx.scene.control.Menu("File");
        javafx.scene.control.Menu menuGenerate = new javafx.scene.control.Menu("Generate");
        javafx.scene.control.Menu menuHelp     = new javafx.scene.control.Menu("Help");
        menuBar.getMenus().addAll(menuFile, menuGenerate, menuHelp);

        // MENU ITEMS
        MenuItem save      = new MenuItem("Save to file [PNG]");
        MenuItem histogram = new MenuItem("Histogram");
        MenuItem contrast  = new MenuItem("Contrast");
        MenuItem grey      = new MenuItem("Grey scale");
        MenuItem rotate    = new MenuItem("Rotate 90°");
        MenuItem moreHelp  = new MenuItem("Help me...");

        // EVENT HANDLERS (Controller)
        HandleGenerate handleGenerate = new HandleGenerate(save, histogram, contrast, grey, rotate);

        // ADDING TO TOP PANE (MENU BAR)
        menuFile    .getItems().add(save);
        menuGenerate.getItems().addAll(histogram, contrast, grey, rotate);
        menuHelp    .getItems().add(moreHelp);
        topPane     .getChildren().add(menuBar);

        Main.root.setTop(topPane);
    }

    /** ACCESS METHOD */
    public VBox getTopPane() { return topPane; }
}
