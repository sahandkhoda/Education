module com.kth.se.laboration_5_ny {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.swing;

    opens com.kth.se.laboration_5_ny to javafx.fxml;
    exports com.kth.se.laboration_5_ny;
    opens com.kth.se.laboration_5_ny.controller to javafx.fxml;
    exports com.kth.se.laboration_5_ny.controller;

}