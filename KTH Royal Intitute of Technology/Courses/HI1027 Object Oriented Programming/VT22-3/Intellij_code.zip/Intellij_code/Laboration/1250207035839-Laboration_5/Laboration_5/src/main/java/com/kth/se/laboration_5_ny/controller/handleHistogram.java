package com.kth.se.laboration_5_ny.controller;

import com.kth.se.laboration_5_ny.model.ImageHistogram;
import com.kth.se.laboration_5_ny.view.HistogramView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.stage.Stage;

public class handleHistogram implements EventHandler<ActionEvent>
{
    /** DATA FIELDS */
    private final LineChart<String, Number> chartHistogram;

    /** CONSTRUCTOR */
    public handleHistogram() {
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis   yAxis = new NumberAxis();
        chartHistogram = new LineChart<>(xAxis, yAxis);
        chartHistogram.setCreateSymbols(false);
    }

    /** HANDLE ACTION EVENT */
    @Override
    public void handle(ActionEvent actionEvent) {
        chartHistogram.getData().clear();
        ImageHistogram imageHistogram = new ImageHistogram();
        if (imageHistogram.isSuccess()) {
            chartHistogram.getData().addAll(
                    imageHistogram.getSeriesAlpha(),
                    imageHistogram.getSeriesRed(),
                    imageHistogram.getSeriesGreen(),
                    imageHistogram.getSeriesBlue());
        }
        HistogramView histogramView = new HistogramView(chartHistogram);
        Stage newStage = histogramView.getNewStage();
        newStage.setOnCloseRequest(event -> FileIO.setImageView());
        newStage.show();
    }
}
