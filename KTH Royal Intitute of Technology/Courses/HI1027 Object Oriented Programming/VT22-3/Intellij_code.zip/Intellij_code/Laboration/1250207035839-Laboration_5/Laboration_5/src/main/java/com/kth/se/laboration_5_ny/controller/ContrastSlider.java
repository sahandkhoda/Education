package com.kth.se.laboration_5_ny.controller;

import javafx.scene.control.Slider;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.ImageView;

public class ContrastSlider
{
    /** DATA FIELDS */
    private final Slider    slider;
    private final ImageView theView;

    /** ACCESS METHOD */
    public ImageView getTheView() { return theView;   }
    public Slider    getSlider()  { return slider; }

    /** CONSTRUCTOR */
    public ContrastSlider() {
        theView = new ImageView(FileIO.image);
        slider  = new Slider(0, 1, 0);
        setSlider();
    }

    /** PRIVATE METHOD */
    private void setSlider() {
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setBlockIncrement(10);
        slider.setMajorTickUnit(0.25);
        slider.valueProperty().addListener((observable, oldValue, newValue) -> {
            ColorAdjust colorAdjust = new ColorAdjust();
            colorAdjust.setContrast((Double) newValue);
            theView.setEffect(colorAdjust);
        });
    }
}
