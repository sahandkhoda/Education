package com.kth.se.laboration_5_ny.controller;

import com.kth.se.laboration_5_ny.model.GreyScale;
import com.kth.se.laboration_5_ny.model.ImagePixelMatrixConverter;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class handleGreyScale implements EventHandler<ActionEvent>
{
    @Override
    public void handle(ActionEvent actionEvent) {
        GreyScale greyScale = new GreyScale();
        FileIO.image = ImagePixelMatrixConverter.getImage(greyScale.getTheMatrix());
        FileIO.imageView.setImage(FileIO.image);
    }
}
