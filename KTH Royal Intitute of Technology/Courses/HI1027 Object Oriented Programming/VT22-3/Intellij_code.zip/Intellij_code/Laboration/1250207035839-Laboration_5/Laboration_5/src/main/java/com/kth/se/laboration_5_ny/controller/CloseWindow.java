package com.kth.se.laboration_5_ny.controller;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.util.Optional;

public class CloseWindow
{
    /** PRIVATE DATA FIELD */
    private final Alert exitAlert;

    /** CONSTRUCTOR */
    public CloseWindow(Stage stage) {
        this.exitAlert = new Alert(Alert.AlertType.INFORMATION,
                              "Are you sure you want to exit?",
                               ButtonType.YES,
                               ButtonType.CANCEL);

        exitAlert.setTitle("Information");
        exitAlert.setHeaderText("Confirmation");

        stage.setOnCloseRequest(event -> {
            Optional<ButtonType> result = exitAlert.showAndWait();
            if (result.get() == ButtonType.CANCEL) {
                event.consume();
            }
        });
    }
}
