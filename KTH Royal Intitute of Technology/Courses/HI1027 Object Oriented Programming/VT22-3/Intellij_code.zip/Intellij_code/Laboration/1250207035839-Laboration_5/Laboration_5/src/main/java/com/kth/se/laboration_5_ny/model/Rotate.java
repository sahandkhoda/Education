package com.kth.se.laboration_5_ny.model;

import com.kth.se.laboration_5_ny.controller.FileIO;

public class Rotate implements ImageProcessing
{
    /** PRIVATE FIELD & ACCESS METHOD */
    private final int[][] theMatrix;
    public int[][] getTheMatrix() { return theMatrix; }

    /** CONSTRUCTOR */
    public Rotate() {
        this.theMatrix = processImage(ImagePixelMatrixConverter.getPixelMatrix(FileIO.image));
    }

    @Override
    public int[][] processImage(int[][] originalMatrix) {
        int h = originalMatrix[0].length;
        int w = originalMatrix.length;

        int[][] mirror = new int[h][w];
        for(int i = 0 ; i < h; i++){
            for(int j = 0 ; j < w; j++){
                mirror[i][j] = originalMatrix[j][h-i-1];
            }
        }
        return mirror;
    }
}
