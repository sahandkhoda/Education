package com.kth.se.laboration_5_ny;

import com.kth.se.laboration_5_ny.controller.CloseWindow;
import com.kth.se.laboration_5_ny.controller.FileIO;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {

    public static BorderPane root;

    @Override
    public void start(Stage primaryStage)
    {
        root = new BorderPane();
        CloseWindow closeWindow = new CloseWindow(primaryStage);
        Scene scene = new Scene(root, 600, 600);
        scene.setFill(Color.WHITE);

        FileIO.open();
        FileIO io = new FileIO(primaryStage);

        primaryStage.setTitle("IMAGE PROCESSING");
        primaryStage.setScene(scene);
        primaryStage.sizeToScene();
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}