package com.kth.se.laboration_5_ny.model;

import com.kth.se.laboration_5_ny.controller.FileIO;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class GreyScale implements ImageProcessing
{
    /** PRIVATE DATA FIELD & ACCESS METHOD */
    private final int[][] theMatrix;
    public int[][] getTheMatrix() { return theMatrix; }

    /** CONSTRUCTOR */
    public GreyScale() {
        this.theMatrix = processImage(ImagePixelMatrixConverter.getPixelMatrix(FileIO.image));
    }

    @Override
    public int[][] processImage(int[][] originalMatrix)
    {
        PixelReader origPixels = ImagePixelMatrixConverter.getImage(originalMatrix).getPixelReader();

        // Get the image width and height dimensions
        int width  = originalMatrix.length;
        int height = originalMatrix[0].length;

        WritableImage outImg = new WritableImage(width, height);
        PixelWriter outPixels = outImg.getPixelWriter();

        // Convert to grayscale by looping over pixels, beginning at top-most left coordinate (0,0)
        for(int x = 0; x < width; x++) {
            for(int y = 0; y < height; y++) {
                int p = origPixels.getArgb(x, y);

                // ImagePixelMatrixConverter.getImage(originalMatrix).getPixelReader().getArgb(x,y);

                int a = (p>>24) & 0xff;
                int r = (p>>16) & 0xff;
                int g = (p>>8) & 0xff;
                int b = p & 0xff;

                // Calculate average color (grayscale it)
                int avg = (r+g+b)/3;

                // Replace RGB value with avg
                p = (a<<24) | (avg<<16) | (avg<<8) | avg;
                outPixels.setArgb(x, y, p);
            }
        }
        return ImagePixelMatrixConverter.getPixelMatrix(outImg);
    }
}
