package com.kth.se.laboration_5_ny.controller;

import com.kth.se.laboration_5_ny.view.ContrastView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.stage.Stage;

public class handleContrast implements EventHandler<ActionEvent>
{
    @Override
    public void handle(ActionEvent actionEvent)
    {
        ContrastSlider cSlider = new ContrastSlider();
        ContrastView   cView   = new ContrastView(cSlider.getTheView(), cSlider.getSlider());

        //Stage newStage = cView.getNewStage();
        //newStage.setOnCloseRequest(event -> FileIO.setImageView());
        //newStage.show();
    }
}
