package com.kth.se.laboration_5_ny.model;

public interface ImageProcessing
{
    /**
     * Implemented by every image processing method.
     * @param originalMatrix the original matrix
     * @return the matrix
     */

    public abstract int[][] processImage(int[][] originalMatrix);
}
