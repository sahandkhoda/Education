package com.kth.se.laboration_5_ny.controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.io.IOException;

public class handleSave implements EventHandler<ActionEvent>
{
    @Override
    public void handle(ActionEvent actionEvent) {
        try {
            FileIO.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
