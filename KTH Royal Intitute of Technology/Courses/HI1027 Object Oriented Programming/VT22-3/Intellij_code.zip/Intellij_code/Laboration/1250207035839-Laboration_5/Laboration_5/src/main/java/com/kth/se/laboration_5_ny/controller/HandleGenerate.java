package com.kth.se.laboration_5_ny.controller;

import javafx.event.ActionEvent;
import javafx.scene.control.MenuItem;

public class HandleGenerate
{
    public HandleGenerate(MenuItem save,
                          MenuItem histogram,
                          MenuItem contrast,
                          MenuItem grey,
                          MenuItem rotate)
    {
        save     .addEventHandler(ActionEvent.ACTION, new handleSave());
        histogram.addEventHandler(ActionEvent.ACTION, new handleHistogram());
        contrast .addEventHandler(ActionEvent.ACTION, new handleContrast());
        grey     .addEventHandler(ActionEvent.ACTION, new handleGreyScale());
        rotate   .addEventHandler(ActionEvent.ACTION, new handleRotate());
    }
}
