package com.kth.se.laboration_5_ny.view;

import com.kth.se.laboration_5_ny.Main;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;


public class CreateBottomPane
{
    /** PRIVATE DATA FIELDS */
    private final FlowPane bottomPane;
    private final Button   loadButton;

    /** CONSTRUCTOR */
    public CreateBottomPane() {
        this.bottomPane = new FlowPane();
        this.loadButton = new Button("Load Image File [PNG]");
        setBottomPane();
    }

    /** PRIVATE METHOD */
    private void setBottomPane() {
        bottomPane.setAlignment(Pos.CENTER);
        bottomPane.setPadding(new Insets(5, 5, 5, 5));
        bottomPane.getChildren().add(loadButton);
        Main.root.setBottom(bottomPane);
    }

    /** ACCESS METHOD */
    public Button getLoadButton() { return loadButton; }
}
