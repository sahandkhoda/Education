package com.kth.se.laboration_5_ny.controller;

import com.kth.se.laboration_5_ny.Main;
import com.kth.se.laboration_5_ny.view.CreateBottomPane;
import com.kth.se.laboration_5_ny.view.CreateTopPane;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class FileIO
{
    /** DATA FIELDS */
    public  static Image       image;
    public  static ImageView   imageView;
    private static FileChooser fileChooser;
    private static Stage       stage;

    /** STATIC METHODS */
    public static void open() {
        imageView   = new ImageView();
        fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("PNG Files", "*.png");
        fileChooser.getExtensionFilters().add(extFilter);
        fileChooser.setTitle("Open Image File [PNG]");
    }
    public static void close() throws IOException {

        FileChooser saveFileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("PNG Files", "*.png");
        saveFileChooser.setTitle("Save Image File [PNG]");
        saveFileChooser.getExtensionFilters().add(extFilter);
        BufferedImage bufferedImage = SwingFXUtils.fromFXImage(FileIO.image, null);
        ImageIO.write(bufferedImage, "png", saveFileChooser.showSaveDialog(stage));

    }
    public static void setImageView() { Main.root.setCenter(imageView); }

    /** CONSTRUCTOR */
    public FileIO (Stage primaryStage) {
        stage = primaryStage;
        CreateBottomPane b = new CreateBottomPane();
        b.getLoadButton().setOnAction(event -> openAndLoadImage(primaryStage));
    }

    /** PRIVATE METHOD */
    private void openAndLoadImage(Stage stage) {
        File file = fileChooser.showOpenDialog(stage);

        if(file != null) {
            image = new Image(file.toURI().toString());
            imageView.setImage(image);
            imageView.fitWidthProperty().bind(stage.widthProperty());
            imageView.setPreserveRatio(true);
            imageView.setSmooth(true);
            imageView.setRotate(0);

            CreateTopPane t = new CreateTopPane();
            Main.root.setTop(t.getTopPane());
            setImageView();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("WARNING");
            alert.setHeaderText("NO FILE SELECTED");
            alert.setContentText("You have to select a PNG file.");
            alert.show();
        }
    }
}