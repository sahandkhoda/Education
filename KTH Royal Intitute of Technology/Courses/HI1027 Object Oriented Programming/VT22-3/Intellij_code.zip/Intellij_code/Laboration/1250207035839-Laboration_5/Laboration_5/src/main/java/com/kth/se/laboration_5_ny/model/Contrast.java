package com.kth.se.laboration_5_ny.model;

import com.kth.se.laboration_5_ny.controller.FileIO;

import javafx.scene.control.Slider;
import javafx.scene.image.*;

public class Contrast implements ImageProcessing
{
    /** DATA FIELDS */
    private final Slider slider;
    //private final int[][] theMatrix;

    /** ACCESS METHODS */
    public Slider    getSlider()    { return this.slider;    }
    //public int[][]   getTheMatrix() { return this.theMatrix; }


    /** CONSTRUCTOR */
    public Contrast(Slider slider) {
        this.slider = slider;
        //this.theMatrix = processImage(ImagePixelMatrixConverter.getPixelMatrix(FileIO.image));
    }

    /** PRIVATE METHODS */
    @Override
    public int[][] processImage(int[][] originalMatrix)
    {
        PixelReader origPixels = ImagePixelMatrixConverter.getImage(originalMatrix).getPixelReader();

        int width  = originalMatrix.length;
        int height = originalMatrix[0].length;

        WritableImage outImg = new WritableImage(width, height);
        PixelWriter outPixels = outImg.getPixelWriter();

        for(int x = 0; x < width; x++) {
            for(int y = 0; y < height; y++) {
                int color = origPixels.getArgb(x,y);
                int a = ((color >> 24) & 0xff);
                int r = (int) (((color >> 16) & 0xff) * (slider.getValue())+1);
                int g = (int) (((color >> 8) & 0xff)  * (slider.getValue())+1);
                int b = (int) (((color) & 0xff)       * (slider.getValue())+1);

                int c = (a << 24) | (r << 16) | (g << 8) | b;
                System.out.println(r + " " + g + " " + b + " " + a + "    " + c);
                outPixels.setArgb(x, y, c);
            }
        }
        System.out.println("SLIDER VALUE : " + slider.getValue());
        return ImagePixelMatrixConverter.getPixelMatrix(outImg);
    }
}

