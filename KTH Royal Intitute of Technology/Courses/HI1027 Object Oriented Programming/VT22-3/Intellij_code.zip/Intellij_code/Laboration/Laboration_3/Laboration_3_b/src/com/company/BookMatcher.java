package com.company;

/**
 * Interface for classes implementing the "logic" for the collection of books.
 * It is redundant to add "abstract" and "public" on the methods.
 */
public interface BookMatcher
{
    /**
     * Searches for book (title, author, or ISBN)
     * @param bookToMatch the book to match (compare) with
     * @return whether it matches or not
     */
    abstract public boolean matches(Book bookToMatch);

}
