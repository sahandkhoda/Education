package com.company;

import java.io.Serializable;

public class Isbn implements Serializable
{
    public static Isbn createIsbn(String isbnStr) { return new Isbn(isbnStr); }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final String isbnStr;
    private static final String isbnPattern = "^(19|20)?[0-9]{13}$";

    private Isbn(String isbnStr) throws IllegalArgumentException {
        this.isbnStr = isbnStr.replace("-", "");
        if (!this.isbnStr.matches(isbnPattern))
            throw new IllegalArgumentException("Illegal ISBN : " + isbnStr);
        }

    public String getIsbnStr() { return isbnStr; }

    @Override
    public String toString()   { return "The ISBN is " + getIsbnStr(); }

}
