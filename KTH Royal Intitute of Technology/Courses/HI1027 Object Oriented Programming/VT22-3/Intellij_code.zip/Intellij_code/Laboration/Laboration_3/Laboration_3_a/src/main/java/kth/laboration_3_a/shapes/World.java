package kth.laboration_3_a.shapes;

import javafx.scene.paint.Color;

/**
 * A representation of a world containing a set of moving shapes. NB! The worlds
 * y-axis points downward.
 *
 * @author Anders Lindström, anderslm@kth.se 2021-09-15
 */
public class World {

    private double width, height; // this worlds width and height
    private final Shape[] shapes; // an array of references to the shapes

    /**
     * Creates a new world, containing a pad and a set of balls. NB! The worlds
     * y-axis points downward.
     *
     * @param width the width of this world
     * @param height the height of this world
     */
    public World(double width, double height) {
        this.width = width;
        this.height = height;

        shapes = new Shape[3];

        // Create the actual Shape array and objects (subtypes)
        shapes[0] = new Line(0, 0, 100, 50, Color.RED);
        shapes[1] = new Circle();
        shapes[2] = new Rectangle(0, 0, 60, 40, false, Color.BLUE);

        // Sets the velocity of each Shape object
        shapes[0].setVelocity(20, 40);  // pixels per second
        shapes[1].setVelocity(10, 40);  // pixels per second
        shapes[2].setVelocity(50, 40);  // pixels per second

        for (Shape s : shapes) {
            if(s instanceof FillableShape) {
                FillableShape fs = (FillableShape) s;
                fs.setFilled(true);
            }
        }
    }

    /**
     * Sets the new dimensions, in pixels, for this world. The method could be
     * used for example when the canvas is reshaped.
     *
     * @param newWidth
     * @param newHeight
     */
    public void setDimensions(double newWidth, double newHeight) {
        this.width = newWidth;
        this.height = newHeight;
    }

    /**
     * Move the world one step, based on the time elapsed since last move.
     *
     * @param elapsedTimeNs the elapsed time in nanoseconds
     */
    public void moveAndConstrain(long elapsedTimeNs) {
        // alternative loop: for(Shape s : shapes) { ...
        for (Shape s : shapes) {
            s.moveAndConstrain(elapsedTimeNs, 0, 0, width, height);
        }
    }

    /**
     * Returns a copy of the list of ball references.
     * Due to the implementation of clone, a shallow copy is returned.
     *
     * @return a copy of the list of balls
     */
    public Shape[] getShapes() {
        return (Shape[]) shapes.clone();
    }
}

