package com.company;

public class IsbnMatcher implements BookMatcher
{
    public IsbnMatcher(Isbn toMatch) { this.toMatch = toMatch; }

    @Override
    public boolean matches(Book book) {
        return book.getIsbnStr().equals(toMatch.getIsbnStr());
    }

    /** PRIVATE FIELD */
    private final Isbn toMatch;
}
