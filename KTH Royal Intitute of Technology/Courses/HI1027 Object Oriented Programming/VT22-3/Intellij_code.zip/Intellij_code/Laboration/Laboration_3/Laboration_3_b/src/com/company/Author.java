package com.company;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Locale;

public class Author implements Serializable
{
     public Author(String name, LocalDate dateOfBirth)
    {
        this.name = name.toUpperCase(Locale.ROOT);
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * PRIVATE FIELDS & ACCESS METHODS
     */
    private final String name;
    private final LocalDate dateOfBirth;

    @Override
    public String toString()
    {
        return getName() + " [" + getDateOfBirth() + "]";
    }

    public String getName() { return name; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
}
