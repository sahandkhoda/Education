package com.company;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Book implements Serializable, Comparable
{
    public Book(String title, List<Author> authors, Genre genre, Isbn isbn, int rating) {
        theAuthors = authors;
        this.title  = title;
        this.genre  = genre;
        this.isbn   = isbn;
        this.rating = rating;
    }

    public void addAuthor(Author author) { theAuthors.add(author); }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final String title;
    private final List<Author> theAuthors;
    private final Genre genre;
    private final Isbn isbn;
    private final int rating;

    @Override
    public String toString()
    {
        return " --------" + "\n" +
               " Title  : " + getTitle()    + "\n" +
               " Author : " + getAuthors()  + "\n" +
               " Genre  : " + getGenre()    + "\n" +
               " ISBN   : " + getIsbnStr()  + "\n" +
               " Rating : " + getRating()   + "\n";
    }

    public String       getTitle()   { return title; }
    public List<Author> getAuthors() { return new ArrayList<>(theAuthors); }
    public Genre        getGenre()   { return genre; }
    public Isbn         getIsbn()    { return isbn; }
    public String       getIsbnStr() { return isbn.getIsbnStr(); }
    public int          getRating()  { return rating; }

    @Override
    public int compareTo(Object o) {
        if(this.getRating() == (((Book) o).getRating())) {
            return this.getTitle().compareTo(((Book) o).getTitle());
        } else if (this.getRating() < (((Book) o).getRating())) {
            return 1;
        } else
            return -1;
    }
}
