package kth.laboration_3_a.shapes;

import javafx.scene.paint.Color;

abstract public class FillableShape extends Shape {

    private boolean filled;

    protected FillableShape(double x, double y, boolean filled, Color color) {
        super(x, y, color);
        this.filled = filled;
    }

    protected FillableShape() {
        super();
        this.filled = true;
    }

    public boolean isFilled() { return filled; }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }
}