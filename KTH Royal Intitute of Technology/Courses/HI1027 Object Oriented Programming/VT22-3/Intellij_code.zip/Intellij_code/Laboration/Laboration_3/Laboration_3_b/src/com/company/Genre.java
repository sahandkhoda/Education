package com.company;

public enum Genre
{
    DRAMA,
    ROMANCE,
    CRIME,
    HORROR,
    ADVENTURE
}
