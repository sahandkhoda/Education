package kth.laboration_3_a.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Circle extends FillableShape {

    public Circle(double x, double y, double diameter, boolean filled, Color color) {
        super(x, y, filled, color);
        this.diameter = diameter;
    }

    public Circle() {
        super();
        this.diameter = 50;
    }

    public void setDiameter(double newDiameter) { this.diameter = newDiameter; }

    @Override
    public void paint(GraphicsContext gc) {
        gc.setStroke(getColor());
        gc.strokeOval(getX(), getY(), diameter, diameter);
        if(isFilled()) {
            gc.setFill(getColor());
            gc.fillOval(getX(), getY(), diameter, diameter);
        }
    }

    @Override
    public void constrain(double boxX, double boxY,
                          double boxWidth, double boxHeight) {
        super.constrain(boxX, boxY, boxWidth, boxHeight);
        double newDx = getDx();
        double newDy = getDy();

        if (diameter + getX() < boxX) {
            newDx = Math.abs(getDx());
        } else if (diameter + getX() > boxWidth) {
            newDx = -Math.abs(getDx());
        }
        if (diameter + getY() < boxY) {
            newDy = Math.abs(getDy());
        } else if (diameter + getY() > boxHeight) {
            newDy = -Math.abs(getDy());
        }
        setVelocity(newDx, newDy);
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private double diameter;

    public double getDiameter() { return diameter; }

    @Override
    public String toString() {
        return super.toString() +
             " , diameter=" + diameter;
    }
}