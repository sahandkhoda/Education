package com.company;

public class AuthorMatcher implements BookMatcher
{
    public AuthorMatcher(Author toMatch) { this.toMatch = toMatch; }

    @Override
    public boolean matches(Book book) {
        for (Author author : book.getAuthors()) {
            if (author.getName().contains(toMatch.getName())) {
                return true;
            }
        }
        return false;
    }

    /** PRIVATE FIELD */
    private final Author toMatch;
}
