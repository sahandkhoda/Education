package com.company;

import java.io.IOException;
import java.util.*;

import static com.company.BooksIO.deSerializeFromFile;
import static com.company.BooksIO.serializeToFile;

public class CollectionOfBooks
{
    /**
     * Creates a new instance of ArrayList</Book>, representing the
     * collection of books. Suitable methods of ArrayList can be
     * implemented for a more flexible code.
     */
    public CollectionOfBooks() { theBooks = new ArrayList<>(); }

    /**
     * Opens a file.
     * If found, the file content is added to the empty ArrayList theBooks.
     * If not found, alert the user with message and theBooks is still empty.
     */
    public void openFile() {
        try {
            theBooks.addAll(deSerializeFromFile("BookCollection.io"));
            if (theBooks.isEmpty()) {
                System.out.println();
                System.out.println("[FILE IS FOUND BUT NULL]");
            } else {
                System.out.println();
                System.out.println("[FILE IS FOUND]");
            }
        } catch (ClassNotFoundException | IOException e) {
            System.out.println();
            System.out.println("[FILE IS NOT FOUND]");
        }
    }

    /**
     * Saves and closes the file called "BookCollection.io".
     * The program then exits.
     * @throws IOException the exception
     */
    public void closeFile() throws IOException {
        serializeToFile("BookCollection.io", getTheBooks());
        System.out.println("Saving collection...");
        System.out.println("DONE");
    }

    /**
     * Adds a new book to the collection.
     * If null is passed as book argument, an exception is thrown.
     * @param book the book to be added
     * @throws IllegalArgumentException the exception
     */
    public void addBook(Book book) {
        if (book==null) throw new IllegalArgumentException("OBS! Book is NULL");
        theBooks.add(book);
    }

    /**
     * Removes the specified book, if it exists in the collection.
     * @param isbn (ISBN)
     */
    public void removeBook(Isbn isbn) {
        theBooks.removeIf(book -> isbn.getIsbnStr().equals(book.getIsbnStr()));
    }

    public List<Book> searchForBooks(BookMatcher matcher) {
        ArrayList<Book> tempList = new ArrayList<>();
        for (Book book : theBooks) {
            if (matcher.matches(book)) {
                tempList.add(book);
                sort(tempList);
            }
        }
        return tempList;
    }

    public void sort(ArrayList<Book> list) {
        Collections.sort(list);

        /*
        // Sorts the ratings
        for (int i=0; i<list.size()-1; i++) {
            for (int j = i + 1; j < list.size(); j++) {
                if (list.get(i).getRating() > (list.get(j).getRating())) {
                    Collections.swap(list, i, j);
                }
            }
        }

        // Sorts the titles
        for (int i=0; i<list.size()-1; i++) {
            for (int j = i + 1; j < list.size(); j++) {
                if (list.get(i).getTitle().compareTo(list.get(j).getTitle()) > 0) {
                    Collections.swap(list, i, j);
                    Collections.sort(list);
                }
            }
        }
         */
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final List<Book> theBooks;

    public List<Book> getTheBooks() { return new ArrayList<>(theBooks); }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (Book book : theBooks) {
            builder.append(book.toString());
        }
        return builder.toString();
    }
}