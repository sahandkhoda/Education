package kth.laboration_3_a.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Line extends Shape {

    public Line(double x, double y, double x2, double y2, Color color) {
        super(x, y, color);  // Sends the values to super constructor Shape
        this.x2 = x2;
        this.y2 = y2;
    }

    public Line() {
        super();            // Default values x=0, y=0, color=Color.BLACK
        this.x2 = 100;
        this.y2 = 100;
    }

    public void setX2(double x2) { if (x2>0 && x2>getX()) this.x2 = x2; }
    public void setY2(double y2) { if (y2>0 && y2>getY()) this.y2 = y2; }

    @Override
    public void move(long elapsedTimeNs) {
        super.move(elapsedTimeNs);                 // Updates x and y
        x2 += getDx() * elapsedTimeNs / BILLION;   // Updates x2
        y2 += getDy() * elapsedTimeNs / BILLION;   // Updates y2
    }

    @Override
    public void paint(GraphicsContext gc) {
        gc.setStroke(getColor());
        gc.setLineWidth(5);
        gc.strokeLine(getX(), getY(), x2, y2);
    }

    @Override
    public void constrain(double boxX, double boxY,
                          double boxWidth, double boxHeight) {

        // Constrains x and y with super constructor Shape
        super.constrain(boxX, boxY, boxWidth, boxHeight);

        // Constrains x2
        double newDx = getDx();
        if (x2 < boxX) {
            newDx = Math.abs(getDx());
        } else if (x2 > boxWidth) {
            newDx = -Math.abs(getDx());
        }

        // Constrains y2
        double newDy = getDy();
        if (y2 < boxY) {
            newDy = Math.abs(getDy());
        } else if (y2 > boxHeight) {
            newDy = -Math.abs(getDy());
        }
        setVelocity(newDx, newDy);
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private double x2, y2;

    public double getX2() { return x2; }
    public double getY2() { return y2; }

    @Override
    public String toString() {
        return super.toString() +
             " , x2=" + x2 +
             " , y2=" + y2;
    }
}