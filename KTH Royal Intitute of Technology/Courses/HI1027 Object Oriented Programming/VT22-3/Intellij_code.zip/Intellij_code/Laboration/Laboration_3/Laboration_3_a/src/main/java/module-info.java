module com.example.laboration_3_test {
    requires javafx.controls;
    requires javafx.fxml;


    opens kth.laboration_3_a to javafx.fxml;
    exports kth.laboration_3_a;
    exports kth.laboration_3_a.shapes;
    opens kth.laboration_3_a.shapes to javafx.fxml;
}