package kth.laboration_3_a.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Rectangle extends FillableShape {

    public Rectangle(double x, double y, double width, double height, boolean filled, Color color) {
        super(x, y, filled, color);
        this.width = width;
        this.height = height;
    }

    public Rectangle() {
        super();
        this.width = 60;
        this.height = 40;
    }

    public void setWidth(double width)   { this.width = width; }
    public void setHeight(double height) { this.height = height; }

    @Override
    public void paint(GraphicsContext gc) {
        gc.setStroke(getColor());
        gc.strokeRect(getX(), getY(), width, height);
        if(isFilled()) {
            gc.setFill(getColor());
            gc.fillRect(getX(), getY(), width, height);
        }
    }

    @Override
    public void constrain(double boxX, double boxY,
                          double boxWidth, double boxHeight) {

        // Constrains start points width and height using super constructor Shape
        super.constrain(boxX, boxY, boxWidth, boxHeight);

        // Constrains end points width
        double newDx = getDx();
        if (width + getX() < boxX) {
            newDx = Math.abs(getDx());
        } else if (width + getX() > boxWidth) {
            newDx = -Math.abs(getDx());
        }

        // Constrains end points height
        double newDy = getDy();
        if (height + getY() < boxY) {
            newDy = Math.abs(getDy());
        } else if (height + getY() > boxHeight) {
            newDy = -Math.abs(getDy());
        }
        setVelocity(newDx, newDy);
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private double width, height;

    public double getWidth()  { return width; }
    public double getHeight() { return height; }

    @Override
    public String toString() {
        return super.toString() +
             " , width=" + width +
             " , height=" + height;
    }
}