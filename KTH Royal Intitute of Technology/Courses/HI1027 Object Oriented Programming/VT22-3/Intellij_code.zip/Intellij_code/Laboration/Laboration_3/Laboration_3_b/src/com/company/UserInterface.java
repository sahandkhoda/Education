package com.company;

import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

import static com.company.Isbn.createIsbn;

public class UserInterface
{
    /** Creates a new instance of a scanner and collection (of books). */
    public UserInterface() {
        scan = new Scanner(System.in);
        theCollection = new CollectionOfBooks();
    }

    /**
     * The main menu where the user can specify an option.
     * Entering 0 saves and closes the library.
     */
    public void menu() throws IOException {

        start();
        int choice;
        do {
            menuTEXT();
            System.out.print("Enter option : ");
            choice = Integer.parseInt(scan.nextLine());
            switch (choice) {
                case 1 -> printCollection();
                case 2 -> bookToAdd();
                case 3 -> bookToRemove();
                case 4 -> searchBook();
                case 0 -> quit();
                default -> System.out.println("ERROR! Unknown command");
            }
        } while (choice !=0);
    }

    private void menuTEXT()
    {
        System.out.print(
                """
                   
                   ======= MENU =======
                   1 My library
                   2 Add book
                   3 Remove book
                   4 Search book
                   
                   0 Exit
                   ====================
                   """);
    }

    /** Prints collection of books. */
    private void printCollection() {
        System.out.println("\n" + "=== MY COLLECTION ===");
        if (theCollection.getTheBooks().isEmpty())
            System.out.println("[NO REGISTERED BOOKS]");
        else
            System.out.println(theCollection.toString());
    }

    /** @return book new instance of a Book. */
    private Book bookInfo() {
        return new Book(infoTitle(),
                        infoAuthors(),
                        infoGenre(),
                        infoIsbn(),
                        infoRating());

    }

    /** @return title (string) */
    private String infoTitle() {
        System.out.print("* TITLE  : ");
        return scan.nextLine();
    }

    /** @return authors (List</Authors>) */
    private List<Author> infoAuthors()
    {
        List<Author> listOfAuthors = new ArrayList<>();

        System.out.println("* AUTHOR : ");
        System.out.print("How many authors? : ");
        int nrOfAuthors = Integer.parseInt(scan.nextLine());
        for (int i=0; i<nrOfAuthors; i++) {
            String authorName = authorCreateName();
            LocalDate dateOfBirth = authorCreateDate();
            listOfAuthors.add(new Author(authorName, dateOfBirth));
        }
        return listOfAuthors;
    }

    /** @return author (Author) */
    private Author infoAuthor()
    {
        System.out.println("* AUTHOR : ");
        String authorName = authorCreateName();
        LocalDate dateOfBirth = authorCreateDate();
        return new Author(authorName, dateOfBirth);
    }

    private String authorCreateName()
    {
        System.out.print  (" - Full name : ");
        return scan.nextLine().toUpperCase(Locale.ROOT);
    }

    private LocalDate authorCreateDate()
    {
        System.out.print  (" - Date of birth [YYYYMMDD] : ");
        String authorDate = scan.nextLine();

        StringBuilder y = new StringBuilder();
        StringBuilder m = new StringBuilder();
        StringBuilder d = new StringBuilder();

        for (int j=0; j<authorDate.length(); j++)
        {
            if (j<4)      y.append(authorDate.charAt(j));
            else if (j<6) m.append(authorDate.charAt(j));
            else          d.append(authorDate.charAt(j));
        }

        int year  = Integer.parseInt(String.valueOf(y));
        int month = Integer.parseInt(String.valueOf(m));
        int day   = Integer.parseInt(String.valueOf(d));

        return LocalDate.of(year, month, day);
    }

    /** @return genre (Genre) */
    private Genre infoGenre()
    {
        System.out.print("* GENRE  : ");
        String genreStr = scan.nextLine().toUpperCase(Locale.ROOT);
        return Genre.valueOf(genreStr);
    }

    /** @return isbn (Isbn) creates an ISBN using a static method*/
    private Isbn infoIsbn() {
        System.out.print("* ISBN [13-digit] : ");
        return createIsbn(scan.nextLine());
    }

    /** @return rating (Int) */
    private int infoRating() {
        int rating;
        do {
            System.out.print("* RATING [1-5] : ");
            String ratingStr = scan.nextLine();
            rating = Integer.parseInt(ratingStr);
            if (rating<1 || rating>5) System.out.println("Invalid rating!");
        } while (rating<1 || rating>5);
        return rating;
    }

    /**
     * Creates an instance of a book (title, author, isbn, genre, rating)
     * and passes it to our collection of books. The book is added using
     * a method in ArrayList called add(...).
     */
    public void bookToAdd() {
        System.out.println();
        System.out.println("--- ADD NEW BOOK ---");
        theCollection.addBook(bookInfo());
    }

    /** Removes book matching to the entered ISBN. */
    private void bookToRemove() {
        System.out.println();
        System.out.println("====== REMOVE BOOK ======");
        System.out.print("Enter ISBN : ");
        Isbn isbn = createIsbn(scan.nextLine());
        theCollection.removeBook(isbn);
    }

    /**
     * Gives options for searching for book.
     * Every option implements a specific sub-method.
     */
    public void searchBook()
    {
        int option;
        do {
            System.out.println();
            System.out.println("====== SEARCH BOOK ======");
            System.out.println(" (1) Title");
            System.out.println(" (2) Author");
            System.out.println(" (3) ISBN" + "\n");
            System.out.println(" (0) Return to main menu" + "\n");
            System.out.print("Enter option : ");
            option = Integer.parseInt(scan.nextLine());
            switch (option) {
                case 1 -> getBookByTitle(infoTitle());
                case 2 -> getBookByAuthor(infoAuthor());
                case 3 -> getBookByISBN(infoIsbn());
                case 0 -> {}
                default -> System.out.println("Invalid option!");
            }
        } while (option!=0);
    }

    public void getBookByTitle  (String title)  {
        TitleMatcher matcher = new TitleMatcher(title);
        List<Book> list = theCollection.searchForBooks(matcher);
        for (Book book : list) {
            System.out.println(book.toString());
        }
    }
    public void getBookByAuthor (Author author) {
        AuthorMatcher matcher = new AuthorMatcher(author);
        List<Book> list = theCollection.searchForBooks(matcher);
        for (Book book : list) {
            System.out.println(book.toString());
        }
    }
    public void getBookByISBN   (Isbn isbn)     {
        IsbnMatcher matcher = new IsbnMatcher(isbn);
        List<Book> list = theCollection.searchForBooks(matcher);
        for (Book book : list) {
            System.out.println(book.toString());
        }
    }

    public void start()                   { theCollection.openFile();  }
    public void quit() throws IOException { theCollection.closeFile(); }


    /** PRIVATE FIELDS */
    private final Scanner scan;
    private final CollectionOfBooks theCollection;
}
