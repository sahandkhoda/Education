package com.company;

public class TitleMatcher implements BookMatcher
{
    public TitleMatcher(String toMatch) { this.toMatch = toMatch; }

    @Override
    public boolean matches(Book book) {
        return book.getTitle().contains(toMatch);
    }

    /** PRIVATE FIELD */
    private final String toMatch;
}
