package com.company;

import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        Scanner scanINT = new Scanner(System.in);
        Scanner scanSTRING = new Scanner(System.in);

        String choice = "YES";
        while (choice.toUpperCase(Locale.ROOT).equals("YES"))
        {
            GuessMyNumberModel guessModel = new GuessMyNumberModel(3);
            System.out.println("WELCOME");

            int guess;
            do
            {
                System.out.println();
                System.out.println("SECRET : " + guessModel.getSecret());
                System.out.print("Make a guess [1-" + guessModel.getUpperLimit() + "] : ");
                guess = scanINT.nextInt();
                guessModel.setGuess(guess);
                System.out.println("Your guess is " + guessModel.compareGuessToString());
                System.out.println("Number of guesses : " + guessModel.getNrOfGuesses());
            } while (guess != guessModel.getSecret());

            System.out.println();
            System.out.print("Continue? (yes/no) : ");
            choice = scanSTRING.nextLine();
        }

        System.out.println();
        System.out.println("GOOD-BYE");
        System.out.println("Exiting program...");
        System.out.println("DONE!");
    }
}
