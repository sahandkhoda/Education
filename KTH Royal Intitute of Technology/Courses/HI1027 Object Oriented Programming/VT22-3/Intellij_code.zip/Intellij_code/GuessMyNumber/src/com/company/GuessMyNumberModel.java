package com.company;

import java.util.Random;

public class GuessMyNumberModel
{
    public GuessMyNumberModel(int upperLimit)
    {
        this.upperLimit = upperLimit;
        initGame();
    }

    public void initGame()
    {
        nrOfGuesses = 0;
        secret = random.nextInt(upperLimit)+1;
    }

    public void setGuess(int guess)
    {
        this.guess = guess;
        nrOfGuesses++;
    }

    public String compareGuessToString()
    {
        return switch (compareGuess())
                {
                    case -1 -> "too low...";
                    case 1 -> "too high...";
                    default -> "CORRECT!";
                };
    }

    public int compareGuess()
    {
        return Integer.compare(guess, secret);
    }


    /**
     * PRIVATE FIELDS & ACCESS METHODS
     */

    private final int upperLimit;
    private int secret, guess, nrOfGuesses;
    private static final Random random = new Random();

    public int getSecret()      { return secret; }
    public int getUpperLimit()  { return upperLimit; }
    public int getNrOfGuesses() { return nrOfGuesses; }

}
