package com.sahand.kth.se;

public class SList
{
    public SList(int capacity) {
        arr = new String[capacity];
        nrOfElements = 0;
    }

    public SList() {
        this(10);
    }

    public void add(String s) {
        if (nrOfElements >= arr.length) {
            resize();
        }
        arr[nrOfElements++] = s;
    }

    private void resize() {
        String[] temp = new String[arr.length*2];
        for (int i=0; i<nrOfElements; i++) {
            temp[i] = arr[i];
        }
        arr = temp;
    }

    public String remove(int index) {
        checkIndex(index);
        String temp = arr[index];
        pack(index);
        return temp;
    }

    private void pack(int index) {
        for (int i = index; i<arr.length-1; i++) {
            arr[i] = arr[i+1];
        }
    }

    public void clear() {
        for (int i=0; i< arr.length; i++) {
            arr[i] = null;
        }
    }

    public boolean equals(SList other) {
        if (this == other) return true;
        if (this.nrOfElements != other.nrOfElements) return false;
        for (int i=0; i<nrOfElements; i++) {
            if (!this.arr[i].equals(other.arr[i])) {
                System.out.println("HÄR!");
                return false;
            }
        }
        return true;
    }

    public SList clone() {
        SList copy = new SList(arr.length);
        for (int i = 0; i < nrOfElements; i++) {
            copy.add(this.arr[i]);
        }
        return copy;
    }

    private void checkIndex(int index) {
        if (index < 0 || index > size()) {
            throw new IndexOutOfBoundsException();
        }
    }

    /** PRIVATE FIELDS */
    private String[] arr;
    private int nrOfElements;

    /** ACCESS METHODS */
    public String get(int index) {
        checkIndex(index);
        return arr[index];
    }

    public int getNrOfElements() { return nrOfElements; }

    public int size() { return arr.length; }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();

        builder.append("[");
        for (int i=0; i<arr.length; i++) {
            if (i+1 != arr.length)
                builder.append(arr[i]).append(", ");
            else
                builder.append(arr[i]);
        }
        builder.append("]");
        return builder.toString();
    }
}
