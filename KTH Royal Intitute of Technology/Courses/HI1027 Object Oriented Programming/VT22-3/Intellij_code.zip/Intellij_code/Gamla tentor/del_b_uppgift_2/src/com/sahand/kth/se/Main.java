package com.sahand.kth.se;

public class Main {

    public static void main(String[] args)
    {
        SList s = new SList();
        s.add("Hej");
        s.add("min");
        s.add("vän");
        SList t = s.clone();
        System.out.println("They are equal? " + s.equals(t));
        s.add("där!");


    }
}
