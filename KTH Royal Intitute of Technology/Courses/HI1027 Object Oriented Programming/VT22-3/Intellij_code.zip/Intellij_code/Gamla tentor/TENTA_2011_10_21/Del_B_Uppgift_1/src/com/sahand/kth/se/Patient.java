package com.sahand.kth.se;

import java.util.ArrayList;
import java.util.List;

public class Patient extends Person
{
    public Patient(String name, String pnr) {
        super(name, pnr);
        journalNotes = new ArrayList<>();
    }

    public void addNote(Physician ph, String note) {
        journalNotes.add(new JournalNote(ph, note));
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final List<JournalNote> journalNotes;

    public List<JournalNote> getJournal() {
        return new ArrayList<>(journalNotes);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (JournalNote note : journalNotes) {
            builder.append(note.toString()).append("\n");
        }
        return super.toString() + "\n"
             + "=== PATIENT NOTES==="
             + builder;
    }
}
