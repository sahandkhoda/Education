package com.sahand.kth.se;

public class Physician extends Person
{
    public Physician(String name, String pnr, Speciality speciality) {
        super(name, pnr);
        this.speciality = speciality;
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final Speciality speciality;

    public Speciality getSpeciality()    { return speciality; }

    @Override
    public String toString() {
        return super.toString()
             + "* Speciality : " + getSpeciality() + "\n";
    }
}
