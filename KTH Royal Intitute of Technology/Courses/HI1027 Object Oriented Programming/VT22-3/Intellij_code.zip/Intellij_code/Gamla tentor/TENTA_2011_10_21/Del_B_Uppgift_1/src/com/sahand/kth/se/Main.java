package com.sahand.kth.se;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args)
    {
        Physician ph1 = new Physician("Adam Sandler",
                                      "111111-0000",
                                      Speciality.KIRURG);

        Physician ph2 = new Physician("Kevin James",
                                      "222222-0000",
                                      Speciality.MEDICIN);

        Patient patient = new Patient("Chris Rock", "333333-0000");
        patient.addNote(ph1, "Kevin is a great guy.");
        patient.addNote(ph2, "Adam is bad at basketball.");
        patient.addNote(ph1, "... NOT!");

        System.out.println(patient.toString());
    }
}
