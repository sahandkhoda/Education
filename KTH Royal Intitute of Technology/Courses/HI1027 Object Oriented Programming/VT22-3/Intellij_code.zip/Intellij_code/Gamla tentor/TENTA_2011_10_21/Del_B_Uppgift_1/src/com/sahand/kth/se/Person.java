package com.sahand.kth.se;

public class Person
{
    public Person(String name, String pnr) {
        this.name = name;
        this.pnr = pnr.replace("-", "");
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final String name;
    private final String pnr;

    public String getName() { return name; }
    public String getPnr()  { return pnr;  }

    @Override
    public String toString() {
        return "\n"
             + "=== PERSON INFO ===" + "\n"
             + "NAME : " + getName() + "\n"
             + "PNR  : " + getPnr() + "\n";
    }
}
