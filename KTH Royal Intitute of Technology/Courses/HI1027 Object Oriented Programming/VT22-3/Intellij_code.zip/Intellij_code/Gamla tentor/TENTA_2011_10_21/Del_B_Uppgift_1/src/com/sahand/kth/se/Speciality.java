package com.sahand.kth.se;

public enum Speciality
{
    KIRURG,
    MEDICIN
}
