package com.sahand.kth.se;

import java.util.Date;

public class JournalNote 
{
    public JournalNote(Physician physician, String note) {
        this.physician = physician;
        this.note = note;
        date = new Date();
    }

    /** PRIVATE FIELDS & ACCESS METHODS */
    private final Date date;
    private final Physician physician;
    private final String note;

    public Date      getDate()      { return date; }
    public Physician getPhysician() { return physician; }
    public String    getNote()      { return note; }

    @Override
    public String toString() {
        return "\n"
             + getPhysician().getName()
             + " (" + getPhysician().getSpeciality() + ")" + "\n"
             + getDate() + "\n"
             + "* " + getNote();
    }
}
