package com.company;

import java.util.Locale;

public class Account
{
    /*
    Public fields
    public String firstName;
    public String secondName;
    public String getFullName2() { return firstName + " " + secondName;}
    */

    // Private fields
    private final String fullName;
    private double balance;
    private static double interest;          // Static member, i.e. class data

    // Account info
    public Account(String fullName, double balance) {
        this.fullName = fullName.toUpperCase(Locale.ROOT);
        this.balance = balance;
    }

    // Set interest method
    public static void setInterest(double newInterest) {
        interest = newInterest;
    }

    // Deposit method
    void deposit(double amount) {
        if (amount<0) throw new IllegalArgumentException();
        balance+=amount;
    }

    // Withdraw method
    void withdraw(double amount) {
        if (amount>=0 && amount<=balance) balance-=amount;
        else throw new IllegalArgumentException();
    }

    // Access methods
    public String getFullName1()       { return fullName; }
    public double getBalance()         { return balance;  }
    public static double getInterest() { return interest; }
}
