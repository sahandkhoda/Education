package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        // Account info
        System.out.print("\n");
        Account user = new Account("Adam Sandler", 500);            // Name & Balance
        Account.setInterest(0.5);                                                  // Standard interest
        Scanner scanDOUBLE = new Scanner(System.in);                               // Scanner for double
        Scanner scanSTRING = new Scanner(System.in);                               // Scanner for string

        /*
        System.out.println("-- ACCOUNT INFO --");
        System.out.print("Enter    first name : ");
        user.firstName = scanSTRING.nextLine().toUpperCase(Locale.ROOT);
        System.out.print("Enter   second name : ");
        user.secondName = scanSTRING.nextLine().toUpperCase(Locale.ROOT);
        System.out.print("Enter balance [USD] : ");
        user.balance = scanDOUBLE.nextDouble();
        */

        // ACCOUNT INFO
        {
            System.out.println("=== ACCOUNT INFO ===");
            System.out.println("CURRENT BALANCE [USD] : " + user.getBalance());
            System.out.println("CURRENT INTEREST      : " + Account.getInterest() + "%\n");
        }

        // CHANGE BALANCE
        {
            System.out.println("-- CHANGE BALANCE --");
            System.out.println("Do you want to change your balance?");
            System.out.print(" Press 'yes' or 'no' : ");
        }
        String input1 = scanSTRING.nextLine();
        if (input1.equals("yes"))
        {
            System.out.print(" Press 'd' (deposit) or 'w' (withdraw) : ");
            String choice = scanSTRING.nextLine();
            switch (choice)
            {
                // Deposit
                case "d": {
                    System.out.print(" Enter deposit [USD] : ");
                    double amountDeposit = scanDOUBLE.nextDouble();
                    user.deposit(amountDeposit);
                    break;
                }
                // Withdraw
                case "w": {
                    System.out.print(" Enter withdraw [USD] : ");
                    double amountWithdraw = scanDOUBLE.nextDouble();
                    user.withdraw(amountWithdraw);
                    break;
                }
                default: break;
            }
        }

        // CHANGE INTEREST
        {
            System.out.print("\n");
            System.out.println("-- CHANGE INTEREST --");
            System.out.println("Do you want to change your interest?");
            System.out.print(" Press 'yes' or 'no' : ");
        }
        String input2 = scanSTRING.nextLine();
        if (input2.equals("yes"))
        {
            System.out.print(" Enter new interest : ");
            double interest = scanDOUBLE.nextDouble();
            Account.setInterest(interest);
        }

        // NEW ACCOUNT INFO DISPLAY
        {
            System.out.println("______________________________\n");
            System.out.println("-- ACCOUNT INFO --");
            System.out.println("Full name        : " + user.getFullName1());
            // System.out.println("Full name     : " + user.getFullName2());
            System.out.println("Balance [USD]    : $" + user.getBalance());
            System.out.println("Current interest : " + Account.getInterest() + "%");
        }
    }
}
